import type { Accent } from '../domain/models';

export interface SpeakOptions {
  accent: Accent;
  rate: 0.75 | 0.85 | 1 | 1.15;
  audioUrl: string | null;
  signal?: AbortSignal;
}
export type SpeechResult =
  | { ok: true; source: 'audio' | 'synthesis'; voiceName: string | null }
  | { ok: false; reason: 'unsupported' | 'cancelled' | 'playback-failed' };

let activeAudio: HTMLAudioElement | null = null;

export function selectVoice(voices: SpeechSynthesisVoice[], accent: Accent): SpeechSynthesisVoice | null {
  if (!voices.length) return null;
  const regionTerms = accent === 'en-GB' ? ['united kingdom', 'british', 'uk english'] : ['united states', 'american', 'us english'];
  const scored = voices.map((voice, index) => {
    const lang = voice.lang.toLowerCase();
    const name = voice.name.toLowerCase();
    let score = 0;
    if (lang === accent.toLowerCase()) score = 400;
    else if (regionTerms.some((term) => name.includes(term))) score = 300;
    else if (lang.startsWith('en-')) score = 200;
    else if (lang === 'en') score = 100;
    return { voice, score, index };
  }).filter((item) => item.score > 0);
  scored.sort((a, b) => b.score - a.score || Number(b.voice.localService) - Number(a.voice.localService) || a.index - b.index);
  return scored[0]?.voice ?? null;
}

async function waitForVoices(timeoutMs = 700): Promise<SpeechSynthesisVoice[]> {
  if (!('speechSynthesis' in window)) return [];
  const initial = speechSynthesis.getVoices();
  if (initial.length) return initial;
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      speechSynthesis.removeEventListener?.('voiceschanged', finish);
      resolve(speechSynthesis.getVoices());
    };
    const timer = window.setTimeout(finish, timeoutMs);
    speechSynthesis.addEventListener?.('voiceschanged', finish, { once: true });
  });
}

function playIndependentAudio(url: string, signal?: AbortSignal): Promise<boolean> {
  return new Promise((resolve) => {
    activeAudio?.pause();
    const audio = new Audio(url);
    activeAudio = audio;
    let settled = false;
    const finish = (value: boolean) => {
      if (settled) return;
      settled = true;
      audio.onended = null;
      audio.onerror = null;
      signal?.removeEventListener('abort', onAbort);
      if (activeAudio === audio) activeAudio = null;
      resolve(value);
    };
    const onAbort = () => { audio.pause(); finish(false); };
    audio.onended = () => finish(true);
    audio.onerror = () => finish(false);
    signal?.addEventListener('abort', onAbort, { once: true });
    if (signal?.aborted) return onAbort();
    audio.play().catch(() => finish(false));
  });
}

export function cancelSpeech(): void {
  activeAudio?.pause();
  activeAudio = null;
  if ('speechSynthesis' in window) speechSynthesis.cancel();
}

export async function speakWord(word: string, options: SpeakOptions): Promise<SpeechResult> {
  cancelSpeech();
  if (options.signal?.aborted) return { ok: false, reason: 'cancelled' };
  if (options.audioUrl) {
    const played = await playIndependentAudio(options.audioUrl, options.signal);
    if (played) return { ok: true, source: 'audio', voiceName: null };
    if (options.signal?.aborted) return { ok: false, reason: 'cancelled' };
  }
  if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
    return { ok: false, reason: 'unsupported' };
  }
  const voice = selectVoice(await waitForVoices(), options.accent);
  if (options.signal?.aborted) return { ok: false, reason: 'cancelled' };
  return new Promise((resolve) => {
    const utterance = new SpeechSynthesisUtterance(word);
    utterance.lang = options.accent;
    utterance.rate = options.rate;
    if (voice) utterance.voice = voice;
    const onAbort = () => { speechSynthesis.cancel(); resolve({ ok: false, reason: 'cancelled' }); };
    options.signal?.addEventListener('abort', onAbort, { once: true });
    utterance.onend = () => { options.signal?.removeEventListener('abort', onAbort); resolve({ ok: true, source: 'synthesis', voiceName: voice?.name ?? null }); };
    utterance.onerror = () => { options.signal?.removeEventListener('abort', onAbort); resolve({ ok: false, reason: 'playback-failed' }); };
    speechSynthesis.speak(utterance);
  });
}
