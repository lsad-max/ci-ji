import { useCallback, useEffect, useState } from 'react';
import { useSettings } from '../settings/SettingsProvider';
import type { WordEntry } from '../domain/models';
import { cancelSpeech, selectVoice, speakWord } from './speechService';

export function useSpeech() {
  const { settings } = useSettings();
  const [voiceName, setVoiceName] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [available, setAvailable] = useState(typeof window !== 'undefined' && 'speechSynthesis' in window);

  useEffect(() => {
    if (!('speechSynthesis' in window)) { setAvailable(false); return; }
    const update = () => { const voice = selectVoice(speechSynthesis.getVoices(), settings.accent); setVoiceName(voice?.name ?? null); setAvailable(Boolean(voice || speechSynthesis)); };
    update(); speechSynthesis.addEventListener?.('voiceschanged', update);
    return () => speechSynthesis.removeEventListener?.('voiceschanged', update);
  }, [settings.accent]);

  const speak = useCallback(async (word: WordEntry | string, slow = false) => {
    const value = typeof word === 'string' ? word : word.word;
    const audio = typeof word === 'string' ? null : settings.accent === 'en-GB' ? word.audioUK : word.audioUS;
    const result = await speakWord(value, { accent: settings.accent, rate: slow ? 0.75 : settings.speechRate, audioUrl: audio });
    if (!result.ok) {
      setError(result.reason === 'unsupported' ? '当前浏览器没有可用的英语语音，请在系统中安装英语语音包或更换浏览器。' : result.reason === 'cancelled' ? null : '读音播放失败，请稍后重试。');
    } else { setError(null); setVoiceName(result.voiceName); }
    return result;
  }, [settings.accent, settings.speechRate]);

  return { voiceName, available, error, speak, cancel: cancelSpeech };
}
