import { useRef } from 'react';
import { Volume2 } from 'lucide-react';
import type { WordEntry } from '../domain/models';
import { useSpeech } from './useSpeech';

export function SpeechButton({ word, className = '' }: { word: WordEntry | string; className?: string }) {
  const { speak } = useSpeech();
  const timer = useRef<number | null>(null);
  const slowTriggered = useRef(false);
  const clear = () => { if (timer.current !== null) window.clearTimeout(timer.current); timer.current = null; };
  return <button
    type="button" className={`speech-button ${className}`} aria-label="播放读音"
    onPointerDown={() => { slowTriggered.current = false; timer.current = window.setTimeout(() => { slowTriggered.current = true; void speak(word, true); }, 450); }}
    onPointerUp={clear} onPointerCancel={clear} onPointerLeave={clear}
    onClick={(event) => { if (slowTriggered.current) { event.preventDefault(); slowTriggered.current = false; return; } void speak(word, false); }}
  ><Volume2 size={22} aria-hidden="true" /></button>;
}
