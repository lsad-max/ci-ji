import type { ImmersiveRowData } from './immersiveQueries';
import { SpeechButton } from '../speech/SpeechButton';

export function ImmersiveRow({ row, open, onToggle }: { row:ImmersiveRowData; open:boolean; onToggle:()=>void }) {
  return <article className={`immersive-row ${open?'is-open':''}`}>
    <button className="immersive-row__main" aria-expanded={open} aria-label={`${String(row.number).padStart(2,'0')} ${row.word.word}`} onClick={onToggle}>
      <span className="immersive-row__number">{String(row.number).padStart(2,'0')}</span><span className="immersive-row__word">{row.word.word}</span><span className={`status-dot status-dot--${row.status}`} aria-label={row.status}/>
    </button>
    <div className="immersive-row__speech" onClick={(event)=>event.stopPropagation()}><SpeechButton word={row.word}/></div>
    {open?<div className="immersive-row__answer"><p className="immersive-row__phonetic">{row.word.phoneticUK??'暂无音标'}</p><p><b>{row.word.partOfSpeech.join(' / ')}</b>　{row.word.meanings.join('；')}</p></div>:null}
  </article>;
}
