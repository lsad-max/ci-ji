import { Navigate, createBrowserRouter } from 'react-router-dom';
import { AppShell } from './AppShell';
import { SettingsPage } from '../settings/SettingsPage';
import { CardStudyPage } from '../cards/CardStudyPage';
import { ImmersivePage } from '../immersive/ImmersivePage';
import { Onboarding } from '../onboarding/Onboarding';
import { LibraryPage } from '../library/LibraryPage';
import { WordEditor } from '../library/WordEditor';
import { BulkPastePage } from '../library/BulkPastePage';
import { ImportPackPage } from '../library/ImportPackPage';
import { TrashPage } from '../library/TrashPage';
import { HomePage } from '../home/HomePage';
import { RecordsPage } from '../records/RecordsPage';
import { RecordsDetailPage } from '../records/RecordsDetailPage';
import { BackupPage } from '../backup/BackupPage';
import { useSettings } from '../settings/SettingsProvider';

function OnboardingRoute() { const { patchSettings } = useSettings(); return <Onboarding onDone={async () => { await patchSettings({ onboardingSeen: true }); window.history.back(); }} />; }

function Placeholder({ title }: { title: string }) { return <div className="page"><header className="page-header"><h1>{title}</h1></header><div className="empty-placeholder">功能正在装配</div></div>; }

export const router = createBrowserRouter([
  { path: '/', element: <AppShell />, children: [
    { index: true, element: <HomePage /> },
    { path: 'library', element: <LibraryPage /> },
    { path: 'library/new', element: <WordEditor /> },
    { path: 'library/edit/:wordId', element: <WordEditor /> },
    { path: 'library/bulk', element: <BulkPastePage /> },
    { path: 'library/import', element: <ImportPackPage /> },
    { path: 'library/trash', element: <TrashPage /> },
    { path: 'records', element: <RecordsPage /> },
    { path: 'records/detail', element: <RecordsDetailPage /> },
    { path: 'settings', element: <SettingsPage /> },
    { path: 'study/:mode', element: <CardStudyPage /> },
    { path: 'study/continue/:sessionId', element: <CardStudyPage /> },
    { path: 'immersive/:packId', element: <ImmersivePage /> },
    { path: 'backup', element: <BackupPage /> },
    { path: 'onboarding', element: <OnboardingRoute /> },
    { path: '*', element: <Navigate to="/" replace /> },
  ] },
]);
