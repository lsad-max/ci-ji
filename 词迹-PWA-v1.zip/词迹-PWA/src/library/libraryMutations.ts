import type { IDBPDatabase } from 'idb';
import type { CiJiDb } from '../db/schema';
import { addLocalDays, todayLocal } from '../domain/dates';
import type { DailyPack, StudyState, TrashRecord, WordEntry } from '../domain/models';

const unique = <T,>(values: T[]) => [...new Set(values)];
const rank = { unseen: 0, known: 1, fuzzy: 2, unknown: 3 } as const;

export async function moveWordToTrash(db: IDBPDatabase<CiJiDb>, wordId: string, now = new Date()): Promise<{ affectedPacks: number }> {
  const word = await db.get('words', wordId); if (!word) throw new Error('未找到该单词');
  const packs = await db.getAll('packs');
  const links = packs.flatMap((pack) => pack.wordIds.map((id, index) => id === wordId ? { packId: pack.id, index } : null).filter(Boolean)) as {packId:string;index:number}[];
  const tx = db.transaction(['words', 'packs', 'trash'], 'readwrite');
  for (const pack of packs.filter((item) => item.wordIds.includes(wordId))) {
    const wordIds = pack.wordIds.filter((id) => id !== wordId);
    await tx.objectStore('packs').put({ ...pack, wordIds, wordCount: wordIds.length });
  }
  const deletedAt = now.toISOString();
  const record: TrashRecord = { id: `trash-${word.id}-${now.getTime()}`, word, deletedAt, expiresAt: `${addLocalDays(todayLocal(now), 30)}T23:59:59.999Z`, packLinks: links };
  await tx.objectStore('trash').put(record); await tx.objectStore('words').delete(wordId); await tx.done;
  return { affectedPacks: links.length };
}

export async function restoreWordFromTrash(db: IDBPDatabase<CiJiDb>, trashId: string): Promise<WordEntry> {
  const record = await db.get('trash', trashId); if (!record) throw new Error('回收站中未找到该单词');
  const tx = db.transaction(['trash', 'words', 'packs'], 'readwrite'); await tx.objectStore('words').put(record.word);
  for (const link of record.packLinks ?? []) {
    const pack = await tx.objectStore('packs').get(link.packId); if (!pack || pack.wordIds.includes(record.word.id)) continue;
    const wordIds = [...pack.wordIds]; wordIds.splice(Math.min(link.index, wordIds.length), 0, record.word.id);
    await tx.objectStore('packs').put({ ...pack, wordIds, wordCount: wordIds.length });
  }
  await tx.objectStore('trash').delete(trashId); await tx.done; return record.word;
}

function mergeWordEntries(target: WordEntry, source: WordEntry): WordEntry {
  const objectUnion = <T extends {en:string;zh:string}>(a:T[],b:T[]) => {
    const seen = new Set(a.map((x)=>`${x.en}\0${x.zh}`)); return [...a,...b.filter((x)=>!seen.has(`${x.en}\0${x.zh}`) && (seen.add(`${x.en}\0${x.zh}`),true))];
  };
  return { ...target,
    phoneticUK: target.phoneticUK ?? source.phoneticUK, phoneticUS: target.phoneticUS ?? source.phoneticUS,
    partOfSpeech: unique([...target.partOfSpeech,...source.partOfSpeech]), meanings: unique([...target.meanings,...source.meanings]),
    supplementaryMeanings: unique([...target.supplementaryMeanings,...source.supplementaryMeanings]), categories: unique([...target.categories,...source.categories]),
    phrases: objectUnion(target.phrases,source.phrases), examples: objectUnion(target.examples,source.examples), confusables: unique([...target.confusables,...source.confusables]),
    audioUK: target.audioUK ?? source.audioUK, audioUS: target.audioUS ?? source.audioUS, appearedDates: unique([...target.appearedDates,...source.appearedDates]).sort() as WordEntry['appearedDates'],
    occurrenceCount: unique([...target.appearedDates,...source.appearedDates]).length, updatedAt: new Date().toISOString(),
  };
}

function mergeStates(target: StudyState | undefined, source: StudyState | undefined, targetId: string): StudyState | undefined {
  if (!target && !source) return undefined; if (!target) return { ...source!, wordId: targetId }; if (!source) return target;
  const status = rank[target.status] >= rank[source.status] ? target.status : source.status;
  const nextDates = [target.nextReviewDate,source.nextReviewDate].filter(Boolean).sort();
  return { wordId: targetId, status, consecutiveKnown: status==='known'?Math.max(target.consecutiveKnown,source.consecutiveKnown):0,
    nextReviewDate: nextDates[0] ?? null, lastStudiedAt: [target.lastStudiedAt,source.lastStudiedAt].filter(Boolean).sort().at(-1) ?? null,
    knownCount: target.knownCount+source.knownCount, fuzzyCount: target.fuzzyCount+source.fuzzyCount, unknownCount: target.unknownCount+source.unknownCount };
}

export async function mergeMasterWords(db: IDBPDatabase<CiJiDb>, targetId: string, sourceId: string): Promise<WordEntry> {
  if (targetId===sourceId) throw new Error('不能合并同一词条');
  const [target,source]=await Promise.all([db.get('words',targetId),db.get('words',sourceId)]); if(!target||!source)throw new Error('待合并词条不存在');
  const tx=db.transaction(['words','packs','studyStates','studyEvents','sessions'],'readwrite'); const merged=mergeWordEntries(target,source); await tx.objectStore('words').put(merged);
  const packs=await tx.objectStore('packs').getAll(); for(const pack of packs){if(!pack.wordIds.includes(sourceId))continue;const ids=unique(pack.wordIds.map(id=>id===sourceId?targetId:id));await tx.objectStore('packs').put({...pack,wordIds:ids,wordCount:ids.length} as DailyPack);}
  const events=await tx.objectStore('studyEvents').index('by-word').getAll(sourceId);for(const event of events)await tx.objectStore('studyEvents').put({...event,wordId:targetId});
  const states=mergeStates(await tx.objectStore('studyStates').get(targetId),await tx.objectStore('studyStates').get(sourceId),targetId);if(states)await tx.objectStore('studyStates').put(states);await tx.objectStore('studyStates').delete(sourceId);
  const sessions=await tx.objectStore('sessions').getAll();for(const session of sessions){const replace=(id:string)=>id===sourceId?targetId:id;await tx.objectStore('sessions').put({...session,queue:session.queue.map(c=>({...c,wordId:replace(c.wordId)})),firstPassSeenWordIds:unique(session.firstPassSeenWordIds.map(replace)),undo:session.undo?{...session.undo,card:{...session.undo.card,wordId:replace(session.undo.card.wordId)}}:null});}
  await tx.objectStore('words').delete(sourceId);await tx.done;return merged;
}
