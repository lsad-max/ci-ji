import { z } from 'zod';
import { incomingPackSchema } from '../packs/packSchema';
import type { AppSettings, DailyPack, ImportRecord, LocalDate, StudyEvent, StudySession, StudyState, TrashRecord, WordEntry } from '../domain/models';

const localDateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const bilingualSchema = z.object({ en: z.string(), zh: z.string() });
const wordSchema: z.ZodType<WordEntry> = z.object({
  id:z.string(),normalizedKey:z.string(),word:z.string(),phoneticUK:z.string().nullable(),phoneticUS:z.string().nullable(),partOfSpeech:z.array(z.string()),meanings:z.array(z.string()).min(1),supplementaryMeanings:z.array(z.string()),categories:z.array(z.string()),phrases:z.array(bilingualSchema),examples:z.array(bilingualSchema),confusables:z.array(z.string()),audioUK:z.string().nullable(),audioUS:z.string().nullable(),appearedDates:z.array(localDateSchema) as z.ZodType<LocalDate[]>,occurrenceCount:z.number().int().nonnegative(),createdAt:z.string(),updatedAt:z.string(),
});
const packSchema: z.ZodType<DailyPack> = z.object({id:z.string(),schemaVersion:z.literal(1),date:localDateSchema as z.ZodType<LocalDate>,theme:z.string(),wordCount:z.number().int().nonnegative(),createdAt:z.string(),notes:z.string(),wordIds:z.array(z.string()),categories:z.array(z.string())});
const stateSchema: z.ZodType<StudyState> = z.object({wordId:z.string(),status:z.enum(['unseen','unknown','fuzzy','known']),consecutiveKnown:z.number().int().nonnegative(),nextReviewDate:(localDateSchema.nullable()) as z.ZodType<LocalDate|null>,lastStudiedAt:z.string().nullable(),knownCount:z.number().int().nonnegative(),fuzzyCount:z.number().int().nonnegative(),unknownCount:z.number().int().nonnegative()});
const eventSchema: z.ZodType<StudyEvent> = z.object({id:z.string(),wordId:z.string(),packId:z.string().nullable(),rating:z.enum(['unknown','fuzzy','known']),studiedAt:z.string(),localDate:localDateSchema as z.ZodType<LocalDate>,direction:z.enum(['en-zh','zh-en']),phase:z.enum(['first-pass','reinforcement','review'])});
const sessionCard=z.object({wordId:z.string(),phase:z.enum(['first-pass','reinforcement','review'])});
const sessionSchema: z.ZodType<StudySession> = z.object({id:z.string(),packId:z.string().nullable(),kind:z.enum(['daily','review']),direction:z.enum(['en-zh','zh-en']),queue:z.array(sessionCard),cursor:z.number().int().nonnegative(),firstPassSeenWordIds:z.array(z.string()),ratingCounts:z.object({unknown:z.number(),fuzzy:z.number(),known:z.number()}),undo:z.any().nullable(),completedFirstPassAt:z.string().nullable(),completedAt:z.string().nullable(),updatedAt:z.string()});
const settingsSchema: z.ZodType<AppSettings> = z.object({id:z.literal('singleton'),direction:z.enum(['en-zh','zh-en']),showPhonetic:z.boolean(),gesturesEnabled:z.boolean(),defaultOrder:z.enum(['source','random']),fontSize:z.enum(['small','medium','large']),accent:z.enum(['en-GB','en-US']),speechRate:z.union([z.literal(.75),z.literal(.85),z.literal(1),z.literal(1.15)]),autoSpeakCards:z.boolean(),autoSpeakImmersive:z.boolean(),theme:z.enum(['light','dark','system']),immersiveDensity:z.enum(['compact','comfortable']),onboardingSeen:z.boolean(),gestureHintSeen:z.boolean()});
const importSchema: z.ZodType<ImportRecord> = z.object({id:z.string(),fileName:z.string(),packId:z.string(),importedAt:z.string(),newWordCount:z.number(),linkedWordCount:z.number(),supplementedWordCount:z.number()});
const trashSchema: z.ZodType<TrashRecord> = z.object({id:z.string(),word:wordSchema,deletedAt:z.string(),expiresAt:z.string(),packLinks:z.array(z.object({packId:z.string(),index:z.number().int().nonnegative()})).default([])});

export interface CompleteBackupV1 { schemaVersion:1; app:'词迹'; exportedAt:string; localDate:LocalDate; data:{words:WordEntry[];packs:DailyPack[];studyStates:StudyState[];studyEvents:StudyEvent[];sessions:StudySession[];settings:AppSettings;imports:ImportRecord[];trash:TrashRecord[]} }
export const completeBackupSchema: z.ZodType<CompleteBackupV1> = z.object({schemaVersion:z.literal(1),app:z.literal('词迹'),exportedAt:z.string(),localDate:localDateSchema as z.ZodType<LocalDate>,data:z.object({words:z.array(wordSchema),packs:z.array(packSchema),studyStates:z.array(stateSchema),studyEvents:z.array(eventSchema),sessions:z.array(sessionSchema),settings:settingsSchema,imports:z.array(importSchema),trash:z.array(trashSchema)})});

export function validateBackup(input:unknown):CompleteBackupV1{
 if(typeof input==='object'&&input!==null&&'schemaVersion'in input&&(input as {schemaVersion:unknown}).schemaVersion!==1)throw new Error('备份版本高于当前应用支持版本');
 const result=completeBackupSchema.safeParse(input);if(!result.success)throw new Error(`备份格式错误：${result.error.issues[0]?.path.join('.')||'root'} ${result.error.issues[0]?.message||''}`);return result.data;
}
// Keep the imported pack schema reachable in generated API docs and guard accidental drift.
export const supportedPackSchema = incomingPackSchema;
