export type LocalDate = `${number}-${number}-${number}`;
export type Rating = 'unknown' | 'fuzzy' | 'known';
export type MasteryStatus = 'unseen' | Rating;
export type LearningDirection = 'en-zh' | 'zh-en';
export type Accent = 'en-GB' | 'en-US';
export type ThemeMode = 'light' | 'dark' | 'system';
export type FontSize = 'small' | 'medium' | 'large';
export type ListDensity = 'compact' | 'comfortable';
export type PackOrderMode = 'source' | 'random';
export type StudyPhase = 'first-pass' | 'reinforcement' | 'review';

export interface BilingualText { en: string; zh: string }

export interface WordEntry {
  id: string;
  normalizedKey: string;
  word: string;
  phoneticUK: string | null;
  phoneticUS: string | null;
  partOfSpeech: string[];
  meanings: string[];
  supplementaryMeanings: string[];
  categories: string[];
  phrases: BilingualText[];
  examples: BilingualText[];
  confusables: string[];
  audioUK: string | null;
  audioUS: string | null;
  appearedDates: LocalDate[];
  occurrenceCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface DailyPack {
  id: string;
  schemaVersion: 1;
  date: LocalDate;
  theme: string;
  wordCount: number;
  createdAt: string;
  notes: string;
  wordIds: string[];
  categories: string[];
}

export interface StudyEvent {
  id: string;
  wordId: string;
  packId: string | null;
  rating: Rating;
  studiedAt: string;
  localDate: LocalDate;
  direction: LearningDirection;
  phase: StudyPhase;
}

export interface StudyState {
  wordId: string;
  status: MasteryStatus;
  consecutiveKnown: number;
  nextReviewDate: LocalDate | null;
  lastStudiedAt: string | null;
  knownCount: number;
  fuzzyCount: number;
  unknownCount: number;
}

export interface SessionCard { wordId: string; phase: StudyPhase }

export interface StudySession {
  id: string;
  packId: string | null;
  kind: 'daily' | 'review';
  direction: LearningDirection;
  queue: SessionCard[];
  cursor: number;
  firstPassSeenWordIds: string[];
  ratingCounts: Record<Rating, number>;
  undo: { card: SessionCard; rating: Rating; previousState: StudyState | null; eventId: string; queueBefore?: SessionCard[]; cursorBefore?: number } | null;
  completedFirstPassAt: string | null;
  completedAt: string | null;
  updatedAt: string;
}

export interface AppSettings {
  id: 'singleton';
  direction: LearningDirection;
  showPhonetic: boolean;
  gesturesEnabled: boolean;
  defaultOrder: PackOrderMode;
  fontSize: FontSize;
  accent: Accent;
  speechRate: 0.75 | 0.85 | 1 | 1.15;
  autoSpeakCards: boolean;
  autoSpeakImmersive: boolean;
  theme: ThemeMode;
  immersiveDensity: ListDensity;
  onboardingSeen: boolean;
  gestureHintSeen: boolean;
}

export interface ImportRecord {
  id: string;
  fileName: string;
  packId: string;
  importedAt: string;
  newWordCount: number;
  linkedWordCount: number;
  supplementedWordCount: number;
}

export interface TrashRecord {
  id: string;
  word: WordEntry;
  deletedAt: string;
  expiresAt: string;
  packLinks: { packId: string; index: number }[];
}
