import type { Repositories } from './repositories';
import { parsePackJson } from '../packs/parsePack';
import { buildImportPreview } from '../packs/previewImport';
import { commitPackImport } from '../packs/commitImport';

const SEED_META_KEY = 'seed:2026-07-11:v1';
const SEED_URL = '/packs/2026-07-11-自然地理与环境-131词.json';

export async function ensureBundledSeedImported(repositories: Repositories): Promise<'imported' | 'already-present'> {
  const marker = await repositories.db.get('meta', SEED_META_KEY);
  if (marker?.value === true) return 'already-present';
  const response = await fetch(SEED_URL);
  if (!response.ok) throw new Error(`无法读取内置词包：${response.status}`);
  const result = parsePackJson(await response.text());
  if (!result.ok) throw new Error(`内置词包格式错误：${result.issues.map((issue) => issue.message).join('；')}`);
  const preview = buildImportPreview(result.pack, await repositories.words.getAll(), '2026-07-11-自然地理与环境-131词.json');
  await commitPackImport(repositories.db, preview, {});
  await repositories.db.put('meta', { key: SEED_META_KEY, value: true });
  return 'imported';
}
