import type { DBSchema } from 'idb';
import type { AppSettings, DailyPack, ImportRecord, StudyEvent, StudySession, StudyState, TrashRecord, WordEntry } from '../domain/models';

export interface CiJiDb extends DBSchema {
  words: { key: string; value: WordEntry; indexes: { 'by-normalized': string; 'by-updated': string } };
  packs: { key: string; value: DailyPack; indexes: { 'by-date': string } };
  studyStates: { key: string; value: StudyState; indexes: { 'by-status': string; 'by-next-review': string } };
  studyEvents: { key: string; value: StudyEvent; indexes: { 'by-word': string; 'by-local-date': string } };
  sessions: { key: string; value: StudySession; indexes: { 'by-updated': string } };
  settings: { key: 'singleton'; value: AppSettings };
  imports: { key: string; value: ImportRecord; indexes: { 'by-imported': string } };
  trash: { key: string; value: TrashRecord; indexes: { 'by-expires': string } };
  meta: { key: string; value: { key: string; value: unknown } };
}
