import { beforeEach, describe, expect, it, vi } from 'vitest';
import { selectVoice, speakWord } from '../../src/speech/speechService';

const voice = (name: string, lang: string) => ({ name, lang, default: false, localService: true, voiceURI: name } as SpeechSynthesisVoice);

describe('selectVoice', () => {
  it('prefers exact British and American voices then generic English', () => {
    const voices = [voice('English Generic', 'en-AU'), voice('British Voice', 'en-GB'), voice('American Voice', 'en-US')];
    expect(selectVoice(voices, 'en-GB')?.name).toBe('British Voice');
    expect(selectVoice(voices, 'en-US')?.name).toBe('American Voice');
    expect(selectVoice([voice('English Generic', 'en-AU')], 'en-GB')?.name).toBe('English Generic');
    expect(selectVoice([], 'en-GB')).toBeNull();
  });
});

describe('speakWord', () => {
  beforeEach(() => {
    const synth = {
      getVoices: vi.fn(() => [voice('British Voice', 'en-GB')]),
      cancel: vi.fn(),
      speak: vi.fn((utterance: SpeechSynthesisUtterance) => queueMicrotask(() => utterance.onend?.(new Event('end') as SpeechSynthesisEvent))),
      addEventListener: vi.fn(), removeEventListener: vi.fn(),
    };
    vi.stubGlobal('speechSynthesis', synth);
    vi.stubGlobal('SpeechSynthesisUtterance', class {
      text: string; lang=''; rate=1; voice: SpeechSynthesisVoice|null=null; onend: ((event: SpeechSynthesisEvent)=>void)|null=null; onerror: ((event: SpeechSynthesisErrorEvent)=>void)|null=null;
      constructor(text: string) { this.text = text; }
    });
  });

  it('uses attached audio before synthesis', async () => {
    const play = vi.fn().mockResolvedValue(undefined);
    vi.stubGlobal('Audio', class {
      onended: (()=>void)|null=null; onerror: (()=>void)|null=null; play=play; pause=vi.fn();
      constructor() { queueMicrotask(() => this.onended?.()); }
    });
    const result = await speakWord('atmosphere', { accent: 'en-GB', rate: 0.85, audioUrl: '/a.mp3' });
    expect(result).toEqual({ ok: true, source: 'audio', voiceName: null });
    expect(speechSynthesis.speak).not.toHaveBeenCalled();
  });

  it('falls back to synthesis when audio fails', async () => {
    vi.stubGlobal('Audio', class {
      onended: (()=>void)|null=null; onerror: (()=>void)|null=null; pause=vi.fn();
      play() { queueMicrotask(() => this.onerror?.()); return Promise.resolve(); }
    });
    const result = await speakWord('atmosphere', { accent: 'en-GB', rate: 0.85, audioUrl: '/broken.mp3' });
    expect(result).toMatchObject({ ok: true, source: 'synthesis', voiceName: 'British Voice' });
    const utterance = vi.mocked(speechSynthesis.speak).mock.calls[0][0];
    expect(utterance.text).toBe('atmosphere');
    expect(utterance.rate).toBe(0.85);
  });
});
