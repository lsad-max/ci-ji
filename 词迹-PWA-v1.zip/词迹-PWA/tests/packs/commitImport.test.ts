import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB } from 'idb';
import { openCiJiDb } from '../../src/db/openDb';
import { buildImportPreview } from '../../src/packs/previewImport';
import { commitPackImport } from '../../src/packs/commitImport';
import { validPack } from '../fixtures/samplePack';

const names: string[] = [];
afterEach(async () => Promise.all(names.splice(0).map((name) => deleteDB(name))));

describe('commitPackImport', () => {
  it('writes words, pack, and import in one transaction', async () => {
    const name = `pack-${crypto.randomUUID()}`; names.push(name);
    const db = await openCiJiDb(name);
    const preview = buildImportPreview(validPack, [], 'sample.json');
    const record = await commitPackImport(db, preview, {});
    expect(await db.count('words')).toBe(2);
    expect((await db.get('packs', preview.packId))?.wordIds).toHaveLength(2);
    expect((await db.getAll('imports'))[0].id).toBe(record.id);
    db.close();
  });

  it('rolls back all stores when a word write fails', async () => {
    const name = `pack-${crypto.randomUUID()}`; names.push(name);
    const db = await openCiJiDb(name);
    const preview = buildImportPreview(validPack, [], 'sample.json');
    await expect(commitPackImport(db, preview, {}, { simulateFailureAfterWords: 1 })).rejects.toThrow('模拟导入失败');
    expect(await db.count('words')).toBe(0);
    expect(await db.count('packs')).toBe(0);
    expect(await db.count('imports')).toBe(0);
    db.close();
  });
});
