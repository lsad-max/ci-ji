import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB } from 'idb';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { createRepositories, type Repositories } from '../../src/db/repositories';
import { SettingsProvider, useSettings } from '../../src/settings/SettingsProvider';

const names: string[] = [];
const reposList: Repositories[] = [];
afterEach(async () => {
  reposList.splice(0).forEach((repos) => repos.close());
  await Promise.all(names.splice(0).map((name) => deleteDB(name)));
});

function Probe() {
  const { settings, patchSettings, isReady } = useSettings();
  if (!isReady) return <span>loading</span>;
  return <button onClick={() => patchSettings({ theme: 'dark' })}>{settings.accent}|{settings.speechRate}|{settings.theme}|{settings.fontSize}</button>;
}

describe('SettingsProvider', () => {
  it('loads exact defaults and persists patches after remount', async () => {
    const name = `settings-${crypto.randomUUID()}`; names.push(name);
    const repos = await createRepositories(name); reposList.push(repos);
    const first = render(<SettingsProvider repositories={repos}><Probe /></SettingsProvider>);
    const button = await screen.findByRole('button');
    expect(button).toHaveTextContent('en-GB|0.85|light|medium');
    await userEvent.click(button);
    await waitFor(() => expect(document.documentElement.dataset.theme).toBe('dark'));
    first.unmount();
    render(<SettingsProvider repositories={repos}><Probe /></SettingsProvider>);
    expect(await screen.findByRole('button')).toHaveTextContent('en-GB|0.85|dark|medium');
  });
});
