import type { Page } from '@playwright/test';

export async function finishOnboarding(page: Page) {
  await page.locator('.onboarding, .app-shell').first().waitFor({ state: 'visible' });

  if (await page.locator('.onboarding').isVisible().catch(() => false)) {
    await page.getByRole('button', { name: '下一步' }).click();
    await page.getByRole('button', { name: '下一步' }).click();
    await page.getByRole('button', { name: '开始使用' }).click();
  }

  await page.locator('.app-shell').waitFor({ state: 'visible' });
}

export async function openFreshApp(page: Page) {
  await page.goto('/');
  await finishOnboarding(page);
  await page.getByRole('heading', { name: '词迹' }).waitFor();
}

export async function clearAppData(page: Page) {
  await page.evaluate(async () => {
    const databases = await indexedDB.databases();
    await Promise.all(
      databases.map((database) =>
        database.name
          ? new Promise<void>((resolve, reject) => {
              const request = indexedDB.deleteDatabase(database.name!);
              request.onsuccess = () => resolve();
              request.onerror = () => reject(request.error);
              request.onblocked = () => resolve();
            })
          : Promise.resolve(),
      ),
    );

    const registrations = (await navigator.serviceWorker?.getRegistrations?.()) ?? [];
    await Promise.all(registrations.map((registration) => registration.unregister()));

    const cacheKeys = await caches.keys();
    await Promise.all(cacheKeys.map((key) => caches.delete(key)));
  });
}
