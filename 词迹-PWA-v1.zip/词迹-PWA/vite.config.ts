/// <reference types="vitest/config" />
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [react(), VitePWA({
    registerType:'prompt',
    includeAssets:['icons/apple-touch-icon.png','icons/icon.svg','packs/2026-07-11-自然地理与环境-131词.json'],
    manifest:{name:'词迹',short_name:'词迹',description:'每日识词与间隔复习',lang:'zh-CN',start_url:'/',display:'standalone',orientation:'portrait-primary',theme_color:'#0f766e',background_color:'#f4fbfa',icons:[{src:'/icons/icon-192.png',sizes:'192x192',type:'image/png'},{src:'/icons/icon-512.png',sizes:'512x512',type:'image/png'},{src:'/icons/maskable-512.png',sizes:'512x512',type:'image/png',purpose:'maskable'}]},
    workbox:{cacheId:'ci-ji-app',navigateFallback:'/index.html',globPatterns:['**/*.{js,css,html,svg,png,json}'],cleanupOutdatedCaches:true,runtimeCaching:[]},
  })],
  test: { environment:'jsdom', setupFiles:['./tests/setup.ts'], clearMocks:true, exclude:['e2e/**','node_modules/**','dist/**','release/**'] },
});
