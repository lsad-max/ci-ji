# 部署到 GitHub Pages

当前 PWA 的 `start_url` 和静态资源路径以站点根目录 `/` 为基准。最稳妥的方案是使用名为 `<用户名>.github.io` 的仓库，或为 Pages 配置自定义域名，使应用部署在域名根路径。

## GitHub Actions 示例

1. 将代码推送到默认分支。
2. 在仓库 Settings → Pages 中选择 **GitHub Actions**。
3. 工作流执行：

```bash
npm ci
npm run build
```

4. 将 `dist` 目录作为 Pages artifact 上传并部署。

手动验证：

```bash
npm ci
npm run build
npm run preview -- --host 0.0.0.0
```

若必须部署到 `https://用户名.github.io/仓库名/` 子路径，需要同时设置 Vite `base`、Manifest `start_url` 和图标路径为该子路径，然后重新构建。此调整只影响静态资源 URL，不改变 IndexedDB 的本地保存逻辑；但改变站点 origin 或 path 可能形成新的浏览器存储隔离范围，因此正式使用后不建议频繁更换域名。
