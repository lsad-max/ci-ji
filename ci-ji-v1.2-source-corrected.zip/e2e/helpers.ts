import type { Page } from '@playwright/test';

export const TEST_AUDIO_URL = 'https://upload.wikimedia.org/ci-ji-test/atmosphere-en-gb.ogg';
export const TEST_US_AUDIO_URL = 'https://upload.wikimedia.org/ci-ji-test/atmosphere-en-us.ogg';

export function createSilentWavBuffer(durationMs = 200): Buffer {
  const sampleRate = 8000;
  const samples = Math.floor(sampleRate * durationMs / 1000);
  const buffer = Buffer.alloc(44 + samples * 2);
  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + samples * 2, 4);
  buffer.write('WAVEfmt ', 8);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20);
  buffer.writeUInt16LE(1, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * 2, 28);
  buffer.writeUInt16LE(2, 32);
  buffer.writeUInt16LE(16, 34);
  buffer.write('data', 36);
  buffer.writeUInt32LE(samples * 2, 40);
  return buffer;
}

export async function mockWikimedia(page: Page, options: { failAudio?: boolean } = {}) {
  await page.route('https://en.wiktionary.org/**', async (route) => {
    const word = new URL(route.request().url()).searchParams.get('titles') ?? 'aardvark';
    await route.fulfill({
      json: { query: { pages: [{ title: word, images: [{ title: `File:En-uk-${word}.ogg` }] }] } },
    });
  });
  await page.route('https://commons.wikimedia.org/**', async (route) => {
    const url = new URL(route.request().url());
    const rawTitle = url.searchParams.get('titles')?.split('|')[0] ?? 'File:En-uk-aardvark.ogg';
    const word = rawTitle.replace(/^File:En-uk-/, '').replace(/\.ogg$/, '') || 'aardvark';
    await route.fulfill({
      json: {
        query: {
          pages: [{
            title: `File:En-uk-${word}.ogg`,
            imageinfo: [{
              url: `https://upload.wikimedia.org/ci-ji-test/${word}-en-gb.ogg`,
              descriptionurl: `https://commons.wikimedia.org/wiki/File:En-uk-${word}.ogg`,
              mime: 'audio/ogg', mediatype: 'AUDIO', duration: 0.2,
              extmetadata: {
                Artist: { value: 'Wikimedia Test Speaker' },
                LicenseShortName: { value: 'CC BY-SA 4.0' },
                LicenseUrl: { value: 'https://creativecommons.org/licenses/by-sa/4.0/' },
                Categories: { value: 'British English pronunciation' },
                Language: { value: 'English' },
              },
            }],
          }],
        },
      },
    });
  });
  await page.route('https://upload.wikimedia.org/**', async (route) => {
    if (options.failAudio) {
      await route.fulfill({ status: 500, body: 'failed' });
      return;
    }
    await route.fulfill({ status: 200, contentType: 'audio/wav', body: createSilentWavBuffer() });
  });
}

export async function finishOnboarding(page: Page) {
  await page.locator('.onboarding, .app-shell').first().waitFor({ state: 'visible' });

  if (await page.locator('.onboarding').isVisible().catch(() => false)) {
    await page.getByRole('button', { name: '下一步' }).click();
    await page.getByRole('button', { name: '下一步' }).click();
    await page.getByRole('button', { name: '开始使用' }).click();
  }

  await page.locator('.app-shell').waitFor({ state: 'visible' });
}

export async function openFreshApp(page: Page) {
  await page.goto('/');
  await finishOnboarding(page);
  await page.getByRole('heading', { name: '词迹' }).waitFor();
}

export async function seedApprovedPronunciation(
  page: Page,
  normalizedKey: string,
  accent: 'en-GB' | 'en-US',
  audioUrl = accent === 'en-GB' ? TEST_AUDIO_URL : TEST_US_AUDIO_URL,
) {
  await page.evaluate(async ({ normalizedKey, accent, audioUrl }) => {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('ci-ji');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const word = await new Promise<any>((resolve, reject) => {
      const tx = db.transaction('words', 'readonly');
      const request = tx.objectStore('words').index('by-normalized').get(normalizedKey);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    if (!word) throw new Error(`Missing word ${normalizedKey}`);
    const now = new Date().toISOString();
    const sourceFileName = `${normalizedKey}-${accent}.ogg`;
    const review = {
      id: `${word.id}:${accent}`,
      wordId: word.id,
      normalizedKey,
      accent,
      status: 'approved',
      selected: {
        accent,
        audioUrl,
        compatibleAudioUrl: null,
        filePageUrl: `https://commons.wikimedia.org/wiki/File:${sourceFileName}`,
        author: 'Wikimedia Test Speaker',
        licenseName: 'CC BY-SA 4.0',
        licenseUrl: 'https://creativecommons.org/licenses/by-sa/4.0/',
        sourceFileName,
        durationSeconds: 0.2,
        mappingVersion: 99,
      },
      origin: 'user',
      reviewedAt: now,
      updatedAt: now,
    };
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('pronunciationReviews', 'readwrite');
      tx.objectStore('pronunciationReviews').put(review);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  }, { normalizedKey, accent, audioUrl });
}

export async function waitForPronunciationCache(page: Page, minimum = 1) {
  await page.waitForFunction(async ({ minimum }) => {
    const cache = await caches.open('ci-ji-wikimedia-audio-v1');
    return (await cache.keys()).length >= minimum;
  }, { minimum });
}

export async function clearAppData(page: Page) {
  await page.evaluate(async () => {
    const databases = await indexedDB.databases();
    await Promise.all(
      databases.map((database) =>
        database.name
          ? new Promise<void>((resolve, reject) => {
              const request = indexedDB.deleteDatabase(database.name!);
              request.onsuccess = () => resolve();
              request.onerror = () => reject(request.error);
              request.onblocked = () => resolve();
            })
          : Promise.resolve(),
      ),
    );

    const registrations = (await navigator.serviceWorker?.getRegistrations?.()) ?? [];
    await Promise.all(registrations.map((registration) => registration.unregister()));

    const cacheKeys = await caches.keys();
    await Promise.all(cacheKeys.map((key) => caches.delete(key)));
  });
}
