import { expect, test, type Page } from '@playwright/test';
import fs from 'node:fs';
import path from 'node:path';
import { finishOnboarding, openFreshApp } from './helpers';

async function uploadJson(page: Page, name: string, text: string) {
  await page.locator('input[type=file]').evaluate((input, payload) => {
    const transfer = new DataTransfer();
    transfer.items.add(new File([payload.text], payload.name, { type: 'application/json' }));
    Object.defineProperty(input, 'files', { configurable: true, value: transfer.files });
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }, { name, text });
}

test('pack import preview, duplicate detection, export, clear, and restore recover the library', async ({ page }) => {
  await openFreshApp(page);
  await page.getByRole('link', { name: '设置', exact: true }).click();
  await page.getByText('备份与恢复').click();
  await expect(page.getByRole('button', { name: /导出备份/ })).toBeVisible();

  await page.getByText('清空全部数据').click();
  await page.getByLabel(/请输入/).fill('确认清空');
  await page.getByRole('button', { name: '确认' }).click();

  const packPath = path.resolve(process.cwd(), 'public/packs/2026-07-11-自然地理与环境-131词.json');
  const packText = fs.readFileSync(packPath, 'utf8');
  await page.goto('/library/import');
  await finishOnboarding(page);
  await uploadJson(page, path.basename(packPath), packText);
  await expect(page.getByText(/新单词 131/)).toBeVisible();
  await page.getByRole('button', { name: '确认导入' }).click();
  await expect(page.getByText('词包已导入')).toBeVisible();

  await page.goto('/library/import');
  await uploadJson(page, path.basename(packPath), packText);
  await expect(page.getByText(/已存在 131/)).toBeVisible();

  await page.goto('/backup');
  const [download] = await Promise.all([
    page.waitForEvent('download'),
    page.getByRole('button', { name: /导出备份/ }).click(),
  ]);
  const downloadedPath = await download.path();
  expect(downloadedPath).not.toBeNull();
  const backupText = fs.readFileSync(downloadedPath!, 'utf8');
  expect(JSON.parse(backupText).data.words).toHaveLength(131);

  await page.getByText('清空全部数据').click();
  await page.getByLabel(/请输入/).fill('确认清空');
  await page.getByRole('button', { name: '确认' }).click();
  await uploadJson(page, download.suggestedFilename(), backupText);
  await expect(page.getByText(/单词 131/)).toBeVisible();
  await page.getByRole('button', { name: /合并恢复/ }).click();
  await expect(page.getByText(/合并恢复成功/)).toBeVisible();

  await page.goto('/library');
  await expect(page.getByText(/131个主词条/)).toBeVisible();
});
