import { expect, test } from '@playwright/test';
import {
  TEST_US_AUDIO_URL,
  mockWikimedia,
  openFreshApp,
  seedApprovedPronunciation,
  waitForPronunciationCache,
} from './helpers';

test('approved Wikimedia pronunciation plays and attribution opens', async ({ page }) => {
  await mockWikimedia(page);
  await openFreshApp(page);
  await seedApprovedPronunciation(page, 'atmosphere', 'en-GB');
  await page.goto('/study/today');
  await page.getByRole('button', { name: '播放atmosphere' }).click();
  await expect(page.getByRole('button', { name: '真人发音 · Wikimedia' })).toBeVisible();
  await page.getByRole('button', { name: '真人发音 · Wikimedia' }).click();
  await expect(page.getByText('Wikimedia Test Speaker')).toBeVisible();
  await expect(page.getByRole('link', { name: '查看 Wikimedia 文件页' })).toBeVisible();
  await waitForPronunciationCache(page);
});

test('network failure falls back to same-accent local audio', async ({ page }) => {
  await mockWikimedia(page, { failAudio: true });
  await openFreshApp(page);
  await seedApprovedPronunciation(page, 'atmosphere', 'en-GB');
  await page.goto('/study/today');
  await page.getByRole('button', { name: '播放atmosphere' }).click();
  await expect(page.locator('.speech-button__status')).toHaveText('正在使用备用发音');
});

test('opposite accent is never used', async ({ page }) => {
  let americanRequests = 0;
  await mockWikimedia(page);
  await page.route(TEST_US_AUDIO_URL, async (route) => {
    americanRequests += 1;
    await route.continue();
  });
  await openFreshApp(page);
  await seedApprovedPronunciation(page, 'atmosphere', 'en-US');
  await page.goto('/study/today');
  await page.getByRole('button', { name: '播放atmosphere' }).click();
  await expect(page.locator('.speech-button__status')).toHaveText('正在使用备用发音');
  expect(americanRequests).toBe(0);
});

test('cached recording works offline', async ({ page, context }) => {
  await mockWikimedia(page);
  await openFreshApp(page);
  await seedApprovedPronunciation(page, 'atmosphere', 'en-GB');
  await page.goto('/study/today');
  await page.getByRole('button', { name: '播放atmosphere' }).click();
  await waitForPronunciationCache(page);
  await context.setOffline(true);
  await page.getByRole('button', { name: '播放atmosphere' }).click();
  await page.getByRole('button', { name: '真人发音 · Wikimedia' }).click();
  await expect(page.getByText('已缓存')).toBeVisible();
});

test('new word enters review queue and can be approved', async ({ page }) => {
  await mockWikimedia(page);
  await openFreshApp(page);
  await page.goto('/library/new');
  await page.getByLabel('英文单词').fill('aardvark');
  await page.getByLabel('核心中文释义').fill('土豚');
  await page.getByRole('button', { name: '保存' }).click();
  await page.getByRole('link', { name: /待审核发音/ }).click();
  await expect(page.getByRole('heading', { name: 'aardvark' })).toBeVisible();
  await expect(page.getByText('En-uk-aardvark.ogg')).toBeVisible();
  await page.getByRole('button', { name: '确认使用' }).first().click();
  const status = await page.evaluate(async () => {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('ci-ji');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const reviews = await new Promise<any[]>((resolve, reject) => {
      const tx = db.transaction('pronunciationReviews', 'readonly');
      const request = tx.objectStore('pronunciationReviews').index('by-normalized').getAll('aardvark');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    db.close();
    return reviews.find((review) => review.accent === 'en-GB')?.status;
  });
  expect(status).toBe('approved');
});

test('clearing audio cache preserves mastery', async ({ page }) => {
  await mockWikimedia(page);
  await openFreshApp(page);
  await page.goto('/study/today');
  await page.getByRole('button', { name: '查看释义' }).click();
  await page.getByRole('button', { name: '模糊', exact: true }).click();
  const before = await page.evaluate(async () => {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('ci-ji'); request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
    const result = await new Promise<any[]>((resolve, reject) => {
      const request = db.transaction('studyStates', 'readonly').objectStore('studyStates').getAll();
      request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
    db.close(); return result;
  });
  await page.goto('/settings');
  page.once('dialog', (dialog) => dialog.accept());
  await page.getByRole('button', { name: '清除真人录音缓存' }).click();
  const after = await page.evaluate(async () => {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('ci-ji'); request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
    const result = await new Promise<any[]>((resolve, reject) => {
      const request = db.transaction('studyStates', 'readonly').objectStore('studyStates').getAll();
      request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
    db.close(); return result;
  });
  expect(after).toEqual(before);
});
