import { expect, test } from '@playwright/test';
import { openFreshApp } from './helpers';

test('card flow reveals before rating, persists, supports undo and reverse direction', async ({ page }) => {
  await openFreshApp(page);
  await page.getByText(/继续今日学习|开始今日学习/).click();
  await expect(page.getByRole('button', { name: '查看释义' })).toBeVisible();
  await expect(page.getByRole('button', { name: '不认识' })).toHaveCount(0);
  await page.getByRole('button', { name: '查看释义' }).click();
  for (const label of ['不认识', '模糊', '认识']) {
    await expect(page.getByRole('button', { name: label, exact: true })).toBeVisible();
  }

  const firstWord = await page.locator('.study-card__word').first().textContent();
  await page.getByRole('button', { name: '模糊' }).click();
  await expect(page.getByRole('button', { name: /撤销/ })).toBeVisible();
  await page.reload();
  await expect(page.locator('.study-card__word').first()).not.toHaveText(firstWord ?? '');
  await page.getByRole('button', { name: /撤销/ }).click();
  await expect(page.locator('.study-card__word').first()).toHaveText(firstWord ?? '');

  await page.getByLabel('返回').click();
  await page.getByRole('link', { name: /设置/ }).click();
  await page.getByLabel('学习方向').selectOption('zh-en');
  await page.evaluate(async () => {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('ci-ji');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const transaction = db.transaction('sessions', 'readwrite');
    transaction.objectStore('sessions').clear();
    await new Promise<void>((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
    db.close();
  });
  await page.goto('/study/today');
  await expect(page.locator('.study-card__meaning-front')).toBeVisible();
  await expect(page.locator('input')).toHaveCount(0);
  await page.getByRole('button', { name: '查看释义' }).click();
  await expect(page.locator('.study-card__word--answer')).toBeVisible();
});

test('reinforcement does not advance first-pass progress and all 131 words can complete', async ({ page }) => {
  await openFreshApp(page);
  await page.getByText(/继续今日学习|开始今日学习/).click();
  const progress = page.locator('.study-header span');
  await expect(progress).toHaveText('0 / 131');

  await page.getByRole('button', { name: '查看释义' }).click();
  await page.getByRole('button', { name: '不认识', exact: true }).click();
  await expect(progress).toHaveText('1 / 131');

  let firstPassProgress = 1;
  for (let step = 0; step < 6; step += 1) {
    const label = await progress.textContent();
    if (label?.startsWith('强化')) break;
    await page.getByRole('button', { name: '查看释义' }).click();
    await page.getByRole('button', { name: '认识', exact: true }).click();
    firstPassProgress += 1;
  }
  await expect(progress).toContainText('强化 ·');

  await page.getByRole('button', { name: '查看释义' }).click();
  await page.getByRole('button', { name: '认识', exact: true }).click();
  await expect(progress).toHaveText(`${firstPassProgress} / 131`);

  await page.evaluate(async () => {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('ci-ji');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const requestValue = <T,>(request: IDBRequest<T>) => new Promise<T>((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const readTransaction = db.transaction(['packs', 'sessions'], 'readonly');
    const packs = await requestValue(readTransaction.objectStore('packs').getAll());
    const sessions = await requestValue(readTransaction.objectStore('sessions').getAll());
    const pack = packs[0] as { id: string; wordIds: string[] };
    const session = sessions.find((item: { id: string }) => item.id === `daily:${pack.id}`) as {
      queue: Array<{ wordId: string; phase: 'first-pass' | 'reinforcement' }>;
      cursor: number;
      firstPassSeenWordIds: string[];
      ratingCounts: { unknown: number; fuzzy: number; known: number };
      undo: unknown;
      completedFirstPassAt: string | null;
      completedAt: string | null;
      updatedAt: string;
    };
    session.queue = [
      ...pack.wordIds.map((wordId) => ({ wordId, phase: 'first-pass' as const })),
      { wordId: pack.wordIds[0], phase: 'reinforcement' as const },
    ];
    session.cursor = 130;
    session.firstPassSeenWordIds = pack.wordIds.slice(0, 130);
    session.ratingCounts = { unknown: 1, fuzzy: 0, known: 130 };
    session.undo = null;
    session.completedFirstPassAt = null;
    session.completedAt = null;
    session.updatedAt = new Date().toISOString();
    const writeTransaction = db.transaction('sessions', 'readwrite');
    writeTransaction.objectStore('sessions').put(session);
    await new Promise<void>((resolve, reject) => {
      writeTransaction.oncomplete = () => resolve();
      writeTransaction.onerror = () => reject(writeTransaction.error);
    });
    db.close();
  });
  await page.reload();
  await expect(progress).toHaveText('130 / 131');
  await page.getByRole('button', { name: '查看释义' }).click();
  await page.getByRole('button', { name: '认识', exact: true }).click();

  await expect(page.getByRole('heading', { name: '今日新词浏览完成' })).toBeVisible();
  await expect(page.getByText('共学习 131 词')).toBeVisible();
  await expect(page.getByRole('button', { name: '继续强化' })).toBeVisible();
});
