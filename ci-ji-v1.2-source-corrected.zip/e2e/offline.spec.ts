import { expect, test } from '@playwright/test';
import { finishOnboarding } from './helpers';

test('app shell and IndexedDB remain available after closing the page and reopening offline', async ({ page, context }) => {
  await page.goto('/');
  await finishOnboarding(page);
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.close();

  await context.setOffline(true);
  const offlinePage = await context.newPage();
  await offlinePage.goto('/');
  await expect(offlinePage.getByRole('heading', { name: '词迹' })).toBeVisible();
  await offlinePage.getByRole('link', { name: /词库/ }).click();
  await expect(offlinePage.getByRole('heading', { name: '词库' })).toBeVisible();
  await expect(offlinePage.getByText(/131个主词条/)).toBeVisible();
  await offlinePage.goto('/study/today');
  await expect(offlinePage.locator('.study-card')).toBeVisible();
});
