import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB } from 'idb';
import { openCiJiDb } from '../../src/db/openDb';
import { DEFAULT_SETTINGS } from '../../src/domain/constants';
import { readCompleteBackup } from '../../src/backup/exportBackup';
import { validateBackup } from '../../src/backup/backupSchema';

const names: string[] = [];
afterEach(async () => Promise.all(names.splice(0).map((name) => deleteDB(name))));

describe('pronunciation backup', () => {
  it('exports user reviews in schema v2', async () => {
    const name = `backup-${crypto.randomUUID()}`;
    names.push(name);
    const db = await openCiJiDb(name);
    await db.put('settings', DEFAULT_SETTINGS);
    await db.put('pronunciationReviews', {
      id: 'w1:en-GB', wordId: 'w1', normalizedKey: 'atmosphere', accent: 'en-GB',
      status: 'approved', selected: null, origin: 'user', reviewedAt: null,
      updatedAt: '2026-07-11T00:00:00Z',
    });
    const backup = await readCompleteBackup(db);
    expect(backup.schemaVersion).toBe(2);
    expect(backup.data.pronunciationReviews).toHaveLength(1);
    db.close();
  });

  it('accepts a schema v1 backup and supplies no pronunciation reviews', () => {
    const parsed = validateBackup({
      schemaVersion: 1, app: '词迹', exportedAt: '2026-07-11T00:00:00Z', localDate: '2026-07-11',
      data: { words: [], packs: [], studyStates: [], studyEvents: [], sessions: [], settings: {
        id: 'singleton', direction: 'en-zh', showPhonetic: true, gesturesEnabled: false,
        defaultOrder: 'source', fontSize: 'medium', accent: 'en-GB', speechRate: .85,
        autoSpeakCards: true, autoSpeakImmersive: true, speechUnlocked: false,
        speechErrorsEnabled: true, theme: 'light', immersiveDensity: 'comfortable',
        onboardingSeen: true, gestureHintSeen: false,
      }, imports: [], trash: [] },
    });
    expect(parsed.schemaVersion).toBe(2);
    expect(parsed.data.pronunciationReviews).toEqual([]);
    expect(parsed.data.settings.pronunciationSource).toBe('wikimedia-first');
    expect(parsed.data.settings.cacheWikimediaAfterPlayback).toBe(true);
  });
});
