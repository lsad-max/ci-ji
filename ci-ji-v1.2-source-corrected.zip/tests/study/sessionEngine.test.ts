import { describe, expect, it } from 'vitest';
import type { AppSettings, DailyPack } from '../../src/domain/models';
import { DEFAULT_SETTINGS } from '../../src/domain/constants';
import { createDailySession, rateCurrentCard, undoLastRating } from '../../src/study/sessionEngine';

const pack: DailyPack = {
  id: 'pack-1', schemaVersion: 1, date: '2026-07-11', theme: '自然地理与环境', wordCount: 5,
  createdAt: '2026-07-11T00:00:00.000Z', notes: '', wordIds: ['a','b','c','d','e'], categories: [],
};
const settings: AppSettings = { ...DEFAULT_SETTINGS, onboardingSeen: true };
const context = { localDate: '2026-07-11' as const, studiedAt: '2026-07-11T09:00:00.000Z', idFactory: (() => { let n=0; return () => `id-${++n}`; })() };

describe('session engine', () => {
  it('preserves source order and inserts reinforcement in exact ranges', () => {
    let session = createDailySession(pack, settings, () => 0);
    expect(session.queue.map((card) => card.wordId)).toEqual(['a','b','c','d','e']);
    const unknown = rateCurrentCard(session, undefined, 'unknown', () => 0, context);
    expect(unknown.session.queue[3]).toEqual({ wordId: 'a', phase: 'reinforcement' });
    session = createDailySession(pack, settings, () => 0.999);
    const fuzzy = rateCurrentCard(session, undefined, 'fuzzy', () => 0.999, context);
    expect(fuzzy.session.queue.at(-1)).toEqual({ wordId: 'a', phase: 'reinforcement' });
    session = createDailySession(pack, settings, () => 0);
    const known = rateCurrentCard(session, undefined, 'known', () => 0, context);
    expect(known.session.queue).toHaveLength(5);
  });

  it('first pass progress ignores reinforcement and completion can precede queue completion', () => {
    let session = createDailySession(pack, settings, () => 0);
    for (let i = 0; i < 5; i += 1) {
      const mutation = rateCurrentCard(session, undefined, i === 0 ? 'unknown' : 'known', () => 0, context);
      session = mutation.session;
      while (session.queue[session.cursor]?.phase === 'reinforcement') {
        session = rateCurrentCard(session, undefined, 'known', () => 0, context).session;
      }
    }
    expect(new Set(session.firstPassSeenWordIds).size).toBe(5);
    expect(session.completedFirstPassAt).not.toBeNull();
  });

  it('serializes, resumes, and supports one-level undo', () => {
    const session = createDailySession(pack, settings, () => 0);
    const mutation = rateCurrentCard(session, undefined, 'known', () => 0, context);
    const resumed = JSON.parse(JSON.stringify(mutation.session));
    expect(resumed.cursor).toBe(1);
    const undo = undoLastRating(resumed);
    expect(undo.session.cursor).toBe(0);
    expect(undo.session.queue[0]).toEqual({ wordId: 'a', phase: 'first-pass' });
    expect(undo.session.undo).toBeNull();
    expect(undo.eventId).toBe(mutation.event.id);
    expect(undo.previousState).toBeNull();
  });
});
