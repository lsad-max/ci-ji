import { describe, expect, it } from 'vitest';
import { applyRating } from '../../src/study/scheduler';

const now = '2026-07-11T09:00:00.000Z';

describe('applyRating', () => {
  it('uses exact first interval table', () => {
    expect(applyRating(undefined, 'unknown', '2026-07-11', now, 'w').nextReviewDate).toBe('2026-07-12');
    expect(applyRating(undefined, 'fuzzy', '2026-07-11', now, 'w').nextReviewDate).toBe('2026-07-13');
    expect(applyRating(undefined, 'known', '2026-07-11', now, 'w').nextReviewDate).toBe('2026-07-14');
  });

  it('advances known streak through 7, 15, and 30 days then caps', () => {
    let state = applyRating(undefined, 'known', '2026-07-11', now, 'w');
    state = applyRating(state, 'known', '2026-07-14', now, 'w');
    expect(state.nextReviewDate).toBe('2026-07-21');
    state = applyRating(state, 'known', '2026-07-21', now, 'w');
    expect(state.nextReviewDate).toBe('2026-08-05');
    state = applyRating(state, 'known', '2026-08-05', now, 'w');
    expect(state.nextReviewDate).toBe('2026-09-04');
    state = applyRating(state, 'known', '2026-09-04', now, 'w');
    expect(state.nextReviewDate).toBe('2026-10-04');
  });

  it('unknown and fuzzy reset known streak', () => {
    const known = applyRating(undefined, 'known', '2026-07-11', now, 'w');
    const unknown = applyRating(known, 'unknown', '2026-07-14', now, 'w');
    expect(unknown.consecutiveKnown).toBe(0);
    expect(unknown.nextReviewDate).toBe('2026-07-15');
    const fuzzy = applyRating(known, 'fuzzy', '2026-07-14', now, 'w');
    expect(fuzzy.consecutiveKnown).toBe(0);
    expect(fuzzy.nextReviewDate).toBe('2026-07-16');
  });
});
