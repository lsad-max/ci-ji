import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB } from 'idb';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { createRepositories, type Repositories } from '../../src/db/repositories';
import { RepositoriesProvider } from '../../src/db/RepositoriesContext';
import { SettingsProvider } from '../../src/settings/SettingsProvider';
import { CardStudyPage } from '../../src/cards/CardStudyPage';
import type { DailyPack, WordEntry } from '../../src/domain/models';

const names: string[] = [];
const reposList: Repositories[] = [];
afterEach(async () => {
  reposList.splice(0).forEach((repos) => repos.close());
  await Promise.all(names.splice(0).map((name) => deleteDB(name)));
});

const makeWord = (id: string, word: string, meaning: string): WordEntry => ({
  id, normalizedKey: word, word, phoneticUK: '/test/', phoneticUS: null, partOfSpeech: ['n.'], meanings: [meaning], supplementaryMeanings: [], categories: ['测试'], phrases: [], examples: [], confusables: [], audioUK: null, audioUS: null, appearedDates: ['2026-07-11'], occurrenceCount: 1, createdAt: '2026-07-11T00:00:00.000Z', updatedAt: '2026-07-11T00:00:00.000Z',
});

describe('CardStudyPage', () => {
  it('requires reveal before rating and advances after one saved rating', async () => {
    const name = `cards-${crypto.randomUUID()}`; names.push(name);
    const repos = await createRepositories(name); reposList.push(repos);
    const words = [makeWord('w1','atmosphere','大气层'), makeWord('w2','humidity','湿度')];
    for (const word of words) await repos.words.put(word);
    const pack: DailyPack = { id:'p1',schemaVersion:1,date:'2026-07-11',theme:'测试词包',wordCount:2,createdAt:'2026-07-11T00:00:00.000Z',notes:'',wordIds:['w1','w2'],categories:['测试'] };
    await repos.packs.put(pack);
    await repos.settings.patch({ onboardingSeen: true, autoSpeakCards: false });
    render(<RepositoriesProvider repositories={repos}><SettingsProvider repositories={repos}><MemoryRouter initialEntries={['/study/today']}><Routes><Route path="/study/:mode" element={<CardStudyPage />} /></Routes></MemoryRouter></SettingsProvider></RepositoriesProvider>);
    expect(await screen.findByText('atmosphere')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: '认识' })).not.toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: '查看释义' }));
    expect(screen.getByText('大气层')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '认识' })).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: '认识' }));
    expect(await screen.findByText('humidity')).toBeInTheDocument();
  });
});
