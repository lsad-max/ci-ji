import { DEFAULT_SETTINGS } from '../../src/domain/constants';
import type { AppSettings, WordEntry } from '../../src/domain/models';
import type { ApprovedPronunciation, PronunciationCandidateRecord } from '../../src/pronunciation/types';

export const makeWord = (patch: Partial<WordEntry> = {}): WordEntry => ({
  id: 'w-atmosphere', normalizedKey: 'atmosphere', word: 'atmosphere',
  phoneticUK: '/ˈætməsfɪə/', phoneticUS: '/ˈætməsfɪr/', partOfSpeech: ['n.'],
  meanings: ['大气；气氛'], supplementaryMeanings: [], categories: ['自然地理'],
  phrases: [], examples: [], confusables: [],
  audioUK: 'audio/en-GB/001-atmosphere.mp3',
  audioUS: 'audio/en-US/001-atmosphere.mp3',
  appearedDates: ['2026-07-11'], occurrenceCount: 1,
  createdAt: '2026-07-11T00:00:00.000Z', updatedAt: '2026-07-11T00:00:00.000Z',
  ...patch,
});

export const makeSettings = (patch: Partial<AppSettings> = {}): AppSettings => ({
  ...structuredClone(DEFAULT_SETTINGS),
  onboardingSeen: true,
  ...patch,
});

export const makeApprovedRecording = (patch: Partial<ApprovedPronunciation> = {}): ApprovedPronunciation => ({
  accent: 'en-GB',
  audioUrl: 'https://upload.wikimedia.org/example/atmosphere.ogg',
  compatibleAudioUrl: null,
  filePageUrl: 'https://commons.wikimedia.org/wiki/File:En-uk-atmosphere.ogg',
  author: 'User A', licenseName: 'CC BY-SA 4.0',
  licenseUrl: 'https://creativecommons.org/licenses/by-sa/4.0/',
  sourceFileName: 'En-uk-atmosphere.ogg', durationSeconds: 1.2, mappingVersion: 1,
  ...patch,
});

export const makeCandidate = (patch: Partial<PronunciationCandidateRecord> = {}): PronunciationCandidateRecord => ({
  id: 'w-atmosphere:en-GB:En-uk-atmosphere.ogg',
  wordId: 'w-atmosphere', normalizedKey: 'atmosphere', accent: 'en-GB',
  audioUrl: 'https://upload.wikimedia.org/example/atmosphere.ogg', compatibleAudioUrl: null,
  filePageUrl: 'https://commons.wikimedia.org/wiki/File:En-uk-atmosphere.ogg',
  sourceFileName: 'En-uk-atmosphere.ogg', author: 'User A',
  licenseName: 'CC BY-SA 4.0', licenseUrl: 'https://creativecommons.org/licenses/by-sa/4.0/',
  durationSeconds: 1.2, source: 'wiktionary', rank: 1, rejected: false,
  fetchedAt: '2026-07-11T00:00:00.000Z',
  ...patch,
});
