import type { IncomingPack } from '../../src/packs/packSchema';

export const validPack: IncomingPack = {
  schemaVersion: 1,
  date: '2026-07-11',
  theme: '自然地理与环境',
  wordCount: 2,
  createdAt: '2026-07-11T08:00:00.000Z',
  notes: '测试词包',
  words: [
    {
      word: 'atmosphere', phoneticUK: '/ˈætməsfɪə/', phoneticUS: null,
      partOfSpeech: ['n.'], meanings: ['大气', '大气层'], supplementaryMeanings: [],
      categories: ['地球结构与圈层'], phrases: [], examples: [], confusables: [], audioUK: null, audioUS: null,
    },
    {
      word: 'humidity', phoneticUK: '/hjuːˈmɪdəti/', phoneticUS: null,
      partOfSpeech: ['n.'], meanings: ['湿度'], supplementaryMeanings: [],
      categories: ['气象与气候'], phrases: [], examples: [], confusables: [], audioUK: null, audioUS: null,
    },
  ],
};
