import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const viteConfigText = readFileSync(resolve('vite.config.ts'), 'utf8');

describe('pronunciation PWA cache policy', () => {
  it('precaches the mapping but leaves remote Wikimedia formats to business cache', () => {
    expect(viteConfigText).toContain("'data/wikimedia-pronunciations.json'");
    expect(viteConfigText).toContain("globPatterns: ['**/*.{js,css,html,svg,png,json,mp3}']");
    expect(viteConfigText).not.toContain('json,mp3,ogg,oga,webm');
    expect(viteConfigText).not.toContain('upload.wikimedia.org');
  });

  it('separates Workbox caches by deployment base path', () => {
    expect(viteConfigText).toContain("cacheId: `ci-ji-app-${base.replace(/\\W+/g, '-') || 'root'}`");
  });
});
