import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB } from 'idb';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { createRepositories, type Repositories } from '../../src/db/repositories';
import { RepositoriesProvider } from '../../src/db/RepositoriesContext';
import { SettingsProvider } from '../../src/settings/SettingsProvider';
import { ImmersivePage } from '../../src/immersive/ImmersivePage';
import type { DailyPack, WordEntry } from '../../src/domain/models';

const names: string[]=[]; const reposList: Repositories[]=[];
afterEach(async()=>{ reposList.splice(0).forEach(r=>r.close()); await Promise.all(names.splice(0).map(n=>deleteDB(n))); });
const word=(id:string,w:string,m:string,c:string):WordEntry=>({id,normalizedKey:w,word:w,phoneticUK:'/test/',phoneticUS:null,partOfSpeech:['n.'],meanings:[m],supplementaryMeanings:[],categories:[c],phrases:[],examples:[],confusables:[],audioUK:null,audioUS:null,appearedDates:['2026-07-11'],occurrenceCount:1,createdAt:'2026-07-11T00:00:00.000Z',updatedAt:'2026-07-11T00:00:00.000Z'});

describe('ImmersivePage',()=>{
  it('keeps exactly one row open and speech click does not toggle',async()=>{
    const name=`imm-${crypto.randomUUID()}`;names.push(name);const repos=await createRepositories(name);reposList.push(repos);
    const words=[word('a','atmosphere','大气层','地球'),word('b','humidity','湿度','气候')];for(const w of words)await repos.words.put(w);
    const pack:DailyPack={id:'p1',schemaVersion:1,date:'2026-07-11',theme:'测试词包',wordCount:2,createdAt:'2026-07-11T00:00:00.000Z',notes:'',wordIds:['a','b'],categories:['地球','气候']};await repos.packs.put(pack);await repos.settings.patch({onboardingSeen:true,autoSpeakImmersive:false});
    render(<RepositoriesProvider repositories={repos}><SettingsProvider repositories={repos}><MemoryRouter initialEntries={['/immersive/p1']}><Routes><Route path="/immersive/:packId" element={<ImmersivePage/>}/></Routes></MemoryRouter></SettingsProvider></RepositoriesProvider>);
    const a=await screen.findByRole('button',{name:/01 atmosphere/});const b=screen.getByRole('button',{name:/02 humidity/});
    expect(screen.queryByText('大气层')).not.toBeInTheDocument();
    await userEvent.click(a);expect(screen.getByText('大气层')).toBeInTheDocument();
    await userEvent.click(b);expect(screen.queryByText('大气层')).not.toBeInTheDocument();expect(screen.getByText('湿度')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button',{name:'播放humidity'}));expect(screen.getByText('湿度')).toBeInTheDocument();
    await userEvent.click(b);expect(screen.queryByText('湿度')).not.toBeInTheDocument();
  });
});
