import { describe, expect, it } from 'vitest';
import { addLocalDays, isLocalDate } from '../../src/domain/dates';

describe('local date helpers', () => {
  it('adds calendar days without UTC conversion', () => {
    expect(addLocalDays('2026-07-11', 1)).toBe('2026-07-12');
    expect(addLocalDays('2026-12-31', 1)).toBe('2027-01-01');
  });

  it('validates the exact YYYY-MM-DD representation', () => {
    expect(isLocalDate('2026-07-11')).toBe(true);
    expect(isLocalDate('2026-7-11')).toBe(false);
  });
});
