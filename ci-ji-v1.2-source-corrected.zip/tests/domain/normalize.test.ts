import { describe, expect, it } from 'vitest';
import { normalizeWordKey } from '../../src/domain/normalize';

describe('normalizeWordKey', () => {
  it('trims, lowercases, collapses spaces, and normalizes curly apostrophes', () => {
    expect(normalizeWordKey("  Earth’S   atmosphere  ")).toBe("earth's atmosphere");
  });

  it('does not conflate different word forms', () => {
    expect(normalizeWordKey('pollute')).not.toBe(normalizeWordKey('pollution'));
  });
});
