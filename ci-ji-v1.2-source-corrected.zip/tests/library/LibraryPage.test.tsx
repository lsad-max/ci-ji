import { describe, expect, it } from 'vitest';
import { DESTRUCTIVE_CONFIRMATION } from '../../src/domain/constants';
describe('library destructive confirmation',()=>{it('uses the exact agreed phrase',()=>{expect(DESTRUCTIVE_CONFIRMATION).toBe('确认清空');});});
