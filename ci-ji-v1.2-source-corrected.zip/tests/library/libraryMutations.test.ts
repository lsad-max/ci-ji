import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB } from 'idb';
import { createRepositories, type Repositories } from '../../src/db/repositories';
import { mergeMasterWords } from '../../src/library/libraryMutations';
import { createUnreviewedRecord } from '../../src/pronunciation/pronunciationRepository';
import { makeCandidate, makeWord } from '../fixtures/pronunciation';

const names: string[] = [];
const openRepos: Repositories[] = [];

async function setup() {
  const name = `library-mutations-${crypto.randomUUID()}`;
  names.push(name);
  const repos = await createRepositories(name);
  openRepos.push(repos);
  return repos;
}

afterEach(async () => {
  openRepos.splice(0).forEach((repos) => repos.close());
  await Promise.all(names.splice(0).map((name) => deleteDB(name)));
});

describe('library pronunciation data lifecycle', () => {
  it('removes source pronunciation records when master words are merged', async () => {
    const repos = await setup();
    const target = makeWord({ id: 'target' });
    const source = makeWord({ id: 'source', word: 'atmospheres', normalizedKey: 'atmospheres' });
    await repos.words.put(target);
    await repos.words.put(source);
    await repos.pronunciationReviews.put(createUnreviewedRecord(source.id, source.normalizedKey, 'en-GB'));
    await repos.pronunciationCandidates.putMany([makeCandidate({
      id: 'source:en-GB:file.ogg',
      wordId: source.id,
    })]);

    await mergeMasterWords(repos.db, target.id, source.id);

    expect(await repos.pronunciationReviews.getByWord(source.id)).toEqual([]);
    expect(await repos.pronunciationCandidates.getByWord(source.id)).toEqual([]);
  });

  it('removes pronunciation records when a trash item is permanently deleted', async () => {
    const repos = await setup();
    const word = makeWord();
    await repos.pronunciationReviews.put(createUnreviewedRecord(word.id, word.normalizedKey, 'en-GB'));
    await repos.pronunciationCandidates.putMany([makeCandidate()]);
    await repos.trash.put({
      id: 'trash-1', word, deletedAt: '2026-07-11T00:00:00.000Z',
      expiresAt: '2026-08-10T23:59:59.999Z', packLinks: [],
    });

    await repos.trash.delete('trash-1');

    expect(await repos.pronunciationReviews.getByWord(word.id)).toEqual([]);
    expect(await repos.pronunciationCandidates.getByWord(word.id)).toEqual([]);
  });

  it('removes pronunciation records when an expired trash item is purged', async () => {
    const repos = await setup();
    const word = makeWord();
    await repos.pronunciationReviews.put(createUnreviewedRecord(word.id, word.normalizedKey, 'en-US'));
    await repos.pronunciationCandidates.putMany([makeCandidate()]);
    await repos.trash.put({
      id: 'trash-expired', word, deletedAt: '2026-06-01T00:00:00.000Z',
      expiresAt: '2026-07-01T00:00:00.000Z', packLinks: [],
    });

    await expect(repos.trash.purgeExpired('2026-07-11T00:00:00.000Z')).resolves.toBe(1);

    expect(await repos.pronunciationReviews.getByWord(word.id)).toEqual([]);
    expect(await repos.pronunciationCandidates.getByWord(word.id)).toEqual([]);
  });
});
