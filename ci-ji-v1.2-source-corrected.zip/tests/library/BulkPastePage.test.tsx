import { describe, expect, it } from 'vitest';
import { parseBulkWords } from '../../src/library/libraryQueries';
describe('BulkPastePage parser contract',()=>{it('never silently accepts an invalid row',()=>{const result=parseBulkWords('valid | n. | 有效\nwrong | noun');expect(result.rows).toHaveLength(1);expect(result.issues[0]).toMatchObject({lineNumber:2,message:'无法确定中文释义'});});});
