import { describe, expect, it } from 'vitest';
import { buildImportPreview } from '../../src/packs/previewImport';
import type { WordEntry } from '../../src/domain/models';
import { validPack } from '../fixtures/samplePack';

const existing: WordEntry = {
  id: 'word-atmosphere', normalizedKey: 'atmosphere', word: 'atmosphere',
  phoneticUK: '/ˈætməsfɪə/', phoneticUS: null, partOfSpeech: ['n.'], meanings: ['大气', '大气层'],
  supplementaryMeanings: [], categories: [], phrases: [], examples: [], confusables: [], audioUK: null, audioUS: null,
  appearedDates: ['2026-07-01'], occurrenceCount: 1, createdAt: '2026-07-01T00:00:00.000Z', updatedAt: '2026-07-01T00:00:00.000Z',
};

describe('buildImportPreview', () => {
  it('preserves source order and classifies duplicate/new rows', () => {
    const preview = buildImportPreview(validPack, [existing], 'sample.json');
    expect(preview.rows.map((row) => row.incoming.word)).toEqual(['atmosphere', 'humidity']);
    expect(preview.rows.map((row) => row.action)).toEqual(['supplement', 'create']);
    expect(preview.counts.create).toBe(1);
    expect(preview.categoryCounts['气象与气候']).toBe(1);
  });
});
