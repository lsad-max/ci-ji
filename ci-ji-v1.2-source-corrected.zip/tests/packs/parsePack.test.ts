import { describe, expect, it } from 'vitest';
import { parsePackJson } from '../../src/packs/parsePack';
import { validPack } from '../fixtures/samplePack';

describe('parsePackJson', () => {
  it('parses a valid pack', () => {
    const result = parsePackJson(JSON.stringify(validPack));
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.pack.words).toHaveLength(2);
  });

  it.each([
    ['malformed json', '{', 'json'],
    ['missing date', JSON.stringify({ ...validPack, date: undefined }), 'schema'],
    ['missing theme', JSON.stringify({ ...validPack, theme: '' }), 'schema'],
    ['count mismatch', JSON.stringify({ ...validPack, wordCount: 3 }), 'count'],
    ['empty word', JSON.stringify({ ...validPack, words: [{ ...validPack.words[0], word: '' }, validPack.words[1]] }), 'schema'],
    ['empty meanings', JSON.stringify({ ...validPack, words: [{ ...validPack.words[0], meanings: [] }, validPack.words[1]] }), 'schema'],
    ['newer version', JSON.stringify({ ...validPack, schemaVersion: 2 }), 'unsupported-version'],
  ])('reports %s without throwing', (_label, text, code) => {
    const result = parsePackJson(text);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.issues.some((issue) => issue.code === code)).toBe(true);
  });
});
