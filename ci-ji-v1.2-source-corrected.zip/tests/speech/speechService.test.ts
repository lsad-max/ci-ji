import { beforeEach, describe, expect, it, vi } from 'vitest';
import { inspectSpeech, selectVoice, speakWord } from '../../src/speech/speechService';

const voice = (name: string, lang: string) => ({ name, lang, default: false, localService: true, voiceURI: name } as SpeechSynthesisVoice);

class TestUtterance {
  text: string;
  lang = '';
  rate = 1;
  voice: SpeechSynthesisVoice | null = null;
  onend: ((event: SpeechSynthesisEvent) => void) | null = null;
  onerror: ((event: SpeechSynthesisErrorEvent) => void) | null = null;
  constructor(text: string) { this.text = text; }
}

describe('selectVoice', () => {
  it('prefers exact British and American voices then generic English', () => {
    const voices = [voice('English Generic', 'en-AU'), voice('British Voice', 'en-GB'), voice('American Voice', 'en-US')];
    expect(selectVoice(voices, 'en-GB')?.name).toBe('British Voice');
    expect(selectVoice(voices, 'en-US')?.name).toBe('American Voice');
    expect(selectVoice([voice('English Generic', 'en-AU')], 'en-GB')?.name).toBe('English Generic');
    expect(selectVoice([], 'en-GB')).toBeNull();
  });
});

describe('speakWord', () => {
  beforeEach(() => {
    const synth = {
      getVoices: vi.fn(() => [voice('British Voice', 'en-GB')]),
      cancel: vi.fn(),
      resume: vi.fn(),
      speak: vi.fn((utterance: SpeechSynthesisUtterance) => queueMicrotask(() => utterance.onend?.(new Event('end') as SpeechSynthesisEvent))),
      addEventListener: vi.fn(), removeEventListener: vi.fn(),
    };
    vi.stubGlobal('speechSynthesis', synth);
    vi.stubGlobal('SpeechSynthesisUtterance', TestUtterance);
  });

  it('uses preferred attached audio, applies the selected rate, and skips synthesis', async () => {
    const instances: Array<{ src: string; playbackRate: number }> = [];
    vi.stubGlobal('Audio', class {
      src: string;
      playbackRate = 1;
      preload = '';
      onended: (() => void) | null = null;
      onerror: (() => void) | null = null;
      pause = vi.fn();
      constructor(src: string) { this.src = src; instances.push(this); queueMicrotask(() => this.onended?.()); }
      play() { return Promise.resolve(); }
    });
    const result = await speakWord('atmosphere', {
      accent: 'en-GB', rate: 0.85,
      audioUK: 'audio/en-GB/001-atmosphere.mp3',
      audioUS: 'audio/en-US/001-atmosphere.mp3',
    });
    expect(result).toEqual({ ok: true, source: 'audio', voiceName: null, accent: 'en-GB' });
    expect(instances[0]?.src).toContain('/audio/en-GB/001-atmosphere.mp3');
    expect(instances[0]?.playbackRate).toBe(0.85);
    expect(speechSynthesis.speak).not.toHaveBeenCalled();
  });

  it('falls back from broken preferred audio to preferred system synthesis', async () => {
    vi.stubGlobal('Audio', class {
      playbackRate = 1; preload = '';
      onended: (() => void) | null = null; onerror: (() => void) | null = null; pause = vi.fn();
      constructor() {}
      play() { queueMicrotask(() => this.onerror?.()); return Promise.resolve(); }
    });
    const result = await speakWord('atmosphere', {
      accent: 'en-GB', rate: 0.85,
      audioUK: 'audio/en-GB/broken.mp3', audioUS: 'audio/en-US/001-atmosphere.mp3',
    });
    expect(result).toMatchObject({ ok: true, source: 'synthesis', voiceName: 'British Voice', accent: 'en-GB' });
    const utterance = vi.mocked(speechSynthesis.speak).mock.calls[0][0];
    expect(utterance.text).toBe('atmosphere');
    expect(utterance.rate).toBe(0.85);
  });

  it('does not use the opposite accent as a fallback', async () => {
    vi.mocked(speechSynthesis.getVoices).mockReturnValue([]);
    const requested: string[] = [];
    vi.stubGlobal('Audio', class {
      src: string; playbackRate = 1; preload = '';
      onended: (() => void) | null = null; onerror: (() => void) | null = null; pause = vi.fn();
      constructor(src: string) { this.src = src; requested.push(src); }
      play() {
        if (this.src.includes('en-GB')) queueMicrotask(() => this.onerror?.());
        else queueMicrotask(() => this.onended?.());
        return Promise.resolve();
      }
    });
    const result = await speakWord('atmosphere', {
      accent: 'en-GB', rate: 1,
      audioUK: 'audio/en-GB/broken.mp3', audioUS: 'audio/en-US/001-atmosphere.mp3',
    });
    expect(requested.some((url) => url.includes('en-US/001-atmosphere.mp3'))).toBe(false);
    expect(result).toEqual({ ok: false, reason: 'unsupported' });
  });
});

describe('inspectSpeech', () => {
  it('reports browser and English voice availability', async () => {
    vi.stubGlobal('speechSynthesis', {
      getVoices: vi.fn(() => [voice('British Voice', 'en-GB'), voice('Chinese Voice', 'zh-CN')]),
      addEventListener: vi.fn(), removeEventListener: vi.fn(), cancel: vi.fn(), resume: vi.fn(), speak: vi.fn(),
    });
    const result = await inspectSpeech('en-GB');
    expect(result).toEqual({ supported: true, totalVoices: 2, englishVoices: 1, voiceName: 'British Voice' });
  });
});
