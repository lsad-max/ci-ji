import { describe, expect, it } from 'vitest';
import { normalizeBasePath, routerBasenameFromBase } from '../../src/app/basePath';

describe('GitHub Pages base path helpers', () => {
  it('normalizes repository paths with one leading and trailing slash', () => {
    expect(normalizeBasePath('ci-ji')).toBe('/ci-ji/');
    expect(normalizeBasePath('/ci-ji')).toBe('/ci-ji/');
    expect(normalizeBasePath('/ci-ji/')).toBe('/ci-ji/');
    expect(normalizeBasePath('/ci-ji/preview-v1-2/')).toBe('/ci-ji/preview-v1-2/');
  });

  it('keeps the root deployment path unchanged', () => {
    expect(normalizeBasePath('/')).toBe('/');
    expect(normalizeBasePath('')).toBe('/');
  });

  it('converts the Vite base URL into a React Router basename', () => {
    expect(routerBasenameFromBase('/')).toBeUndefined();
    expect(routerBasenameFromBase('/ci-ji/')).toBe('/ci-ji');
    expect(routerBasenameFromBase('/ci-ji/preview-v1-2/')).toBe('/ci-ji/preview-v1-2');
  });
});
