import { describe, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Onboarding } from '../../src/onboarding/Onboarding';

describe('Onboarding', () => {
  it('shows three exact steps and can skip', async () => {
    const onDone = vi.fn();
    render(<Onboarding onDone={onDone} />);
    expect(screen.getByText('导入每日词包')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: '下一步' }));
    expect(screen.getByText('判断认识、模糊、不认识')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: '下一步' }));
    expect(screen.getByText('用沉浸词表快速浏览')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: '开始使用' }));
    expect(onDone).toHaveBeenCalledOnce();
  });

  it('skip finishes immediately', async () => {
    const onDone = vi.fn();
    render(<Onboarding onDone={onDone} />);
    await userEvent.click(screen.getByRole('button', { name: '跳过' }));
    expect(onDone).toHaveBeenCalledOnce();
  });
});
