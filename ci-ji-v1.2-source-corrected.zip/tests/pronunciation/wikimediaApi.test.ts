import { describe, expect, it } from 'vitest';
import { rankCandidates, selectReviewCandidates, stripMetadataHtml } from '../../src/pronunciation/wikimediaApi';
import { makeCandidate } from '../fixtures/pronunciation';

describe('Wikimedia API helpers', () => {
  it('strips HTML from attribution metadata', () => {
    expect(stripMetadataHtml('<a href="/wiki/User:A">User A</a>')).toBe('User A');
  });

  it('ranks explicit British Wiktionary audio above unknown Commons search', () => {
    const ranked = rankCandidates([
      { id: 'u', wordId: 'w1', normalizedKey: 'atmosphere', accent: 'unknown', source: 'commons-search', rank: 0 } as never,
      { id: 'b', wordId: 'w1', normalizedKey: 'atmosphere', accent: 'en-GB', source: 'wiktionary', rank: 0 } as never,
    ], 'en-GB');
    expect(ranked.map((item) => item.id)).toEqual(['b', 'u']);
  });

  it('keeps at most five ranked candidates per explicit accent', () => {
    const british = Array.from({ length: 6 }, (_, index) => makeCandidate({
      id: `b-${index}`,
      accent: 'en-GB',
      source: index === 5 ? 'wiktionary' : 'commons-search',
      sourceFileName: `En-uk-atmosphere-${index}.ogg`,
    }));
    const american = Array.from({ length: 6 }, (_, index) => makeCandidate({
      id: `u-${index}`,
      accent: 'en-US',
      sourceFileName: `En-us-atmosphere-${index}.ogg`,
    }));
    const selected = selectReviewCandidates([...british, ...american]);
    expect(selected.filter((candidate) => candidate.accent === 'en-GB')).toHaveLength(5);
    expect(selected.filter((candidate) => candidate.accent === 'en-US')).toHaveLength(5);
    expect(selected.filter((candidate) => candidate.accent === 'en-GB')[0]?.id).toBe('b-5');
  });

  it('does not let rejected candidates consume the five visible slots', () => {
    const british = Array.from({ length: 6 }, (_, index) => makeCandidate({
      id: `b-${index}`,
      accent: 'en-GB',
      rejected: index === 0,
      sourceFileName: `En-uk-atmosphere-${index}.ogg`,
    }));
    const selected = selectReviewCandidates(british);
    expect(selected.filter((candidate) => candidate.accent === 'en-GB')).toHaveLength(5);
    expect(selected.some((candidate) => candidate.id === 'b-0')).toBe(false);
    expect(selected.some((candidate) => candidate.id === 'b-5')).toBe(true);
  });

});
