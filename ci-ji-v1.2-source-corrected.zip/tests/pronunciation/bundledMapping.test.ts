import { describe, expect, it } from 'vitest';
import { parseBundledMapping } from '../../src/pronunciation/mappingSchema';

describe('bundled Wikimedia mapping', () => {
  it('rejects approved records without attribution', () => {
    expect(() => parseBundledMapping({
      schemaVersion: 1,
      mappingVersion: 1,
      generatedAt: '2026-07-11T00:00:00Z',
      words: { atmosphere: { british: { status: 'approved', accent: 'en-GB', audioUrl: 'https://upload.wikimedia.org/a.ogg' } } },
    })).toThrow();
  });

  it('accepts explicit missing accents', () => {
    const parsed = parseBundledMapping({
      schemaVersion: 1,
      mappingVersion: 1,
      generatedAt: '2026-07-11T00:00:00Z',
      words: { atmosphere: { british: { status: 'missing', accent: 'en-GB' }, american: { status: 'missing', accent: 'en-US' } } },
    });
    expect(parsed.words.atmosphere.british.status).toBe('missing');
  });
});
