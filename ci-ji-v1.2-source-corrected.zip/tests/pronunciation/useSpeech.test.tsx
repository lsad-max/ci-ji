import { act, renderHook } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { makeApprovedRecording, makeWord } from '../fixtures/pronunciation';

const mocks = vi.hoisted(() => ({
  patchSettings: vi.fn(async () => undefined),
  getReview: vi.fn(async () => undefined),
  resolvePlan: vi.fn(),
  play: vi.fn(),
  cancel: vi.fn(),
}));

vi.mock('../../src/settings/SettingsProvider', () => ({
  useSettings: () => ({
    settings: {
      id: 'singleton', direction: 'en-zh', showPhonetic: true, gesturesEnabled: false,
      defaultOrder: 'source', fontSize: 'medium', accent: 'en-GB', speechRate: 0.85,
      autoSpeakCards: true, autoSpeakImmersive: true, speechUnlocked: false,
      speechErrorsEnabled: false, pronunciationSource: 'wikimedia-first',
      cacheWikimediaAfterPlayback: true, theme: 'light', immersiveDensity: 'comfortable',
      onboardingSeen: true, gestureHintSeen: true,
    },
    patchSettings: mocks.patchSettings,
  }),
}));
vi.mock('../../src/db/RepositoriesContext', () => ({
  useRepositories: () => ({ pronunciationReviews: { get: mocks.getReview } }),
}));
vi.mock('../../src/pronunciation/pronunciationResolver', () => ({
  resolvePronunciationPlan: mocks.resolvePlan,
}));
vi.mock('../../src/pronunciation/audioPlaybackController', () => ({
  playPronunciation: mocks.play,
  cancelPronunciation: mocks.cancel,
}));
vi.mock('../../src/pronunciation/bundledMapping', () => ({
  getBundledPronunciation: vi.fn(async () => null),
}));

import { useSpeech } from '../../src/speech/useSpeech';

describe('useSpeech', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    const recording = makeApprovedRecording();
    mocks.resolvePlan.mockResolvedValue({
      word: 'atmosphere', accent: 'en-GB', attribution: recording,
      steps: [{ kind: 'wikimedia-online', recording, timeoutMs: 6000 }],
    });
    mocks.play.mockResolvedValue({
      ok: true, source: 'wikimedia-online', accent: 'en-GB', attribution: recording,
    });
    vi.stubGlobal('speechSynthesis', {
      getVoices: vi.fn(() => []), addEventListener: vi.fn(), removeEventListener: vi.fn(), cancel: vi.fn(),
    });
  });

  it('resolves and plays human pronunciation while exposing attribution', async () => {
    const recording = makeApprovedRecording();
    const { result } = renderHook(() => useSpeech());
    await act(async () => { await result.current.speak(makeWord()); });
    expect(mocks.resolvePlan).toHaveBeenCalled();
    expect(mocks.play).toHaveBeenCalled();
    expect(result.current.status).toBe('playing-human');
    expect(result.current.lastSource).toBe('wikimedia-online');
    expect(result.current.attribution).toEqual(recording);
    expect(result.current.error).toBeNull();
  });

  it('clears Wikimedia attribution when playback falls back to local audio', async () => {
    const recording = makeApprovedRecording();
    mocks.play.mockResolvedValueOnce({
      ok: true, source: 'local-audio', accent: 'en-GB', attribution: null,
    });
    const { result } = renderHook(() => useSpeech());
    await act(async () => { await result.current.speak(makeWord()); });
    expect(result.current.status).toBe('playing-fallback');
    expect(result.current.attribution).toBeNull();
  });

  it('does not let an older unresolved plan cancel or overwrite a newer request', async () => {
    let resolveFirst: ((value: unknown) => void) | null = null;
    const recording = makeApprovedRecording();
    const firstPlan = new Promise((resolve) => { resolveFirst = resolve; });
    mocks.resolvePlan
      .mockReturnValueOnce(firstPlan)
      .mockResolvedValueOnce({
        word: 'climate', accent: 'en-GB', attribution: recording,
        steps: [{ kind: 'wikimedia-online', recording, timeoutMs: 6000 }],
      });
    mocks.play.mockResolvedValue({
      ok: true, source: 'wikimedia-online', accent: 'en-GB', attribution: recording,
    });
    const { result } = renderHook(() => useSpeech());
    let firstPromise: Promise<unknown> | undefined;
    await act(async () => {
      firstPromise = result.current.speak(makeWord());
      await result.current.speak(makeWord({ id: 'w-climate', word: 'climate', normalizedKey: 'climate' }));
    });
    await act(async () => {
      resolveFirst?.({
        word: 'atmosphere', accent: 'en-GB', attribution: recording,
        steps: [{ kind: 'wikimedia-online', recording, timeoutMs: 6000 }],
      });
      await firstPromise;
    });
    expect(mocks.play).toHaveBeenCalledTimes(1);
    expect(result.current.status).toBe('playing-human');
  });

});
