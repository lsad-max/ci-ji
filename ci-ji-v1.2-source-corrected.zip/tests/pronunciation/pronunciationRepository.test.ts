import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB } from 'idb';
import { openCiJiDb } from '../../src/db/openDb';
import {
  approveCandidate,
  ensureReviewSlotsForWords,
  listPendingWords,
  markAccentMissing,
  rejectCandidate,
} from '../../src/pronunciation/pronunciationRepository';
import { makeCandidate, makeWord } from '../fixtures/pronunciation';

const names: string[] = [];
afterEach(async () => Promise.all(names.splice(0).map((name) => deleteDB(name))));

async function setup() {
  const name = `pronunciation-repo-${crypto.randomUUID()}`;
  names.push(name);
  const db = await openCiJiDb(name);
  const word = makeWord();
  await db.put('words', word);
  return { db, word };
}

describe('pronunciation review repository', () => {
  it('creates two unreviewed slots and groups pending words', async () => {
    const { db, word } = await setup();
    await ensureReviewSlotsForWords(db, [word], { schemaVersion: 1, mappingVersion: 1, generatedAt: '2026-07-11T00:00:00.000Z', words: {} });
    const reviews = await db.getAll('pronunciationReviews');
    expect(reviews).toHaveLength(2);
    expect(reviews.every((item) => item.status === 'unreviewed')).toBe(true);
    expect(await listPendingWords(db)).toMatchObject([{ wordId: word.id, normalizedKey: 'atmosphere' }]);
    db.close();
  });

  it('approves, rejects, and marks accents missing without accepting unknown accents', async () => {
    const { db, word } = await setup();
    const candidate = makeCandidate({ wordId: word.id });
    await db.put('pronunciationCandidates', candidate);
    const approved = await approveCandidate(db, candidate);
    expect(approved.status).toBe('approved');
    expect(approved.selected?.author).toBe('User A');
    await rejectCandidate(db, candidate.id);
    expect((await db.get('pronunciationCandidates', candidate.id))?.rejected).toBe(true);
    const missing = await markAccentMissing(db, word.id, word.normalizedKey, 'en-US');
    expect(missing.status).toBe('missing');
    await expect(approveCandidate(db, { ...candidate, accent: 'unknown' })).rejects.toThrow('地区未标明');
    db.close();
  });
});
