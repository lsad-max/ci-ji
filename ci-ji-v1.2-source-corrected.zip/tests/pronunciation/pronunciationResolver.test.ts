import { describe, expect, it } from 'vitest';
import { resolvePronunciationPlan, type PronunciationDataSource } from '../../src/pronunciation/pronunciationResolver';
import { makeApprovedRecording, makeSettings, makeWord } from '../fixtures/pronunciation';

describe('resolvePronunciationPlan', () => {
  it('never includes American Wikimedia or local audio in a British plan', async () => {
    const source: PronunciationDataSource = {
      getUserReview: async () => undefined,
      getBundled: async (_key, accent) => accent === 'en-GB'
        ? { status: 'missing', accent: 'en-GB' }
        : { status: 'approved', ...makeApprovedRecording({ accent: 'en-US' }) },
    };
    const plan = await resolvePronunciationPlan(
      makeWord({ audioUK: null, audioUS: 'audio/en-US/001-atmosphere.mp3' }),
      'en-GB',
      makeSettings(),
      source,
    );
    expect(plan.steps.map((step) => step.kind)).toEqual(['system']);
    expect(JSON.stringify(plan)).not.toContain('en-US');
  });

  it('lets an unreviewed user slot fall back to bundled approved audio', async () => {
    const recording = makeApprovedRecording();
    const source: PronunciationDataSource = {
      getUserReview: async () => ({
        id: 'w-atmosphere:en-GB', wordId: 'w-atmosphere', normalizedKey: 'atmosphere',
        accent: 'en-GB', status: 'unreviewed', selected: null, origin: 'user',
        reviewedAt: null, updatedAt: '2026-07-11T00:00:00.000Z',
      }),
      getBundled: async () => ({ status: 'approved', ...recording }),
    };
    const plan = await resolvePronunciationPlan(makeWord(), 'en-GB', makeSettings(), source);
    expect(plan.attribution).toMatchObject({ audioUrl: recording.audioUrl, accent: 'en-GB' });
    expect(plan.steps.map((step) => step.kind)).toEqual([
      'wikimedia-cache', 'wikimedia-online', 'local-audio', 'system',
    ]);
  });

  it('honours source preferences without changing the requested accent', async () => {
    const source: PronunciationDataSource = {
      getUserReview: async () => undefined,
      getBundled: async () => ({ status: 'approved', ...makeApprovedRecording() }),
    };
    const localFirst = await resolvePronunciationPlan(
      makeWord(), 'en-GB', makeSettings({ pronunciationSource: 'local-first' }), source,
    );
    expect(localFirst.steps.map((step) => step.kind)).toEqual([
      'local-audio', 'wikimedia-cache', 'wikimedia-online', 'system',
    ]);
    const systemOnly = await resolvePronunciationPlan(
      makeWord(), 'en-GB', makeSettings({ pronunciationSource: 'system-only' }), source,
    );
    expect(systemOnly.steps.map((step) => step.kind)).toEqual(['system']);
  });
});
