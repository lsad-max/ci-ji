import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { RepositoriesProvider } from '../../src/db/RepositoriesContext';
import { createRepositories, type Repositories } from '../../src/db/repositories';
import { PronunciationReviewPage } from '../../src/pronunciation/PronunciationReviewPage';
import { createUnreviewedRecord } from '../../src/pronunciation/pronunciationRepository';
import { makeCandidate, makeWord } from '../fixtures/pronunciation';

const mocks = vi.hoisted(() => ({ search: vi.fn() }));
vi.mock('../../src/pronunciation/wikimediaApi', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../../src/pronunciation/wikimediaApi')>();
  return { ...actual, searchWikimediaCandidates: mocks.search };
});
vi.mock('../../src/speech/speechService', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../../src/speech/speechService')>();
  return { ...actual, playLocalAudio: vi.fn(async () => ({ ok: true as const })), cancelSpeech: vi.fn() };
});

async function renderReviewPage(candidates: ReturnType<typeof makeCandidate>[], words = [makeWord()]) {
  const repos = await createRepositories(`review-page-${crypto.randomUUID()}`);
  for (const word of words) {
    await repos.words.put(word);
    await repos.pronunciationReviews.put(createUnreviewedRecord(word.id, word.normalizedKey, 'en-GB'));
    await repos.pronunciationReviews.put(createUnreviewedRecord(word.id, word.normalizedKey, 'en-US'));
  }
  mocks.search.mockResolvedValue(candidates);
  render(<RepositoriesProvider repositories={repos}><MemoryRouter><PronunciationReviewPage/></MemoryRouter></RepositoriesProvider>);
  return repos;
}

describe('PronunciationReviewPage', () => {
  let repos: Repositories | null = null;
  beforeEach(() => { vi.clearAllMocks(); });
  afterEach(() => { cleanup(); repos?.close(); repos = null; });

  it('does not approve an unknown-accent candidate', async () => {
    repos = await renderReviewPage([makeCandidate({ accent: 'unknown' })]);
    expect(await screen.findByText('地区未标明')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '确认使用' })).toBeDisabled();
  });

  it('approves British and advances to the next word', async () => {
    const words = [makeWord(), makeWord({ id: 'w-climate', normalizedKey: 'climate', word: 'climate' })];
    repos = await renderReviewPage([makeCandidate({ accent: 'en-GB' })], words);
    const approveButton = await screen.findByRole('button', { name: '确认英式并进入下一词' });
    await waitFor(() => expect(approveButton).toBeEnabled());
    fireEvent.click(approveButton);
    expect(await screen.findByText('climate', {}, { timeout: 3000 })).toBeInTheDocument();
  });
  it('approves both accents and advances once', async () => {
    const words = [makeWord(), makeWord({ id: 'w-climate', normalizedKey: 'climate', word: 'climate' })];
    const british = makeCandidate({ accent: 'en-GB' });
    const american = makeCandidate({
      id: 'w-atmosphere:en-US:En-us-atmosphere.ogg',
      accent: 'en-US',
      sourceFileName: 'En-us-atmosphere.ogg',
    });
    repos = await renderReviewPage([british, american], words);
    const approveBothButton = await screen.findByRole('button', { name: '两个口音均确认' });
    await waitFor(() => expect(approveBothButton).toBeEnabled());
    fireEvent.click(approveBothButton);
    expect(await screen.findByText('climate', {}, { timeout: 3000 })).toBeInTheDocument();
    await waitFor(async () => {
      const reviews = await repos?.pronunciationReviews.getByWord('w-atmosphere');
      expect(reviews?.filter((review) => review.status === 'approved')).toHaveLength(2);
    });
  });

});
