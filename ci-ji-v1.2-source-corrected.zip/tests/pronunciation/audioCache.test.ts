import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  cachePronunciation,
  clearPronunciationCache,
  getCachedPronunciation,
  getPronunciationCacheStats,
} from '../../src/pronunciation/audioCache';
import { makeApprovedRecording } from '../fixtures/pronunciation';

class MemoryCache {
  private values = new Map<string, Response>();
  async match(request: Request) { return this.values.get(request.url)?.clone(); }
  async put(request: Request, response: Response) { this.values.set(request.url, response.clone()); }
  async keys() { return [...this.values.keys()].map((url) => new Request(url)); }
}

let memory: MemoryCache;
let originalFetch: typeof fetch;
let originalCaches: CacheStorage | undefined;
let originalCreateObjectURL: typeof URL.createObjectURL;
let originalRevokeObjectURL: typeof URL.revokeObjectURL;

beforeEach(() => {
  memory = new MemoryCache();
  originalFetch = globalThis.fetch;
  originalCaches = globalThis.caches;
  originalCreateObjectURL = URL.createObjectURL;
  originalRevokeObjectURL = URL.revokeObjectURL;
  Object.defineProperty(globalThis, 'caches', {
    configurable: true,
    value: {
      open: vi.fn(async () => memory),
      delete: vi.fn(async () => true),
    },
  });
  URL.createObjectURL = vi.fn(() => 'blob:ci-ji-test');
  URL.revokeObjectURL = vi.fn();
});

afterEach(() => {
  globalThis.fetch = originalFetch;
  Object.defineProperty(globalThis, 'caches', { configurable: true, value: originalCaches });
  URL.createObjectURL = originalCreateObjectURL;
  URL.revokeObjectURL = originalRevokeObjectURL;
  vi.restoreAllMocks();
});

describe('Wikimedia pronunciation cache', () => {
  it('uses mapping version in cache key and returns a blob URL', async () => {
    const record = makeApprovedRecording({ audioUrl: 'https://upload.wikimedia.org/a.ogg', mappingVersion: 3 });
    globalThis.fetch = vi.fn(async () => new Response(new Uint8Array([1, 2, 3]), {
      status: 200,
      headers: { 'content-type': 'audio/ogg', 'content-length': '3' },
    })) as never;
    const cached = await cachePronunciation(record);
    expect(cached.cacheKey).toContain('mapping=3');
    expect(cached.objectUrl.startsWith('blob:')).toBe(true);
    expect(cached.bytes).toBe(3);
    cached.revoke();
    expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:ci-ji-test');
    expect(await getCachedPronunciation(record)).not.toBeNull();
    expect(await getPronunciationCacheStats()).toMatchObject({ entries: 1, bytes: 3 });
    await clearPronunciationCache();
    expect(caches.delete).toHaveBeenCalled();
  });


  it('downloads and keys the browser-compatible URL and accepts application/ogg', async () => {
    const record = makeApprovedRecording({
      audioUrl: 'https://upload.wikimedia.org/raw.ogg',
      compatibleAudioUrl: 'https://upload.wikimedia.org/transcoded.oga',
      mappingVersion: 4,
    });
    globalThis.fetch = vi.fn(async () => new Response(new Uint8Array([4, 5]), {
      status: 200,
      headers: { 'content-type': 'application/ogg', 'content-length': '2' },
    })) as never;
    const cached = await cachePronunciation(record);
    expect(globalThis.fetch).toHaveBeenCalledWith(
      'https://upload.wikimedia.org/transcoded.oga',
      expect.objectContaining({ mode: 'cors', credentials: 'omit' }),
    );
    expect(cached.cacheKey).toContain('transcoded.oga');
    expect(cached.cacheKey).toContain('ci_ji_mapping=4');
    cached.revoke();
  });

  it('rejects non-audio responses', async () => {
    globalThis.fetch = vi.fn(async () => new Response('html', {
      status: 200,
      headers: { 'content-type': 'text/html' },
    })) as never;
    await expect(cachePronunciation(makeApprovedRecording())).rejects.toThrow('不是音频');
  });
});
