import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { AttributionPanel } from '../../src/pronunciation/AttributionPanel';
import { makeApprovedRecording } from '../fixtures/pronunciation';

describe('AttributionPanel', () => {
  it('shows compact Wikimedia attribution and expands details', async () => {
    const recording = makeApprovedRecording();
    render(<AttributionPanel recording={recording} cached />);
    expect(screen.getByRole('button', { name: '真人发音 · Wikimedia' })).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button', { name: '真人发音 · Wikimedia' }));
    expect(screen.getByText('User A')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: '查看 Wikimedia 文件页' })).toHaveAttribute('href', recording.filePageUrl);
    expect(screen.getByText(/已缓存/)).toBeInTheDocument();
  });
});
