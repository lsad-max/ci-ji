import { describe, expect, it } from 'vitest';
import { DEFAULT_SETTINGS } from '../../src/domain/constants';

describe('v1.2 pronunciation baseline', () => {
  it('defaults to Wikimedia-first and silent error UI', () => {
    expect(DEFAULT_SETTINGS.pronunciationSource).toBe('wikimedia-first');
    expect(DEFAULT_SETTINGS.cacheWikimediaAfterPlayback).toBe(true);
    expect(DEFAULT_SETTINGS.speechErrorsEnabled).toBe(false);
  });
});
