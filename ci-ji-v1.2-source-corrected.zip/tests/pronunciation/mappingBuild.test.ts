import { describe, expect, it } from 'vitest';
import { buildMapping, parseReviewCsv, type ReviewRow } from '../../scripts/build-wikimedia-mapping';

const packWith = (words: string[]) => ({ words: words.map((word) => ({ word })) });
const row = (patch: Partial<ReviewRow> = {}): ReviewRow => ({
  word: 'atmosphere', normalizedKey: 'atmosphere', accent: 'en-GB', status: 'missing',
  audioUrl: '', compatibleAudioUrl: '', filePageUrl: '', author: '', licenseName: '', licenseUrl: '',
  sourceFileName: '', durationSeconds: '', reviewedBy: 'reviewer', reviewedAt: '2026-07-12T00:00:00.000Z', notes: '',
  ...patch,
});
const twoRows = (patch: Partial<ReviewRow> = {}) => [
  row({ ...patch, accent: 'en-GB' }),
  row({ ...patch, accent: 'en-US' }),
];

describe('Wikimedia mapping build', () => {
  it('requires exactly two reviewed rows per pack word', () => {
    const rows = [row({ accent: 'en-GB' })];
    expect(() => buildMapping(packWith(['atmosphere']), rows)).toThrow('atmosphere 缺少 en-US 审核结果');
  });

  it('rejects approved rows without author and license', () => {
    expect(() => buildMapping(packWith(['atmosphere']), twoRows({
      status: 'approved', audioUrl: 'https://upload.wikimedia.org/a.ogg',
      filePageUrl: 'https://commons.wikimedia.org/wiki/File:a.ogg', sourceFileName: 'a.ogg', author: '', licenseName: '',
    }))).toThrow('授权字段不完整');
  });

  it('sorts keys and increments mapping version', () => {
    const rows = [...twoRows({ word: 'drought', normalizedKey: 'drought' }), ...twoRows()];
    const result = buildMapping(packWith(['drought', 'atmosphere']), rows, 4, '2026-07-12T00:00:00.000Z');
    expect(Object.keys(result.words)).toEqual(['atmosphere', 'drought']);
    expect(result.mappingVersion).toBe(5);
  });

  it('parses quoted CSV fields', () => {
    const header = 'word,normalizedKey,accent,status,audioUrl,compatibleAudioUrl,filePageUrl,author,licenseName,licenseUrl,sourceFileName,durationSeconds,reviewedBy,reviewedAt,notes';
    const parsed = parseReviewCsv(`${header}\natmosphere,atmosphere,en-GB,missing,,,,,,,,,reviewer,2026-07-12T00:00:00.000Z,"checked, no approval"\n`);
    expect(parsed[0]?.notes).toBe('checked, no approval');
  });
});
