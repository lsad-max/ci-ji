import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import { DownloadPackAudioButton } from '../../src/pronunciation/DownloadPackAudioButton';
import { makeApprovedRecording, makeSettings, makeWord } from '../fixtures/pronunciation';

const mocks=vi.hoisted(()=>({resolve:vi.fn(),download:vi.fn()}));
vi.mock('../../src/settings/SettingsProvider',()=>({useSettings:()=>({settings:makeSettings()})}));
vi.mock('../../src/db/RepositoriesContext',()=>({useRepositories:()=>({pronunciationReviews:{get:vi.fn()}})}));
vi.mock('../../src/pronunciation/pronunciationResolver',()=>({resolvePronunciationPlan:mocks.resolve}));
vi.mock('../../src/pronunciation/bundledMapping',()=>({getBundledPronunciation:vi.fn()}));
vi.mock('../../src/pronunciation/audioCache',()=>({
  downloadPronunciations:mocks.download,
}));

describe('DownloadPackAudioButton',()=>{
  it('shows downloadable, missing, estimated bytes and final report',async()=>{
    const first=makeApprovedRecording();
    const second=makeApprovedRecording({
      audioUrl:'https://upload.wikimedia.org/example/climate.ogg',
      sourceFileName:'climate.ogg',
      filePageUrl:'https://commons.wikimedia.org/wiki/File:climate.ogg',
    });
    let calls=0;
    mocks.resolve.mockImplementation(async()=>({
      word:'x',accent:'en-GB',steps:[],
      attribution:++calls===1?first:calls===2?second:null,
    }));
    mocks.download.mockReturnValue({pause:vi.fn(),resume:vi.fn(),cancel:vi.fn(),result:Promise.resolve({success:2,failed:0,skipped:0,bytes:20})});
    const words=[makeWord(),makeWord({id:'w2',normalizedKey:'climate',word:'climate'}),makeWord({id:'w3',normalizedKey:'drought',word:'drought'})];
    const pack={id:'p',schemaVersion:1 as const,date:'2026-07-11' as const,theme:'t',wordCount:3,createdAt:'2026-07-11T00:00:00.000Z',notes:'',wordIds:words.map(w=>w.id),categories:[]};
    render(<DownloadPackAudioButton pack={pack} words={words}/>);
    await userEvent.click(screen.getByRole('button',{name:'下载今日真人发音'}));
    expect(await screen.findByText('可下载真人录音：2条')).toBeInTheDocument();
    expect(screen.getByText('缺少真人录音：1条')).toBeInTheDocument();
    await userEvent.click(screen.getByRole('button',{name:'开始下载'}));
    expect(await screen.findByText(/成功 2/)).toBeInTheDocument();
  });
});
