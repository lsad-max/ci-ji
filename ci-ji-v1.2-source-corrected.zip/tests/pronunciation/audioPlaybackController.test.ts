import { describe, expect, it, vi } from 'vitest';
import {
  playPronunciation,
  type PlaybackDependencies,
  type PronunciationPlan,
} from '../../src/pronunciation/audioPlaybackController';
import { makeApprovedRecording } from '../fixtures/pronunciation';

describe('playPronunciation', () => {
  it('falls from Wikimedia failure to same-accent local audio', async () => {
    const recording = makeApprovedRecording();
    const plan: PronunciationPlan = {
      word: 'atmosphere', accent: 'en-GB', attribution: recording,
      steps: [
        { kind: 'wikimedia-online', recording, timeoutMs: 6000 },
        { kind: 'local-audio', url: 'audio/en-GB/a.mp3', accent: 'en-GB', timeoutMs: 4000 },
        { kind: 'system', accent: 'en-GB', timeoutMs: 3000 },
      ],
    };
    const dependencies: PlaybackDependencies = {
      getCached: vi.fn(async () => null),
      playRemote: vi.fn(async () => ({ ok: false as const, reason: 'playback-failed' as const })),
      playLocal: vi.fn(async () => ({ ok: true as const })),
      playSystem: vi.fn(async () => ({ ok: true as const, voiceName: 'British Voice' })),
      cacheRemote: vi.fn(async () => undefined),
    };
    const result = await playPronunciation(plan, { rate: 1, cacheAfterPlayback: true }, dependencies);
    expect(result).toMatchObject({ ok: true, source: 'local-audio', accent: 'en-GB' });
    expect(dependencies.playSystem).not.toHaveBeenCalled();
  });


  it('tries the same-accent local fallback when user-initiated remote playback is autoplay-blocked', async () => {
    const recording = makeApprovedRecording();
    const plan: PronunciationPlan = {
      word: 'atmosphere', accent: 'en-GB', attribution: recording,
      steps: [
        { kind: 'wikimedia-online', recording, timeoutMs: 6000 },
        { kind: 'local-audio', url: 'audio/en-GB/a.mp3', accent: 'en-GB', timeoutMs: 4000 },
      ],
    };
    const dependencies: PlaybackDependencies = {
      getCached: vi.fn(async () => null),
      playRemote: vi.fn(async () => ({ ok: false as const, reason: 'autoplay-blocked' as const })),
      playLocal: vi.fn(async () => ({ ok: true as const })),
      playSystem: vi.fn(async () => ({ ok: true as const })),
      cacheRemote: vi.fn(async () => undefined),
    };
    const result = await playPronunciation(
      plan,
      { rate: 1, cacheAfterPlayback: true, userInitiated: true },
      dependencies,
    );
    expect(result).toMatchObject({ ok: true, source: 'local-audio' });
    expect(dependencies.playLocal).toHaveBeenCalledOnce();
  });

  it('stops instead of degrading when the active request is cancelled', async () => {
    const recording = makeApprovedRecording();
    const plan: PronunciationPlan = {
      word: 'atmosphere', accent: 'en-GB', attribution: recording,
      steps: [
        { kind: 'wikimedia-online', recording, timeoutMs: 6000 },
        { kind: 'local-audio', url: 'audio/en-GB/a.mp3', accent: 'en-GB', timeoutMs: 4000 },
      ],
    };
    const dependencies: PlaybackDependencies = {
      getCached: vi.fn(async () => null),
      playRemote: vi.fn(async (_recording, _rate, signal) => {
        await new Promise<void>((resolve) => signal.addEventListener('abort', () => resolve(), { once: true }));
        return { ok: false as const, reason: 'cancelled' as const };
      }),
      playLocal: vi.fn(async () => ({ ok: true as const })),
      playSystem: vi.fn(async () => ({ ok: true as const })),
      cacheRemote: vi.fn(async () => undefined),
    };
    const first = playPronunciation(plan, { rate: 1, cacheAfterPlayback: true }, dependencies);
    const second = playPronunciation({ ...plan, steps: [] }, { rate: 1, cacheAfterPlayback: true }, dependencies);
    await second;
    await expect(first).resolves.toEqual({ ok: false, reason: 'cancelled' });
    expect(dependencies.playLocal).not.toHaveBeenCalled();
  });
});
