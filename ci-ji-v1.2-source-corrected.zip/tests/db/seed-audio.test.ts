import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { parsePackJson } from '../../src/packs/parsePack';

describe('bundled dual-accent audio', () => {
  it('links every seed word to existing British and American MP3 files', () => {
    const packPath = resolve(process.cwd(), 'public/packs/2026-07-11-自然地理与环境-131词.json');
    const result = parsePackJson(readFileSync(packPath, 'utf8'));
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.pack.words).toHaveLength(131);
    for (const word of result.pack.words) {
      expect(word.audioUK).toMatch(/^audio\/en-GB\/.+\.mp3$/);
      expect(word.audioUS).toMatch(/^audio\/en-US\/.+\.mp3$/);
      expect(existsSync(resolve(process.cwd(), 'public', word.audioUK!))).toBe(true);
      expect(existsSync(resolve(process.cwd(), 'public', word.audioUS!))).toBe(true);
    }
  });
});
