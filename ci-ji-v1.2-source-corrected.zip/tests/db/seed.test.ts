import { afterEach, describe, expect, it, vi } from 'vitest';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { deleteDB } from 'idb';
import { parsePackJson } from '../../src/packs/parsePack';
import { normalizeWordKey } from '../../src/domain/normalize';
import { createRepositories, type Repositories } from '../../src/db/repositories';
import { ensureBundledSeedImported } from '../../src/db/seed';
import { makeWord } from '../fixtures/pronunciation';

const path = resolve(process.cwd(), 'public/packs/2026-07-11-自然地理与环境-131词.json');
const dbNames: string[] = [];
const reposList: Repositories[] = [];
afterEach(async () => {
  vi.restoreAllMocks();
  reposList.splice(0).forEach((repos) => repos.close());
  await Promise.all(dbNames.splice(0).map((name) => deleteDB(name)));
});

describe('bundled seed pack', () => {
  it('contains 131 unique validated words in source order', async () => {
    const result = parsePackJson(await readFile(path, 'utf8'));
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    const pack = result.pack;
    expect(pack.schemaVersion).toBe(1);
    expect(pack.date).toBe('2026-07-11');
    expect(pack.theme).toBe('自然地理与环境');
    expect(pack.wordCount).toBe(131);
    expect(pack.words).toHaveLength(131);
    expect(new Set(pack.words.map((item) => normalizeWordKey(item.word))).size).toBe(131);
    expect(pack.words[0].word).toBe('atmosphere');
    expect(pack.words.at(-1)?.word).toBe('upgrade');
    for (const word of pack.words) {
      expect(word.categories.length).toBeGreaterThan(0);
      expect(word.partOfSpeech.length).toBeGreaterThan(0);
      expect(word.meanings.length).toBeGreaterThan(0);
      expect(word.phoneticUK).toBeTruthy();
    }
  });

  it('imports once and marks the seed only after success', async () => {
    const text = await readFile(path, 'utf8');
    vi.stubGlobal('fetch', vi.fn(async () => new Response(text, { status: 200 })));
    const name = `seed-${crypto.randomUUID()}`; dbNames.push(name);
    const repos = await createRepositories(name); reposList.push(repos);
    await expect(ensureBundledSeedImported(repos)).resolves.toBe('imported');
    expect(await repos.db.count('words')).toBe(131);
    await expect(ensureBundledSeedImported(repos)).resolves.toBe('already-present');
    expect(await repos.db.count('packs')).toBe(1);
  });

  it('creates pronunciation review slots for an existing v1.1 seed', async () => {
    const name = `seed-upgrade-${crypto.randomUUID()}`; dbNames.push(name);
    const repos = await createRepositories(name); reposList.push(repos);
    const word = makeWord();
    await repos.words.put(word);
    await repos.db.put('meta', { key: 'seed:2026-07-11:v2-dual-audio', value: true });
    await expect(ensureBundledSeedImported(repos)).resolves.toBe('already-present');
    const reviews = await repos.pronunciationReviews.getByWord(word.id);
    expect(reviews).toHaveLength(2);
    expect(reviews.every((review) => review.status === 'unreviewed')).toBe(true);
  });

});
