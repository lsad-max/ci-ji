import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB } from 'idb';
import { createRepositories, type Repositories } from '../../src/db/repositories';
import { DEFAULT_SETTINGS } from '../../src/domain/constants';
import type { WordEntry } from '../../src/domain/models';

const names: string[] = [];
const openRepos: Repositories[] = [];
const nextName = () => { const name = `ci-ji-test-${crypto.randomUUID()}`; names.push(name); return name; };
afterEach(async () => {
  openRepos.splice(0).forEach((repos) => repos.close());
  await Promise.all(names.splice(0).map((name) => deleteDB(name)));
});

describe('IndexedDB repositories', () => {
  it('stores a word and resolves it by normalized key', async () => {
    const repos = await createRepositories(nextName());
    openRepos.push(repos);
    const word: WordEntry = {
      id: 'word-atmosphere', normalizedKey: 'atmosphere', word: 'atmosphere',
      phoneticUK: '/ˈætməsfɪə/', phoneticUS: null, partOfSpeech: ['n.'],
      meanings: ['大气', '大气层'], supplementaryMeanings: [], categories: ['地球结构与圈层'],
      phrases: [], examples: [], confusables: [], audioUK: null, audioUS: null,
      appearedDates: ['2026-07-11'], occurrenceCount: 1,
      createdAt: '2026-07-11T00:00:00.000Z', updatedAt: '2026-07-11T00:00:00.000Z',
    };
    await repos.words.put(word);
    expect((await repos.words.getByNormalizedKey('atmosphere'))?.id).toBe(word.id);
    expect((await repos.words.getMany([word.id, 'missing'])).map((entry) => entry.id)).toEqual([word.id]);
  });

  it('creates default settings exactly once', async () => {
    const repos = await createRepositories(nextName());
    openRepos.push(repos);
    expect(await repos.settings.get()).toEqual(DEFAULT_SETTINGS);
    await repos.settings.patch({ theme: 'dark' });
    expect((await repos.settings.get()).theme).toBe('dark');
  });

  it('returns review states due on or before a local date', async () => {
    const repos = await createRepositories(nextName());
    openRepos.push(repos);
    await repos.studyStates.put({
      wordId: 'a', status: 'fuzzy', consecutiveKnown: 0, nextReviewDate: '2026-07-11',
      lastStudiedAt: null, knownCount: 0, fuzzyCount: 1, unknownCount: 0,
    });
    await repos.studyStates.put({
      wordId: 'b', status: 'known', consecutiveKnown: 1, nextReviewDate: '2026-07-20',
      lastStudiedAt: null, knownCount: 1, fuzzyCount: 0, unknownCount: 0,
    });
    expect((await repos.studyStates.getDue('2026-07-12')).map((state) => state.wordId)).toEqual(['a']);
  });
});
