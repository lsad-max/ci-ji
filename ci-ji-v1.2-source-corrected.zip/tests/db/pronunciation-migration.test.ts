import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB, openDB } from 'idb';
import { openCiJiDb } from '../../src/db/openDb';

const names: string[] = [];
afterEach(async () => Promise.all(names.splice(0).map((name) => deleteDB(name))));

describe('DB v2 pronunciation migration', () => {
  it('adds pronunciation stores without removing v1 words', async () => {
    const name = `migration-${crypto.randomUUID()}`;
    names.push(name);
    const v1 = await openDB(name, 1, {
      upgrade(db) {
        const words = db.createObjectStore('words', { keyPath: 'id' });
        words.createIndex('by-normalized', 'normalizedKey', { unique: true });
        words.createIndex('by-updated', 'updatedAt');
        db.createObjectStore('settings', { keyPath: 'id' });
      },
    });
    await v1.put('words', { id: 'w1', normalizedKey: 'atmosphere', word: 'atmosphere', updatedAt: '2026-07-11T00:00:00Z' });
    v1.close();

    const upgraded = await openCiJiDb(name);
    expect(upgraded.objectStoreNames.contains('pronunciationReviews')).toBe(true);
    expect(upgraded.objectStoreNames.contains('pronunciationCandidates')).toBe(true);
    expect((await upgraded.get('words', 'w1'))?.word).toBe('atmosphere');
    upgraded.close();
  });
});
