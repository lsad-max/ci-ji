# 部署到 Vercel

这是纯前端静态 PWA，不需要数据库服务器。

1. 将项目推送到 GitHub。
2. 在 Vercel 新建项目并选择仓库。
3. Framework Preset 选择 **Vite**。
4. Build Command：`npm run build`。
5. Output Directory：`dist`。
6. 部署完成后，用 HTTPS 地址打开并安装到主屏幕。

也可使用 Vercel CLI：

```bash
npm ci
npm run build
npx vercel --prod
```

Vercel 只托管 `dist` 中的应用文件。IndexedDB 仍位于每个用户自己的浏览器中，部署不会上传或同步词库数据。发布新版本时，Service Worker 会提示“发现新版本”；更新应用代码不会清空本地学习记录。
