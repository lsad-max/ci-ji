# 每日词包格式

## 文件与版本

- 扩展名：`.json`
- 编码：UTF-8
- 当前 `schemaVersion`：`1`
- 推荐文件名：`YYYY-MM-DD-主题-数量词.json`
- 日期使用设备本地日历日期，不进行 UTC 换日。

## 完整有效示例

```json
{
  "schemaVersion": 1,
  "date": "2026-07-11",
  "theme": "自然地理与环境",
  "wordCount": 1,
  "createdAt": "2026-07-11T08:00:00+08:00",
  "notes": "经过人工校对",
  "words": [
    {
      "word": "atmosphere",
      "phoneticUK": "/ˈætməsfɪə/",
      "phoneticUS": "/ˈætməsfɪr/",
      "partOfSpeech": ["n."],
      "meanings": ["大气", "大气层"],
      "supplementaryMeanings": [],
      "categories": ["地球结构与圈层"],
      "phrases": [
        { "en": "the Earth's atmosphere", "zh": "地球大气层" }
      ],
      "examples": [
        { "en": "The atmosphere protects the Earth.", "zh": "大气层保护着地球。" }
      ],
      "confusables": ["environment"],
      "audioUK": null,
      "audioUS": null
    }
  ]
}
```

## 字段语义

| 字段 | 必填 | 说明 |
|---|---:|---|
| `schemaVersion` | 是 | 当前只能为数字 `1` |
| `date` | 是 | `YYYY-MM-DD` |
| `theme` | 是 | 每日词包主主题 |
| `wordCount` | 是 | 必须等于 `words.length` |
| `createdAt` | 否 | ISO 8601 时间；缺失时由解析器补充 |
| `notes` | 否 | 词包备注；默认空字符串 |
| `word` | 是 | 英文单词或短语，去除首尾空格 |
| `phoneticUK/US` | 否 | 字符串或 `null`，不得用猜测值填充 |
| `partOfSpeech` | 否 | 词性数组，如 `['n.', 'v.']` |
| `meanings` | 是 | 至少一个核心中文释义 |
| `supplementaryMeanings` | 否 | 翻面后“更多内容”中的补充义项 |
| `categories` | 否 | 可有多个细分类别 |
| `phrases/examples` | 否 | `{ en, zh }` 数组，两项均不能为空 |
| `confusables` | 否 | 易混词数组 |
| `audioUK/US` | 否 | 独立音频 URL；缺失时使用系统语音 |

所有未填写的数组字段必须写为 `[]`；音标与音频可写 `null`。

## 重复与冲突

英文在比较前会：去除首尾空格、忽略大小写、统一弯引号、合并连续空格。不同词形不会自动合并，例如 `pollute` 与 `pollution` 是两个主词条。

- 完全一致：仅关联新日期；
- 新内容更丰富：补充缺失字段；
- 音标、词性或核心义项冲突：在预览中选择合并、保留旧内容、使用新内容或跳过；
- 导入失败：整批事务回滚，不留下半批数据。

高于当前支持版本的词包会被拒绝，且不会写入数据。
