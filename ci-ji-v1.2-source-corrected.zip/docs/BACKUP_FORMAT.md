# 完整备份格式

## 文件名与版本

无独立 Blob 音频时，导出文件名为 `词迹完整备份-YYYY-MM-DD.json`。当前备份 `schemaVersion` 为 `1`。未来若需要嵌入本地音频，备份可升级为 ZIP，根目录必须包含 `backup.json`。

## 完整有效最小示例

```json
{
  "schemaVersion": 1,
  "app": "词迹",
  "exportedAt": "2026-07-11T10:00:00.000Z",
  "localDate": "2026-07-11",
  "data": {
    "words": [],
    "packs": [],
    "studyStates": [],
    "studyEvents": [],
    "sessions": [],
    "settings": {
      "id": "singleton",
      "direction": "en-zh",
      "showPhonetic": true,
      "gesturesEnabled": false,
      "defaultOrder": "source",
      "fontSize": "medium",
      "accent": "en-GB",
      "speechRate": 0.85,
      "autoSpeakCards": true,
      "autoSpeakImmersive": true,
      "theme": "light",
      "immersiveDensity": "comfortable",
      "onboardingSeen": true,
      "gestureHintSeen": false
    },
    "imports": [],
    "trash": []
  }
}
```

## 数据组

- `words`：主词条与出现日期；
- `packs`：每日词包、主题、原始顺序；
- `studyStates`：当前掌握状态、计数和下次复习日期；
- `studyEvents`：每一次评价的不可变历史；
- `sessions`：中途退出后的队列、游标和撤销信息；
- `settings`：口音、速度、主题、字号等偏好；
- `imports`：词包导入报告；
- `trash`：30 天回收站及原词包位置。

## 恢复模式

### 合并恢复

保留当前数据。重复词按规范化英文合并，词包日期、义项、分类、学习事件和掌握计数取并集；备份预览不会修改数据库。

### 完全恢复

1. 完整验证备份；
2. 在内存中读取当前全部数据作为安全快照；
3. 一个事务清空并写入备份；
4. 写入失败时用第二个事务恢复安全快照；
5. 只有写入成功才报告恢复完成。

完全恢复和清空操作必须输入 `确认清空`。高于当前支持版本、损坏或字段缺失的备份不会产生任何写入。
