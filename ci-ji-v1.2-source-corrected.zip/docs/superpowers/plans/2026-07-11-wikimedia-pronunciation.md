# 词迹 v1.2 Wikimedia 真人发音 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 为“词迹”增加经过审核的 Wikimedia Commons / Wiktionary 真人录音、集中审核、离线缓存和完整署名能力，并保留本地合成音频与系统语音的可靠降级链路。

**Architecture:** 在现有 React/Vite PWA 上新增独立的 `pronunciation` 模块。内置 131 词映射保存在静态 JSON，用户审核结果保存在 IndexedDB，音频响应保存在 Cache Storage；`PronunciationResolver` 只负责选择来源，`AudioPlaybackController` 只负责播放、取消、超时和降级。Wikimedia 查询仅生成候选，未经审核的候选永不进入正式学习播放链路。

**Tech Stack:** React 19、TypeScript 7、Vite 8、Vitest 4、Testing Library、Playwright、IndexedDB（idb）、Cache Storage、MediaWiki Action API、Vite PWA/Workbox。

## Global Constraints

- 正式播放顺序必须是：已缓存 Wikimedia 真人录音 → 在线 Wikimedia 真人录音 → 当前口音的本地合成音频 → 当前口音的系统语音 → “发音暂不可用”。
- 英式和美式录音独立审核；缺少某一口音时不得借用另一口音冒充。
- 未审核候选不得自动用于卡片、词库、沉浸模式或自动朗读。
- 当前 131 词必须使用固定审核映射；新增词先导入，再进入“词库 → 待审核发音”。
- 真人录音首次成功播放后自动缓存；支持手动下载今日词包已审核录音。
- 每条已批准录音必须包含作者、许可证名称、来源文件页和可播放 URL。
- 发音失败提示默认关闭；关闭时只更新按钮状态，不弹窗打断学习。
- 清理真人录音缓存不得删除词库、词包、学习记录、复习计划或审核结果。
- 保留 v1.1 的 `audioUK` / `audioUS` 作为本地合成音频兜底，不自动删除。
- 首次升级必须保留现有 IndexedDB 数据；数据库升级失败不得破坏旧库。
- Wikimedia API 请求使用匿名 CORS，附带 `origin=*`，不引入 API 密钥或后台服务。
- `extmetadata` 返回的 HTML 文本必须去标签后再进入 UI，禁止使用 `dangerouslySetInnerHTML`。
- 同一时刻最多播放一个单词；新点击必须终止上一音频、上一系统语音和上一网络请求。
- 版本号更新为 `1.2.0`，预览部署必须使用独立 base path 和独立 Workbox cacheId。

---

## File Map

### New files

- `src/pronunciation/types.ts` — 真人录音、候选、审核状态、播放来源的公共类型。
- `src/pronunciation/mappingSchema.ts` — 内置映射 JSON 的 Zod 校验和加载。
- `src/pronunciation/bundledMapping.ts` — 按 normalizedKey/口音读取 131 词内置映射。
- `src/pronunciation/wikimediaApi.ts` — Wiktionary/Commons 查询、元数据解析和候选排序。
- `src/pronunciation/pronunciationRepository.ts` — IndexedDB 审核记录与候选记录读写。
- `src/pronunciation/pronunciationResolver.ts` — 按设置、口音和审核状态解析正式播放计划。
- `src/pronunciation/audioCache.ts` — Cache Storage 读写、批量下载、统计和清理。
- `src/pronunciation/audioPlaybackController.ts` — 单实例播放、超时、取消与降级。
- `src/pronunciation/AttributionPanel.tsx` — 作者、许可证、来源页和缓存状态展示。
- `src/pronunciation/PronunciationReviewPage.tsx` — 待审核发音集中处理页面。
- `src/pronunciation/PronunciationReviewCard.tsx` — 单词的英式/美式候选试听与确认。
- `src/pronunciation/DownloadPackAudioButton.tsx` — 今日词包真人录音统计与下载控制。
- `src/pronunciation/pronunciation.css` — 审核页、署名面板和下载进度样式。
- `public/data/wikimedia-pronunciations.json` — 当前 131 词固定审核映射。
- `scripts/discover-wikimedia-pronunciations.ts` — 批量发现 131 词候选。
- `scripts/build-wikimedia-mapping.ts` — 将人工审核 CSV 构建为正式映射 JSON。
- `scripts/validate-wikimedia-mapping.ts` — 校验映射覆盖、授权字段和重复项。
- `docs/pronunciation/wikimedia-review.csv` — 131 词双口音人工审核工作表。
- `docs/pronunciation/README.md` — 审核规则、字段说明和更新流程。
- `tests/fixtures/pronunciation.ts` — 测试用单词、候选、正式录音和设置构造器。
- `tests/pronunciation/*.test.ts(x)` — 新模块单元与组件测试。
- `e2e/pronunciation.spec.ts` — 真人播放、降级、审核、缓存和离线端到端测试。

### Existing files to modify

- `package.json` — 版本号和映射脚本。
- `src/domain/models.ts` — 新设置与发音记录类型引用。
- `src/domain/constants.ts` — v1.2 默认设置。
- `src/db/schema.ts` — 两个发音对象仓库。
- `src/db/openDb.ts` — DB_VERSION 2 升级。
- `src/db/repositories.ts` — 发音记录与候选仓库接口。
- `src/backup/backupSchema.ts` — v1/v2 备份兼容。
- `src/backup/exportBackup.ts` — 导出用户审核结果。
- `src/backup/restoreBackup.ts` — 恢复用户审核结果。
- `src/packs/commitImport.ts` — 新词写入后建立待审核记录。
- `src/library/WordEditor.tsx` — 手动新增词建立待审核记录。
- `src/library/LibraryPage.tsx` — 待审核入口、计数和真人录音筛选。
- `src/library/libraryQueries.ts` — 真人录音筛选语义。
- `src/app/routes.tsx` — `/library/pronunciation-review` 路由。
- `src/app/AppShell.tsx` — 审核页保留底部导航。
- `src/speech/speechService.ts` — 将底层系统语音和本地音频函数暴露给控制器。
- `src/speech/useSpeech.ts` — 调用 resolver/controller，暴露播放状态和署名。
- `src/speech/SpeechButton.tsx` — 加载/真人/备用/不可用状态。
- `src/cards/StudyCard.tsx` — 展示简洁来源和展开署名。
- `src/immersive/ImmersiveRow.tsx` — 展示当前真人来源状态。
- `src/settings/SettingsPage.tsx` — 发音来源、缓存管理和默认关闭失败提示。
- `src/home/HomePage.tsx` — 今日词包真人录音下载入口。
- `vite.config.ts` — 缓存策略、静态映射和运行时音频缓存排除。
- `RELEASE_CHECKLIST.md` — Mate X7 实机验收。

---

### Task 1: 锁定 v1.1 基线并建立 v1.2 测试护栏

**Files:**
- Modify: `package.json`
- Create: `tests/fixtures/pronunciation.ts`
- Create: `tests/pronunciation/baseline.test.ts`
- Modify: `RELEASE_CHECKLIST.md`

**Interfaces:**
- Consumes: 当前 `speakWord(word, options)`、`createRepositories(dbName)`、`DEFAULT_SETTINGS`。
- Produces: v1.2 版本标识和一组防止旧学习数据被破坏的基线测试。

- [ ] **Step 1: 将包版本改为 1.2.0，并增加映射脚本命令**

```json
{
  "version": "1.2.0",
  "scripts": {
    "discover:pronunciations": "tsx scripts/discover-wikimedia-pronunciations.ts",
    "build:pronunciations": "tsx scripts/build-wikimedia-mapping.ts",
    "validate:pronunciations": "tsx scripts/validate-wikimedia-mapping.ts"
  }
}
```

只合并上述字段，不删除现有 scripts。

- [ ] **Step 2: 创建共享测试构造器**

```ts
// tests/fixtures/pronunciation.ts
import { DEFAULT_SETTINGS } from '../../src/domain/constants';
import type { AppSettings, WordEntry } from '../../src/domain/models';
import type { ApprovedPronunciation, PronunciationCandidateRecord } from '../../src/pronunciation/types';

export const makeWord = (patch: Partial<WordEntry> = {}): WordEntry => ({
  id: 'w-atmosphere', normalizedKey: 'atmosphere', word: 'atmosphere',
  phoneticUK: '/ˈætməsfɪə/', phoneticUS: '/ˈætməsfɪr/', partOfSpeech: ['n.'],
  meanings: ['大气；气氛'], supplementaryMeanings: [], categories: ['自然地理'],
  phrases: [], examples: [], confusables: [],
  audioUK: 'audio/en-GB/001-atmosphere.mp3',
  audioUS: 'audio/en-US/001-atmosphere.mp3',
  appearedDates: ['2026-07-11'], occurrenceCount: 1,
  createdAt: '2026-07-11T00:00:00.000Z', updatedAt: '2026-07-11T00:00:00.000Z',
  ...patch,
});

export const makeSettings = (patch: Partial<AppSettings> = {}): AppSettings => ({
  ...structuredClone(DEFAULT_SETTINGS),
  onboardingSeen: true,
  ...patch,
});

export const makeApprovedRecording = (patch: Partial<ApprovedPronunciation> = {}): ApprovedPronunciation => ({
  accent: 'en-GB',
  audioUrl: 'https://upload.wikimedia.org/example/atmosphere.ogg',
  compatibleAudioUrl: null,
  filePageUrl: 'https://commons.wikimedia.org/wiki/File:En-uk-atmosphere.ogg',
  author: 'User A', licenseName: 'CC BY-SA 4.0',
  licenseUrl: 'https://creativecommons.org/licenses/by-sa/4.0/',
  sourceFileName: 'En-uk-atmosphere.ogg', durationSeconds: 1.2, mappingVersion: 1,
  ...patch,
});

export const makeCandidate = (patch: Partial<PronunciationCandidateRecord> = {}): PronunciationCandidateRecord => ({
  id: 'w-atmosphere:en-GB:En-uk-atmosphere.ogg',
  wordId: 'w-atmosphere', normalizedKey: 'atmosphere', accent: 'en-GB',
  audioUrl: 'https://upload.wikimedia.org/example/atmosphere.ogg', compatibleAudioUrl: null,
  filePageUrl: 'https://commons.wikimedia.org/wiki/File:En-uk-atmosphere.ogg',
  sourceFileName: 'En-uk-atmosphere.ogg', author: 'User A',
  licenseName: 'CC BY-SA 4.0', licenseUrl: 'https://creativecommons.org/licenses/by-sa/4.0/',
  durationSeconds: 1.2, source: 'wiktionary', rank: 1, rejected: false,
  fetchedAt: '2026-07-11T00:00:00.000Z',
  ...patch,
});
```

- [ ] **Step 3: 写入失败的基线测试**

```ts
// tests/pronunciation/baseline.test.ts
import { describe, expect, it } from 'vitest';
import { DEFAULT_SETTINGS } from '../../src/domain/constants';

// 这些断言会先失败，直到 Task 2 完成。
describe('v1.2 pronunciation baseline', () => {
  it('defaults to Wikimedia-first and silent error UI', () => {
    expect(DEFAULT_SETTINGS.pronunciationSource).toBe('wikimedia-first');
    expect(DEFAULT_SETTINGS.cacheWikimediaAfterPlayback).toBe(true);
    expect(DEFAULT_SETTINGS.speechErrorsEnabled).toBe(false);
  });
});
```

- [ ] **Step 4: 运行测试并确认失败**

Run: `npm test -- tests/pronunciation/baseline.test.ts`

Expected: FAIL，提示 `pronunciationSource` 或 `cacheWikimediaAfterPlayback` 不存在。

- [ ] **Step 5: 在发布清单加入实机门槛**

```markdown
## v1.2 真人发音门槛
- [ ] Mate X7 / HarmonyOS 6 / Chrome 点击已批准录音可听见真人发音
- [ ] 断开网络后已缓存录音仍可播放
- [ ] 真人录音失败时切换到同口音本地音频
- [ ] 不存在同口音本地音频时再尝试同口音系统语音
- [ ] 英式缺失时不播放美式真人录音，反之亦然
- [ ] 每条已批准录音可查看作者、许可证和 Commons 文件页
```

- [ ] **Step 6: 提交**

```bash
git add package.json tests/fixtures/pronunciation.ts tests/pronunciation/baseline.test.ts RELEASE_CHECKLIST.md
git commit -m "test: establish v1.2 pronunciation baseline"
```

---

### Task 2: 定义发音领域模型、设置项和 IndexedDB v2 迁移

**Files:**
- Create: `src/pronunciation/types.ts`
- Modify: `src/domain/models.ts`
- Modify: `src/domain/constants.ts`
- Modify: `src/db/schema.ts`
- Modify: `src/db/openDb.ts`
- Modify: `src/db/repositories.ts`
- Test: `tests/db/pronunciation-migration.test.ts`
- Test: `tests/pronunciation/baseline.test.ts`

**Interfaces:**
- Produces:
  - `PronunciationAccent = 'en-GB' | 'en-US' | 'unknown'`
  - `PronunciationReviewRecord`
  - `PronunciationCandidateRecord`
  - `PronunciationSourcePreference`
  - `repositories.pronunciationReviews`
  - `repositories.pronunciationCandidates`

- [ ] **Step 1: 写数据库升级失败测试**

```ts
// tests/db/pronunciation-migration.test.ts
import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB, openDB } from 'idb';
import { openCiJiDb } from '../../src/db/openDb';

const names: string[] = [];
afterEach(async () => Promise.all(names.splice(0).map((name) => deleteDB(name))));

describe('DB v2 pronunciation migration', () => {
  it('adds pronunciation stores without removing v1 words', async () => {
    const name = `migration-${crypto.randomUUID()}`;
    names.push(name);
    const v1 = await openDB(name, 1, {
      upgrade(db) {
        const words = db.createObjectStore('words', { keyPath: 'id' });
        words.createIndex('by-normalized', 'normalizedKey', { unique: true });
        words.createIndex('by-updated', 'updatedAt');
        db.createObjectStore('settings', { keyPath: 'id' });
      },
    });
    await v1.put('words', { id: 'w1', normalizedKey: 'atmosphere', word: 'atmosphere', updatedAt: '2026-07-11T00:00:00Z' });
    v1.close();

    const upgraded = await openCiJiDb(name);
    expect(upgraded.objectStoreNames.contains('pronunciationReviews')).toBe(true);
    expect(upgraded.objectStoreNames.contains('pronunciationCandidates')).toBe(true);
    expect((await upgraded.get('words', 'w1'))?.word).toBe('atmosphere');
    upgraded.close();
  });
});
```

- [ ] **Step 2: 运行迁移测试并确认失败**

Run: `npm test -- tests/db/pronunciation-migration.test.ts`

Expected: FAIL，数据库没有 `pronunciationReviews`。

- [ ] **Step 3: 创建发音公共类型**

```ts
// src/pronunciation/types.ts
import type { Accent } from '../domain/models';

export type PronunciationAccent = Accent | 'unknown';
export type PronunciationStatus = 'unreviewed' | 'approved' | 'rejected' | 'missing';
export type PronunciationSourcePreference = 'wikimedia-first' | 'local-first' | 'system-only';
export type PronunciationOrigin = 'bundled' | 'user';

export interface PronunciationAttribution {
  author: string;
  licenseName: string;
  licenseUrl: string | null;
  filePageUrl: string;
  sourceFileName: string;
}

export interface ApprovedPronunciation extends PronunciationAttribution {
  accent: Accent;
  audioUrl: string;
  compatibleAudioUrl: string | null;
  durationSeconds: number | null;
  mappingVersion: number;
}

export interface PronunciationReviewRecord {
  id: string;
  wordId: string;
  normalizedKey: string;
  accent: Accent;
  status: PronunciationStatus;
  selected: ApprovedPronunciation | null;
  origin: PronunciationOrigin;
  reviewedAt: string | null;
  updatedAt: string;
}

export interface PronunciationCandidateRecord extends PronunciationAttribution {
  id: string;
  wordId: string;
  normalizedKey: string;
  accent: PronunciationAccent;
  audioUrl: string;
  compatibleAudioUrl: string | null;
  durationSeconds: number | null;
  source: 'wiktionary' | 'commons-search';
  rank: number;
  rejected: boolean;
  fetchedAt: string;
}

export const pronunciationReviewId = (wordId: string, accent: Accent) => `${wordId}:${accent}`;
```

- [ ] **Step 4: 扩展 AppSettings 并调整默认值**

在 `AppSettings` 增加：

```ts
pronunciationSource: PronunciationSourcePreference;
cacheWikimediaAfterPlayback: boolean;
```

在 `DEFAULT_SETTINGS` 增加并修改：

```ts
pronunciationSource: 'wikimedia-first',
cacheWikimediaAfterPlayback: true,
speechErrorsEnabled: false,
```

- [ ] **Step 5: 将数据库升级到 v2**

```ts
// src/db/openDb.ts
export const DB_VERSION = 2;

// upgrade(db) 内追加
if (!db.objectStoreNames.contains('pronunciationReviews')) {
  const store = db.createObjectStore('pronunciationReviews', { keyPath: 'id' });
  store.createIndex('by-word', 'wordId');
  store.createIndex('by-status', 'status');
  store.createIndex('by-normalized', 'normalizedKey');
}
if (!db.objectStoreNames.contains('pronunciationCandidates')) {
  const store = db.createObjectStore('pronunciationCandidates', { keyPath: 'id' });
  store.createIndex('by-word', 'wordId');
  store.createIndex('by-accent', 'accent');
  store.createIndex('by-fetched', 'fetchedAt');
}
```

在 `CiJiDb` 中加入对应 store 类型；在 `Repositories` 中加入：

```ts
pronunciationReviews: {
  get(wordId: string, accent: Accent): Promise<PronunciationReviewRecord | undefined>;
  getByWord(wordId: string): Promise<PronunciationReviewRecord[]>;
  getByStatus(status: PronunciationStatus): Promise<PronunciationReviewRecord[]>;
  getAll(): Promise<PronunciationReviewRecord[]>;
  put(record: PronunciationReviewRecord): Promise<void>;
  deleteByWord(wordId: string): Promise<void>;
};
pronunciationCandidates: {
  getByWord(wordId: string): Promise<PronunciationCandidateRecord[]>;
  putMany(records: PronunciationCandidateRecord[]): Promise<void>;
  clearForWord(wordId: string): Promise<void>;
  deleteOlderThan(iso: string): Promise<number>;
};
```

- [ ] **Step 6: 运行数据库、设置和既有测试**

Run: `npm test -- tests/db/pronunciation-migration.test.ts tests/pronunciation/baseline.test.ts tests/settings/SettingsProvider.test.tsx tests/db/repositories.test.ts`

Expected: PASS。

- [ ] **Step 7: 提交**

```bash
git add src/pronunciation/types.ts src/domain/models.ts src/domain/constants.ts src/db/schema.ts src/db/openDb.ts src/db/repositories.ts tests/db/pronunciation-migration.test.ts tests/pronunciation/baseline.test.ts
git commit -m "feat: add pronunciation domain and database stores"
```

---

### Task 3: 升级备份格式并兼容 v1 恢复

**Files:**
- Modify: `src/backup/backupSchema.ts`
- Modify: `src/backup/exportBackup.ts`
- Modify: `src/backup/restoreBackup.ts`
- Test: `tests/backup/pronunciationBackup.test.ts`

**Interfaces:**
- Consumes: `PronunciationReviewRecord`。
- Produces: `CompleteBackupV2`；继续接受 `CompleteBackupV1`。
- Candidates 和 Cache Storage 不进入备份；只有用户审核结果进入备份。

- [ ] **Step 1: 写 v1/v2 兼容失败测试**

```ts
// tests/backup/pronunciationBackup.test.ts
import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB } from 'idb';
import { openCiJiDb } from '../../src/db/openDb';
import { readCompleteBackup } from '../../src/backup/exportBackup';
import { validateBackup } from '../../src/backup/backupSchema';

const names: string[] = [];
afterEach(async () => Promise.all(names.splice(0).map((name) => deleteDB(name))));

describe('pronunciation backup', () => {
  it('exports approved user reviews in schema v2', async () => {
    const name = `backup-${crypto.randomUUID()}`;
    names.push(name);
    const db = await openCiJiDb(name);
    await db.put('settings', { id: 'singleton' } as never);
    await db.put('pronunciationReviews', {
      id: 'w1:en-GB', wordId: 'w1', normalizedKey: 'atmosphere', accent: 'en-GB',
      status: 'approved', selected: null, origin: 'user', reviewedAt: null,
      updatedAt: '2026-07-11T00:00:00Z',
    });
    const backup = await readCompleteBackup(db);
    expect(backup.schemaVersion).toBe(2);
    expect(backup.data.pronunciationReviews).toHaveLength(1);
    db.close();
  });

  it('accepts a schema v1 backup and supplies no pronunciation reviews', () => {
    const parsed = validateBackup({
      schemaVersion: 1, app: '词迹', exportedAt: '2026-07-11T00:00:00Z', localDate: '2026-07-11',
      data: { words: [], packs: [], studyStates: [], studyEvents: [], sessions: [], settings: {
        id: 'singleton', direction: 'en-zh', showPhonetic: true, gesturesEnabled: false,
        defaultOrder: 'source', fontSize: 'medium', accent: 'en-GB', speechRate: .85,
        autoSpeakCards: true, autoSpeakImmersive: true, speechUnlocked: false,
        speechErrorsEnabled: true, theme: 'light', immersiveDensity: 'comfortable',
        onboardingSeen: true, gestureHintSeen: false,
      }, imports: [], trash: [] },
    });
    expect(parsed.data.pronunciationReviews).toEqual([]);
  });
});
```

- [ ] **Step 2: 运行测试并确认失败**

Run: `npm test -- tests/backup/pronunciationBackup.test.ts`

Expected: FAIL，当前导出仍是 schemaVersion 1。

- [ ] **Step 3: 实现 v2 联合解析**

定义：

```ts
export interface CompleteBackupV2 {
  schemaVersion: 2;
  app: '词迹';
  exportedAt: string;
  localDate: LocalDate;
  data: CompleteBackupV1['data'] & {
    pronunciationReviews: PronunciationReviewRecord[];
  };
}

export type CompleteBackup = CompleteBackupV1 | CompleteBackupV2;
```

`validateBackup` 对 v1 解析后返回标准化 v2 形状：

```ts
return result.data.schemaVersion === 1
  ? { ...result.data, schemaVersion: 2 as const, data: { ...result.data.data, pronunciationReviews: [] } }
  : result.data;
```

设置 schema 中新增字段必须使用 `.default(...)`，使旧备份自动补齐：

```ts
pronunciationSource: z.enum(['wikimedia-first', 'local-first', 'system-only']).default('wikimedia-first'),
cacheWikimediaAfterPlayback: z.boolean().default(true),
speechErrorsEnabled: z.boolean().default(false),
```

- [ ] **Step 4: 导出与恢复 pronunciationReviews**

`readCompleteBackup` 追加 `db.getAll('pronunciationReviews')`。`mergeRestore` 和覆盖恢复事务 stores 列表加入 `pronunciationReviews`，但不加入 `pronunciationCandidates`。

- [ ] **Step 5: 运行备份测试集**

Run: `npm test -- tests/backup/restoreBackup.test.ts tests/backup/pronunciationBackup.test.ts`

Expected: PASS。

- [ ] **Step 6: 提交**

```bash
git add src/backup/backupSchema.ts src/backup/exportBackup.ts src/backup/restoreBackup.ts tests/backup/pronunciationBackup.test.ts
git commit -m "feat: back up pronunciation reviews with v1 compatibility"
```

---

### Task 4: 建立内置映射格式、加载器和严格校验脚本

**Files:**
- Create: `src/pronunciation/mappingSchema.ts`
- Create: `src/pronunciation/bundledMapping.ts`
- Create: `public/data/wikimedia-pronunciations.json`
- Create: `scripts/validate-wikimedia-mapping.ts`
- Modify: `package.json`
- Test: `tests/pronunciation/bundledMapping.test.ts`

**Interfaces:**
- Produces:
  - `loadBundledPronunciationMapping(fetcher?)`
  - `getBundledPronunciation(normalizedKey, accent)`
  - JSON schemaVersion 1, mappingVersion integer。

- [ ] **Step 1: 写映射加载失败测试**

```ts
// tests/pronunciation/bundledMapping.test.ts
import { describe, expect, it } from 'vitest';
import { parseBundledMapping } from '../../src/pronunciation/mappingSchema';

describe('bundled Wikimedia mapping', () => {
  it('rejects approved records without attribution', () => {
    expect(() => parseBundledMapping({
      schemaVersion: 1,
      mappingVersion: 1,
      generatedAt: '2026-07-11T00:00:00Z',
      words: { atmosphere: { british: { status: 'approved', accent: 'en-GB', audioUrl: 'https://upload.wikimedia.org/a.ogg' } } },
    })).toThrow();
  });

  it('accepts explicit missing accents', () => {
    const parsed = parseBundledMapping({
      schemaVersion: 1,
      mappingVersion: 1,
      generatedAt: '2026-07-11T00:00:00Z',
      words: { atmosphere: { british: { status: 'missing', accent: 'en-GB' }, american: { status: 'missing', accent: 'en-US' } } },
    });
    expect(parsed.words.atmosphere.british.status).toBe('missing');
  });
});
```

- [ ] **Step 2: 运行测试并确认失败**

Run: `npm test -- tests/pronunciation/bundledMapping.test.ts`

Expected: FAIL，模块不存在。

- [ ] **Step 3: 定义严格 Zod 映射 schema**

```ts
// src/pronunciation/mappingSchema.ts
import { z } from 'zod';

const missing = z.object({ status: z.literal('missing'), accent: z.enum(['en-GB', 'en-US']) }).strict();
const approved = z.object({
  status: z.literal('approved'),
  accent: z.enum(['en-GB', 'en-US']),
  audioUrl: z.string().url(),
  compatibleAudioUrl: z.string().url().nullable(),
  filePageUrl: z.string().url(),
  author: z.string().trim().min(1),
  licenseName: z.string().trim().min(1),
  licenseUrl: z.string().url().nullable(),
  sourceFileName: z.string().trim().min(1),
  durationSeconds: z.number().positive().max(12).nullable(),
}).strict();

const accentRecord = z.discriminatedUnion('status', [missing, approved]);
export const bundledMappingSchema = z.object({
  schemaVersion: z.literal(1),
  mappingVersion: z.number().int().positive(),
  generatedAt: z.string().datetime(),
  words: z.record(z.string().min(1), z.object({
    british: accentRecord,
    american: accentRecord,
  }).strict()),
}).strict();

export type BundledMapping = z.infer<typeof bundledMappingSchema>;
export const parseBundledMapping = (input: unknown): BundledMapping => bundledMappingSchema.parse(input);
```

- [ ] **Step 4: 实现单次加载和按口音读取**

```ts
// src/pronunciation/bundledMapping.ts
import type { Accent } from '../domain/models';
import { parseBundledMapping, type BundledMapping } from './mappingSchema';

let pending: Promise<BundledMapping> | null = null;
export function loadBundledPronunciationMapping(fetcher: typeof fetch = fetch): Promise<BundledMapping> {
  pending ??= fetcher(`${import.meta.env.BASE_URL}data/wikimedia-pronunciations.json`)
    .then((response) => {
      if (!response.ok) throw new Error(`真人录音映射加载失败：${response.status}`);
      return response.json();
    })
    .then(parseBundledMapping);
  return pending;
}
export async function getBundledPronunciation(normalizedKey: string, accent: Accent) {
  const mapping = await loadBundledPronunciationMapping();
  return mapping.words[normalizedKey]?.[accent === 'en-GB' ? 'british' : 'american'] ?? null;
}
export function resetBundledMappingForTests() { pending = null; }
```

- [ ] **Step 5: 创建可构建的初始映射**

`public/data/wikimedia-pronunciations.json` 先包含当前词包全部 131 个 normalizedKey，每个口音显式为 `missing`；Task 12 将其替换为审核结果。初始文件必须通过校验，不能遗漏词条。

- [ ] **Step 6: 实现映射验证命令**

验证脚本必须：

```ts
const missingWords = pack.words
  .map((word) => normalizeWordKey(word.word))
  .filter((key) => !mapping.words[key]);
if (missingWords.length) throw new Error(`映射缺少词条：${missingWords.join(', ')}`);
for (const [key, entry] of Object.entries(mapping.words)) {
  for (const record of [entry.british, entry.american]) {
    if (record.status === 'approved' && !record.filePageUrl.includes('commons.wikimedia.org/wiki/File:')) {
      throw new Error(`${key} 的来源页不是 Commons File 页面`);
    }
  }
}
```

- [ ] **Step 7: 运行测试与校验**

Run: `npm test -- tests/pronunciation/bundledMapping.test.ts && npm run validate:pronunciations`

Expected: PASS，输出 `131 words / 262 accent slots validated`。

- [ ] **Step 8: 提交**

```bash
git add src/pronunciation/mappingSchema.ts src/pronunciation/bundledMapping.ts public/data/wikimedia-pronunciations.json scripts/validate-wikimedia-mapping.ts package.json tests/pronunciation/bundledMapping.test.ts
git commit -m "feat: add validated bundled pronunciation mapping"
```

---

### Task 5: 实现 Wikimedia 候选查询、元数据清洗和口音排序

**Files:**
- Create: `src/pronunciation/wikimediaApi.ts`
- Create: `tests/fixtures/wiktionary-atmosphere-images.json`
- Create: `tests/fixtures/commons-atmosphere-imageinfo.json`
- Create: `tests/pronunciation/wikimediaApi.test.ts`

**Interfaces:**
- Produces:
  - `searchWikimediaCandidates(word, signal?): Promise<PronunciationCandidateRecord[]>`
  - `rankCandidates(candidates, requestedAccent): PronunciationCandidateRecord[]`
  - `stripMetadataHtml(value): string`

- [ ] **Step 1: 保存真实结构但去除无关字段的 API 固件**

固件必须覆盖：Wiktionary `prop=images`、Commons `generator=search`、`imageinfo.url|mime|mediatype|extmetadata`，并至少包含英式、美式、地区未知和非音频各一项。

- [ ] **Step 2: 写解析和排序失败测试**

```ts
// tests/pronunciation/wikimediaApi.test.ts
import { describe, expect, it } from 'vitest';
import { rankCandidates, stripMetadataHtml } from '../../src/pronunciation/wikimediaApi';

it('strips HTML from attribution metadata', () => {
  expect(stripMetadataHtml('<a href="/wiki/User:A">User A</a>')).toBe('User A');
});

it('ranks explicit British Wiktionary audio above unknown Commons search', () => {
  const ranked = rankCandidates([
    { id: 'u', wordId: 'w1', normalizedKey: 'atmosphere', accent: 'unknown', source: 'commons-search', rank: 0 } as never,
    { id: 'b', wordId: 'w1', normalizedKey: 'atmosphere', accent: 'en-GB', source: 'wiktionary', rank: 0 } as never,
  ], 'en-GB');
  expect(ranked.map((item) => item.id)).toEqual(['b', 'u']);
});
```

- [ ] **Step 3: 运行测试并确认失败**

Run: `npm test -- tests/pronunciation/wikimediaApi.test.ts`

Expected: FAIL，模块不存在。

- [ ] **Step 4: 实现固定 API 请求构造器**

```ts
const WIKTIONARY_API = 'https://en.wiktionary.org/w/api.php';
const COMMONS_API = 'https://commons.wikimedia.org/w/api.php';

function apiUrl(base: string, params: Record<string, string>): string {
  const url = new URL(base);
  url.search = new URLSearchParams({ action: 'query', format: 'json', formatversion: '2', origin: '*', ...params }).toString();
  return url.toString();
}
```

查询顺序：

```ts
// 1. Wiktionary 词条关联文件
apiUrl(WIKTIONARY_API, { prop: 'images', titles: normalizedWord, imlimit: 'max' });

// 2. Commons 兜底搜索，限制 File namespace
apiUrl(COMMONS_API, {
  generator: 'search',
  gsrsearch: `${normalizedWord} pronunciation`,
  gsrnamespace: '6',
  gsrlimit: '20',
  prop: 'imageinfo',
  iiprop: 'url|mime|mediatype|extmetadata',
  iiextmetadatalanguage: 'en',
  iiextmetadatafilter: 'Artist|LicenseShortName|LicenseUrl|UsageTerms|AttributionRequired|Categories|Language',
});
```

对 Wiktionary 返回的 File titles 再批量调用 Commons `titles=File:A.ogg|File:B.ogg` 的 `imageinfo`。

- [ ] **Step 5: 实现安全元数据解析**

```ts
export function stripMetadataHtml(value: string): string {
  const doc = new DOMParser().parseFromString(value, 'text/html');
  return (doc.body.textContent ?? '').replace(/\s+/g, ' ').trim();
}
```

候选必须同时满足：`mediatype === 'AUDIO'` 或 MIME 以 `audio/` 开头；URL 为 HTTPS；作者、许可证、文件页均非空。时长未知允许保留，但已知时必须在 0.2–12 秒。

- [ ] **Step 6: 实现口音识别与排序**

英式关键字：`en-uk`, `en-gb`, `british`, `uk english`, `united kingdom`。

美式关键字：`en-us`, `american`, `us english`, `united states`。

评分：

```ts
score += candidate.source === 'wiktionary' ? 1000 : 0;
score += exactFileStemMatch ? 500 : 0;
score += candidate.accent === requestedAccent ? 300 : 0;
score += candidate.accent === 'unknown' ? 50 : 0;
score += attributionComplete ? 100 : -1000;
score += durationInRange ? 50 : 0;
```

其他明确口音不得排入请求口音的前五名。

- [ ] **Step 7: 加入请求取消、超时和短期内存缓存**

`searchWikimediaCandidates` 接受外部 `AbortSignal`，每个请求 8 秒超时；相同 normalized word 的成功结果在内存缓存 15 分钟。失败不写入永久 missing。

- [ ] **Step 8: 运行测试**

Run: `npm test -- tests/pronunciation/wikimediaApi.test.ts`

Expected: PASS。

- [ ] **Step 9: 提交**

```bash
git add src/pronunciation/wikimediaApi.ts tests/fixtures/wiktionary-atmosphere-images.json tests/fixtures/commons-atmosphere-imageinfo.json tests/pronunciation/wikimediaApi.test.ts
git commit -m "feat: discover and rank Wikimedia pronunciation candidates"
```

---

### Task 6: 实现审核仓库，并在导入/新增后创建待审核记录

**Files:**
- Create: `src/pronunciation/pronunciationRepository.ts`
- Modify: `src/packs/commitImport.ts`
- Modify: `src/library/WordEditor.tsx`
- Test: `tests/pronunciation/pronunciationRepository.test.ts`
- Test: `tests/packs/commitImport.test.ts`

**Interfaces:**
- Produces:
  - `ensureReviewSlotsForWords(db, words)`
  - `approveCandidate(db, candidate)`
  - `rejectCandidate(db, candidateId)`
  - `markAccentMissing(db, wordId, normalizedKey, accent)`
  - `listPendingWords(db)`

- [ ] **Step 1: 写导入后待审核失败测试**

```ts
it('creates British and American unreviewed slots for new words', async () => {
  const record = await commitPackImport(db, preview, {});
  const words = await db.getAll('words');
  const reviews = await db.getAll('pronunciationReviews');
  expect(record.newWordCount).toBe(2);
  expect(reviews).toHaveLength(words.length * 2);
  expect(reviews.every((item) => item.status === 'unreviewed')).toBe(true);
});
```

- [ ] **Step 2: 运行测试并确认失败**

Run: `npm test -- tests/packs/commitImport.test.ts tests/pronunciation/pronunciationRepository.test.ts`

Expected: FAIL，发音审核记录为空。

- [ ] **Step 3: 实现审核状态转换**

```ts
export async function approveCandidate(db: IDBPDatabase<CiJiDb>, candidate: PronunciationCandidateRecord) {
  if (candidate.accent === 'unknown') throw new Error('地区未标明的录音不能直接确认');
  const now = new Date().toISOString();
  const record: PronunciationReviewRecord = {
    id: pronunciationReviewId(candidate.wordId, candidate.accent),
    wordId: candidate.wordId,
    normalizedKey: candidate.normalizedKey,
    accent: candidate.accent,
    status: 'approved',
    selected: {
      accent: candidate.accent,
      audioUrl: candidate.audioUrl,
      compatibleAudioUrl: candidate.compatibleAudioUrl,
      filePageUrl: candidate.filePageUrl,
      author: candidate.author,
      licenseName: candidate.licenseName,
      licenseUrl: candidate.licenseUrl,
      sourceFileName: candidate.sourceFileName,
      durationSeconds: candidate.durationSeconds,
      mappingVersion: 1,
    },
    origin: 'user',
    reviewedAt: now,
    updatedAt: now,
  };
  await db.put('pronunciationReviews', record);
  return record;
}
```

`ensureReviewSlotsForWords` 仅对不存在 user review 且内置映射不是 approved 的口音创建 `unreviewed`，不得覆盖用户 `rejected/missing/approved`。

- [ ] **Step 4: 将待审核创建纳入词包事务**

`commitPackImport` 的 readwrite transaction stores 加入 `pronunciationReviews`，对真正新建的 words 同事务写入两个口音的 review slot。模拟导入失败时必须连同 review slots 一起回滚。

- [ ] **Step 5: 手动新增词后创建两个 review slot**

`WordEditor` 在 `repos.words.put(entry)` 后调用 repository 方法；编辑既有单词且 normalizedKey 变化时，将旧 review 迁移到新 normalizedKey，但保留 wordId 和状态。

- [ ] **Step 6: 运行测试**

Run: `npm test -- tests/packs/commitImport.test.ts tests/pronunciation/pronunciationRepository.test.ts tests/library/LibraryPage.test.tsx`

Expected: PASS。

- [ ] **Step 7: 提交**

```bash
git add src/pronunciation/pronunciationRepository.ts src/packs/commitImport.ts src/library/WordEditor.tsx tests/pronunciation/pronunciationRepository.test.ts tests/packs/commitImport.test.ts
git commit -m "feat: create pronunciation review queue for new words"
```

---

### Task 7: 实现真人录音 Cache Storage 服务和批量下载

**Files:**
- Create: `src/pronunciation/audioCache.ts`
- Test: `tests/pronunciation/audioCache.test.ts`

**Interfaces:**
- Produces:
  - `getCachedPronunciation(record): Promise<CachedPronunciation | null>`
  - `cachePronunciation(record, signal?): Promise<CachedPronunciation>`
  - `downloadPronunciations(records, options): Promise<DownloadReport>`
  - `getPronunciationCacheStats(): Promise<PronunciationCacheStats>`
  - `clearPronunciationCache(): Promise<void>`

- [ ] **Step 1: 写缓存失败测试**

```ts
it('uses mapping version in cache key and returns a blob URL', async () => {
  const record = makeApprovedRecording({ audioUrl: 'https://upload.wikimedia.org/a.ogg', mappingVersion: 3 });
  globalThis.fetch = vi.fn(async () => new Response(new Uint8Array([1, 2, 3]), {
    status: 200, headers: { 'content-type': 'audio/ogg', 'content-length': '3' },
  })) as never;
  const cached = await cachePronunciation(record);
  expect(cached.cacheKey).toContain('mapping=3');
  expect(cached.objectUrl.startsWith('blob:')).toBe(true);
});
```

- [ ] **Step 2: 运行测试并确认失败**

Run: `npm test -- tests/pronunciation/audioCache.test.ts`

Expected: FAIL，模块不存在。

- [ ] **Step 3: 实现版本化缓存键**

```ts
export const PRONUNCIATION_CACHE = 'ci-ji-wikimedia-audio-v1';
export function cacheRequest(record: ApprovedPronunciation): Request {
  const url = new URL(record.audioUrl);
  url.searchParams.set('ci_ji_mapping', String(record.mappingVersion));
  return new Request(url.toString(), { method: 'GET', mode: 'cors' });
}
```

`cachePronunciation` 使用真实 `audioUrl` fetch，不把查询参数传给 Commons；put 时使用版本化 key：

```ts
const response = await fetch(record.audioUrl, { signal, mode: 'cors', credentials: 'omit' });
if (!response.ok) throw new Error(`真人录音下载失败：${response.status}`);
if (!(response.headers.get('content-type') ?? '').startsWith('audio/')) throw new Error('返回内容不是音频');
await cache.put(cacheRequest(record), response.clone());
```

- [ ] **Step 4: 实现 Blob URL 生命周期**

`getCachedPronunciation` 返回 `{ objectUrl, bytes, cacheKey, revoke() }`；播放器结束、取消或失败时必须调用 `revoke()`。

- [ ] **Step 5: 实现可暂停批量下载控制器**

```ts
export interface DownloadController {
  pause(): void;
  resume(): void;
  cancel(): void;
  result: Promise<DownloadReport>;
}
export interface DownloadReport { success: number; failed: number; skipped: number; bytes: number; }
```

并发数固定为 3；暂停不终止正在下载的 3 项，只阻止下一项启动；单项失败累计后继续。

- [ ] **Step 6: 实现统计和清理**

统计通过遍历 cache keys 和 `content-length`；缺少 content-length 时读取 clone 的 ArrayBuffer。清理仅执行 `caches.delete(PRONUNCIATION_CACHE)`。

- [ ] **Step 7: 运行测试**

Run: `npm test -- tests/pronunciation/audioCache.test.ts`

Expected: PASS。

- [ ] **Step 8: 提交**

```bash
git add src/pronunciation/audioCache.ts tests/pronunciation/audioCache.test.ts
git commit -m "feat: cache and download Wikimedia pronunciation audio"
```

---

### Task 8: 实现正式来源解析器和严格同口音降级播放控制器

**Files:**
- Create: `src/pronunciation/pronunciationResolver.ts`
- Create: `src/pronunciation/audioPlaybackController.ts`
- Modify: `src/speech/speechService.ts`
- Test: `tests/pronunciation/pronunciationResolver.test.ts`
- Test: `tests/pronunciation/audioPlaybackController.test.ts`
- Modify: `tests/speech/speechService.test.ts`

**Interfaces:**
- Produces:
  - `resolvePronunciationPlan(word, accent, settings, source): Promise<PronunciationPlan>`
  - `playPronunciation(plan, options): Promise<PronunciationPlaybackResult>`
  - `cancelPronunciation(): void`
- 旧 `speakWord` 不再尝试另一口音的 audio。

- [ ] **Step 1: 写“不得借用另一口音”失败测试**

```ts
it('never includes American Wikimedia or local audio in a British plan', async () => {
  const source: PronunciationDataSource = {
    getUserReview: async () => undefined,
    getBundled: async (_key, accent) => accent === 'en-GB'
      ? { status: 'missing', accent: 'en-GB' }
      : { status: 'approved', ...makeApprovedRecording({ accent: 'en-US' }) },
  };
  const plan = await resolvePronunciationPlan(
    makeWord({ audioUK: null, audioUS: 'audio/en-US/001-atmosphere.mp3' }),
    'en-GB',
    makeSettings(),
    source,
  );
  expect(plan.steps.map((step) => step.kind)).toEqual(['system']);
  expect(JSON.stringify(plan)).not.toContain('en-US');
});
```

- [ ] **Step 2: 写播放链路失败测试**

```ts
it('falls from Wikimedia timeout to same-accent local audio', async () => {
  const recording = makeApprovedRecording();
  const plan: PronunciationPlan = {
    word: 'atmosphere', accent: 'en-GB', attribution: recording,
    steps: [
      { kind: 'wikimedia-online', recording, timeoutMs: 6000 },
      { kind: 'local-audio', url: 'audio/en-GB/a.mp3', accent: 'en-GB', timeoutMs: 4000 },
      { kind: 'system', accent: 'en-GB', timeoutMs: 3000 },
    ],
  };
  const dependencies: PlaybackDependencies = {
    getCached: vi.fn(async () => null),
    playRemote: vi.fn(async () => ({ ok: false, reason: 'playback-failed' })),
    playLocal: vi.fn(async () => ({ ok: true })),
    playSystem: vi.fn(async () => ({ ok: true, voiceName: 'British Voice' })),
    cacheRemote: vi.fn(async () => undefined),
  };
  const result = await playPronunciation(plan, { rate: 1, cacheAfterPlayback: true }, dependencies);
  expect(result).toMatchObject({ ok: true, source: 'local-audio', accent: 'en-GB' });
});
```

- [ ] **Step 3: 运行测试并确认失败**

Run: `npm test -- tests/pronunciation/pronunciationResolver.test.ts tests/pronunciation/audioPlaybackController.test.ts`

Expected: FAIL，模块不存在。

- [ ] **Step 4: 定义播放计划**

```ts
export type PronunciationPlanStep =
  | { kind: 'wikimedia-cache'; recording: ApprovedPronunciation; timeoutMs: 1000 }
  | { kind: 'wikimedia-online'; recording: ApprovedPronunciation; timeoutMs: 6000 }
  | { kind: 'local-audio'; url: string; accent: Accent; timeoutMs: 4000 }
  | { kind: 'system'; accent: Accent; timeoutMs: 3000 };

export interface PronunciationPlan {
  word: string;
  accent: Accent;
  steps: PronunciationPlanStep[];
  attribution: ApprovedPronunciation | null;
}
```


```ts
export interface PronunciationDataSource {
  getUserReview(wordId: string, accent: Accent): Promise<PronunciationReviewRecord | undefined>;
  getBundled(normalizedKey: string, accent: Accent): Promise<BundledAccentRecord | null>;
}
```

解析顺序：用户 approved → 内置 approved；用户 `missing/rejected` 阻止内置映射；`unreviewed` 不阻止内置 approved。根据 `pronunciationSource` 调整步骤：

- `wikimedia-first`: Wikimedia cache/online → local → system。
- `local-first`: local → Wikimedia cache/online → system。
- `system-only`: system。

- [ ] **Step 5: 从 speechService 暴露底层同口音函数**

保留 `resolveAudioUrl`、`selectVoice`、`inspectSpeech`；新增：

```ts
export function playLocalAudio(url: string, rate: SpeechRate, signal?: AbortSignal): Promise<LowLevelPlaybackResult>;
export function playSystemSpeech(word: string, accent: Accent, rate: SpeechRate, signal?: AbortSignal): Promise<LowLevelPlaybackResult>;
```

删除 `speakWord` 中的 `secondaryAudio` 和 `otherAccent` 分支。系统语音只允许 `selectExactAccentVoice`，没有精确口音则返回 unsupported，不使用 `en-AU` 伪装英式或美式。

- [ ] **Step 6: 实现全局单实例控制器**

控制器依赖接口固定为：

```ts
export interface PlaybackDependencies {
  getCached(recording: ApprovedPronunciation): Promise<CachedPronunciation | null>;
  playRemote(recording: ApprovedPronunciation, rate: SpeechRate, signal: AbortSignal): Promise<LowLevelPlaybackResult>;
  playLocal(url: string, rate: SpeechRate, signal: AbortSignal): Promise<LowLevelPlaybackResult>;
  playSystem(word: string, accent: Accent, rate: SpeechRate, signal: AbortSignal): Promise<LowLevelPlaybackResult & { voiceName?: string }>;
  cacheRemote(recording: ApprovedPronunciation, signal?: AbortSignal): Promise<unknown>;
}
```

控制器维护一个 `AbortController`、一个 active Audio 和一个 active object URL cleanup。每次新播放先调用 `cancelPronunciation()`。每个 step 使用 `Promise.race` 与超时；`cancelled` 立即结束，不继续降级；`autoplay-blocked` 对用户主动点击返回错误，对自动朗读允许下一层但不弹窗。

- [ ] **Step 7: 真人播放成功后异步写缓存**

在线 Wikimedia 播放成功后，在 `cacheWikimediaAfterPlayback` 为 true 时调用 `cachePronunciation(record)`；缓存失败不得把已经成功的播放改成失败。

- [ ] **Step 8: 更新旧 speechService 测试**

将“uses the other independent accent”测试替换为：

```ts
it('does not use the opposite accent as a fallback', async () => {
  // preferred British audio fails, only American audio exists, no British system voice
  const result = await speakWord('atmosphere', { accent: 'en-GB', rate: 1, audioUK: null, audioUS: 'audio/en-US/a.mp3' });
  expect(result.ok).toBe(false);
  expect(requested.some((url) => url.includes('en-US'))).toBe(false);
});
```

- [ ] **Step 9: 运行测试**

Run: `npm test -- tests/pronunciation/pronunciationResolver.test.ts tests/pronunciation/audioPlaybackController.test.ts tests/speech/speechService.test.ts`

Expected: PASS。

- [ ] **Step 10: 提交**

```bash
git add src/pronunciation/pronunciationResolver.ts src/pronunciation/audioPlaybackController.ts src/speech/speechService.ts tests/pronunciation/pronunciationResolver.test.ts tests/pronunciation/audioPlaybackController.test.ts tests/speech/speechService.test.ts
git commit -m "feat: resolve and play same-accent pronunciation fallbacks"
```

---

### Task 9: 将 useSpeech、按钮状态和署名面板接入学习界面

**Files:**
- Modify: `src/speech/useSpeech.ts`
- Modify: `src/speech/SpeechButton.tsx`
- Create: `src/pronunciation/AttributionPanel.tsx`
- Create: `src/pronunciation/pronunciation.css`
- Modify: `src/cards/StudyCard.tsx`
- Modify: `src/immersive/ImmersiveRow.tsx`
- Test: `tests/pronunciation/useSpeech.test.tsx`
- Test: `tests/pronunciation/AttributionPanel.test.tsx`

**Interfaces:**
- `useSpeech().speak(word, slow?)`
- `useSpeech().status: 'idle' | 'loading-human' | 'playing-human' | 'playing-fallback' | 'unavailable'`
- `useSpeech().attribution: ApprovedPronunciation | null`
- `useSpeech().lastSource: 'wikimedia-cache' | 'wikimedia-online' | 'local-audio' | 'system' | null`

- [ ] **Step 1: 写状态和署名失败测试**

```tsx
it('shows compact Wikimedia attribution and expands details', async () => {
  const recording = makeApprovedRecording();
  render(<AttributionPanel recording={recording} cached />);
  expect(screen.getByRole('button', { name: '真人发音 · Wikimedia' })).toBeInTheDocument();
  await userEvent.click(screen.getByRole('button', { name: '真人发音 · Wikimedia' }));
  expect(screen.getByText('User A')).toBeInTheDocument();
  expect(screen.getByRole('link', { name: '查看 Wikimedia 文件页' })).toHaveAttribute('href', recording.filePageUrl);
});
```

- [ ] **Step 2: 运行测试并确认失败**

Run: `npm test -- tests/pronunciation/useSpeech.test.tsx tests/pronunciation/AttributionPanel.test.tsx`

Expected: FAIL。

- [ ] **Step 3: 重构 useSpeech**

`useSpeech` 读取 `useRepositories()`，为每次 `speak` 调用 resolver 和 controller。错误文案改为：

```ts
if (result.reason === 'autoplay-blocked') return '浏览器阻止了自动播放，请直接点击喇叭。';
if (result.reason === 'unsupported') return '当前口音的真人录音、本地发音和系统语音均不可用。';
return '发音暂不可用。';
```

仅 `settings.speechErrorsEnabled` 为 true 时设置 `error`。

- [ ] **Step 4: 更新 SpeechButton 状态**

按钮 aria-label 保持 `播放${word.word}`，视觉状态：

```tsx
<span className="sr-only">{
  status === 'loading-human' ? '正在加载真人发音' :
  status === 'playing-human' ? '正在播放真人发音' :
  status === 'playing-fallback' ? '正在使用备用发音' :
  status === 'unavailable' ? '发音暂不可用' : '播放发音'
}</span>
```

按钮不得阻塞卡片 reveal 或评分。

- [ ] **Step 5: 实现署名面板**

默认按钮文案固定为“真人发音 · Wikimedia”。展开区用普通文本节点显示作者、口音、许可证、缓存状态；外链加 `target="_blank" rel="noreferrer"`。作者和许可证文本只取已经清洗的字符串。

- [ ] **Step 6: 接入卡片和沉浸词表**

`StudyCard` 在 `SpeechButton` 下显示当前 approved attribution。`ImmersiveRow` 只显示一个小型真人标记，点击后可展开署名，不改变“点行展开释义”的既有行为；署名按钮必须 `stopPropagation()`。

- [ ] **Step 7: 运行组件与既有学习测试**

Run: `npm test -- tests/pronunciation/useSpeech.test.tsx tests/pronunciation/AttributionPanel.test.tsx tests/cards/CardStudyPage.test.tsx tests/immersive/ImmersivePage.test.tsx`

Expected: PASS。

- [ ] **Step 8: 提交**

```bash
git add src/speech/useSpeech.ts src/speech/SpeechButton.tsx src/pronunciation/AttributionPanel.tsx src/pronunciation/pronunciation.css src/cards/StudyCard.tsx src/immersive/ImmersiveRow.tsx tests/pronunciation/useSpeech.test.tsx tests/pronunciation/AttributionPanel.test.tsx
git commit -m "feat: show human pronunciation playback and attribution"
```

---

### Task 10: 构建“待审核发音”页面和候选试听流程

**Files:**
- Create: `src/pronunciation/PronunciationReviewPage.tsx`
- Create: `src/pronunciation/PronunciationReviewCard.tsx`
- Modify: `src/pronunciation/pronunciation.css`
- Modify: `src/library/LibraryPage.tsx`
- Modify: `src/app/routes.tsx`
- Test: `tests/pronunciation/PronunciationReviewPage.test.tsx`

**Interfaces:**
- Consumes: `searchWikimediaCandidates`、审核 repository、底层候选试听。
- Produces: `/library/pronunciation-review`。

- [ ] **Step 1: 写审核页面失败测试**

```tsx
it('does not approve an unknown-accent candidate', async () => {
  renderReviewPage({ candidates: [makeCandidate({ accent: 'unknown' })], words: [makeWord()] });
  expect(await screen.findByText('地区未标明')).toBeInTheDocument();
  expect(screen.getByRole('button', { name: '确认使用' })).toBeDisabled();
});

it('approves British and advances to the next word', async () => {
  const user = userEvent.setup();
  renderReviewPage({ candidates: [makeCandidate({ accent: 'en-GB' })], words: [makeWord(), makeWord({ id: 'w-climate', normalizedKey: 'climate', word: 'climate' })] });
  await user.click(await screen.findByRole('button', { name: '确认英式并进入下一词' }));
  expect(await screen.findByText('climate')).toBeInTheDocument();
});
```

- [ ] **Step 2: 运行测试并确认失败**

Run: `npm test -- tests/pronunciation/PronunciationReviewPage.test.tsx`

Expected: FAIL。

- [ ] **Step 3: 增加词库入口和待审核计数**

`LibraryPage` 页头增加：

```tsx
<Link className="review-entry" to="/library/pronunciation-review">
  待审核发音 <b>{pendingWordCount}</b>
</Link>
```

计数按 word 去重，只统计至少一个口音为 `unreviewed` 的词。

- [ ] **Step 4: 实现筛选和加载状态**

筛选值：`today | all | missing-british | missing-american | marked-missing`。进入某词时，先显示已有候选；候选为空或超过 15 分钟时调用搜索，成功后写入 candidate store。网络失败显示“查询失败，稍后重试”，不得把状态改为 missing。

- [ ] **Step 5: 实现候选试听**

候选试听只播放候选 URL，不进入正式 resolver，不写自动缓存；点击另一候选立即停止上一条。试听按钮必须是明确用户手势，避免移动浏览器自动播放限制。

- [ ] **Step 6: 实现审核动作**

按钮：

- `确认使用`
- `换一条`
- `拒绝候选`
- `标记缺失`
- `跳过`
- `确认英式并进入下一词`
- `确认美式并进入下一词`
- `两个口音均确认`

“两个口音均确认”只有两侧都选中明确匹配口音的候选时可用。拒绝后当前 candidate 标记 `rejected=true`，自动切换下一条。

- [ ] **Step 7: 增加路由**

```tsx
{ path: 'library/pronunciation-review', element: <PronunciationReviewPage /> },
```

- [ ] **Step 8: 运行测试**

Run: `npm test -- tests/pronunciation/PronunciationReviewPage.test.tsx tests/library/LibraryPage.test.tsx`

Expected: PASS。

- [ ] **Step 9: 提交**

```bash
git add src/pronunciation/PronunciationReviewPage.tsx src/pronunciation/PronunciationReviewCard.tsx src/pronunciation/pronunciation.css src/library/LibraryPage.tsx src/app/routes.tsx tests/pronunciation/PronunciationReviewPage.test.tsx
git commit -m "feat: add centralized pronunciation review workflow"
```

---

### Task 11: 增加今日词包下载、缓存管理和发音设置

**Files:**
- Create: `src/pronunciation/DownloadPackAudioButton.tsx`
- Modify: `src/home/HomePage.tsx`
- Modify: `src/settings/SettingsPage.tsx`
- Modify: `src/settings/SettingsProvider.tsx`
- Modify: `src/pronunciation/pronunciation.css`
- Test: `tests/pronunciation/DownloadPackAudioButton.test.tsx`
- Modify: `tests/settings/SettingsProvider.test.tsx`

**Interfaces:**
- Produces: 词包下载统计、暂停/继续/取消；设置中的来源优先级和缓存管理。

- [ ] **Step 1: 写下载统计失败测试**

```tsx
it('shows downloadable, missing, estimated bytes and final report', async () => {
  render(<DownloadPackAudioButton pack={pack} words={words} />);
  await userEvent.click(screen.getByRole('button', { name: '下载今日真人发音' }));
  expect(await screen.findByText('可下载真人录音：2条')).toBeInTheDocument();
  expect(screen.getByText('缺少真人录音：1条')).toBeInTheDocument();
  await userEvent.click(screen.getByRole('button', { name: '开始下载' }));
  expect(await screen.findByText(/成功 2/)).toBeInTheDocument();
});
```

- [ ] **Step 2: 运行测试并确认失败**

Run: `npm test -- tests/pronunciation/DownloadPackAudioButton.test.tsx`

Expected: FAIL。

- [ ] **Step 3: 实现下载预览和进度**

根据设置口音只下载当前口音；另提供“双口音”临时选项，不修改全局口音。预览显示可下载、缺失、预计空间。无法从 HEAD 获取长度时，预计空间显示“下载后统计”，不得伪造数值。

- [ ] **Step 4: 接入首页今日词包**

只在 `summary.todayPack` 存在时显示 `DownloadPackAudioButton`。下载组件不得改变首页主操作或学习进度。

- [ ] **Step 5: 更新设置页**

发音设置改为：

```tsx
<SelectRow label="发音来源" value={settings.pronunciationSource} onChange={(value) => void patchSettings({ pronunciationSource: value as PronunciationSourcePreference })}>
  <option value="wikimedia-first">真人词典优先</option>
  <option value="local-first">本地发音优先</option>
  <option value="system-only">仅系统语音</option>
</SelectRow>
<ToggleRow label="首次播放后自动缓存" checked={settings.cacheWikimediaAfterPlayback} onChange={(value) => void patchSettings({ cacheWikimediaAfterPlayback: value })} />
<ToggleRow label="发音失败提示" checked={settings.speechErrorsEnabled} onChange={(value) => void patchSettings({ speechErrorsEnabled: value })} />
```

诊断区显示当前实际来源、真人缓存条数/空间、本地英式/美式文件存在情况、系统精确口音语音数量。删除硬编码“131 / 131”，改为运行时检测或显示“作为备用”。

- [ ] **Step 6: 实现清理缓存确认**

显示：

```text
真人录音缓存：12.8 MB
已缓存录音：86 条
```

按钮“清除真人录音缓存”点击后使用普通确认对话框；成功后刷新统计。禁止调用 IndexedDB clear。

- [ ] **Step 7: 运行测试**

Run: `npm test -- tests/pronunciation/DownloadPackAudioButton.test.tsx tests/settings/SettingsProvider.test.tsx`

Expected: PASS。

- [ ] **Step 8: 提交**

```bash
git add src/pronunciation/DownloadPackAudioButton.tsx src/home/HomePage.tsx src/settings/SettingsPage.tsx src/settings/SettingsProvider.tsx src/pronunciation/pronunciation.css tests/pronunciation/DownloadPackAudioButton.test.tsx tests/settings/SettingsProvider.test.tsx
git commit -m "feat: download and manage human pronunciation cache"
```

---

### Task 12: 建立 131 词候选发现、人工审核和正式映射构建流水线

**Files:**
- Create: `scripts/discover-wikimedia-pronunciations.ts`
- Create: `scripts/build-wikimedia-mapping.ts`
- Create: `docs/pronunciation/wikimedia-review.csv`
- Create: `docs/pronunciation/README.md`
- Modify: `public/data/wikimedia-pronunciations.json`
- Test: `tests/pronunciation/mappingBuild.test.ts`

**Interfaces:**
- 输入：`public/packs/2026-07-11-自然地理与环境-131词.json`
- 候选输出：`docs/pronunciation/wikimedia-candidates.json`
- 审核输入：`docs/pronunciation/wikimedia-review.csv`
- 正式输出：`public/data/wikimedia-pronunciations.json`

- [ ] **Step 1: 定义审核 CSV 列**

首行必须是：

```csv
word,normalizedKey,accent,status,audioUrl,compatibleAudioUrl,filePageUrl,author,licenseName,licenseUrl,sourceFileName,durationSeconds,reviewedBy,reviewedAt,notes
```

`accent` 只能是 `en-GB` 或 `en-US`；`status` 只能是 `approved` 或 `missing`。

- [ ] **Step 2: 写构建器失败测试**

在测试文件中定义 `packWith(words)` 和 `twoRows(patch)`，分别构造最小词包和同一单词的 en-GB/en-US 两行审核数据；随后写入：

```ts
it('requires exactly two reviewed rows per pack word', () => {
  const rows = [{ word: 'atmosphere', normalizedKey: 'atmosphere', accent: 'en-GB', status: 'missing' }];
  expect(() => buildMapping(packWith(['atmosphere']), rows as never)).toThrow('atmosphere 缺少 en-US 审核结果');
});

it('rejects approved rows without author and license', () => {
  expect(() => buildMapping(packWith(['atmosphere']), twoRows({ status: 'approved', author: '' }) as never)).toThrow('授权字段不完整');
});
```

- [ ] **Step 3: 实现候选发现脚本**

脚本逐词调用 `searchWikimediaCandidates`，每次请求间隔 250ms，并设置清晰 User-Agent：

```ts
const USER_AGENT = 'CiJiPronunciationAudit/1.2 (https://github.com/lsad-max/ci-ji)';
```

浏览器端 fetch 不允许设置 User-Agent；该头仅用于 Node 审核脚本。脚本失败时写入 `{ word, error }` 并继续，最终非零退出码提醒存在失败词。

- [ ] **Step 4: 人工完成 262 个口音槽审核**

每个槽执行：

1. 打开候选文件页，确认单词和语言。
2. 实际试听，确认不是例句、多人对话、音乐或严重噪声。
3. 根据文件名、分类或说明页确认英式/美式；无法确认则不批准。
4. 核对作者、许可证和来源页。
5. 合格写 `approved`；没有合格项写 `missing`。
6. `reviewedAt` 使用 ISO 8601，`reviewedBy` 写审核者 GitHub 用户名。

- [ ] **Step 5: 实现映射构建器**

构建器必须排序 normalizedKey，生成稳定 JSON；每个 pack word 必须恰好两个 accent rows。`approved` 转成完整记录，`missing` 只保留 status/accent。`mappingVersion` 从现有文件读取并加 1。

- [ ] **Step 6: 运行完整构建与验证**

Run:

```bash
npm run discover:pronunciations
npm run build:pronunciations
npm run validate:pronunciations
npm test -- tests/pronunciation/mappingBuild.test.ts tests/pronunciation/bundledMapping.test.ts
```

Expected:

```text
131 words / 262 accent slots reviewed
approved: N（由脚本根据审核 CSV 计算）
missing: M（由脚本根据审核 CSV 计算）
validation passed
```

不得在审核前写死 approved/missing 数量。

- [ ] **Step 7: 抽样复核**

至少复核 20 个词：10 个英式、10 个美式；其中包含 `atmosphere`、`climate`、`drought`、`earthquake`、`ecosystem`。抽样结果写入 `docs/pronunciation/README.md` 的“抽样复核记录”。

- [ ] **Step 8: 提交**

```bash
git add scripts/discover-wikimedia-pronunciations.ts scripts/build-wikimedia-mapping.ts docs/pronunciation/wikimedia-review.csv docs/pronunciation/README.md public/data/wikimedia-pronunciations.json tests/pronunciation/mappingBuild.test.ts
git commit -m "data: add reviewed Wikimedia pronunciation mapping"
```

---

### Task 13: 调整 PWA 缓存、版本显示和部署路径

**Files:**
- Modify: `vite.config.ts`
- Modify: `src/settings/SettingsPage.tsx`
- Modify: `.github/workflows/deploy-pages.yml`
- Modify: `tests/app/basePath.test.ts`
- Create: `tests/pwa/pronunciationCachePolicy.test.ts`

**Interfaces:**
- 静态映射随 app shell 预缓存。
- 远程 Wikimedia 音频只由 `audioCache.ts` 管理，Workbox 不重复缓存。
- v1.2 预览路径：`/ci-ji/preview-v1-2/`。

- [ ] **Step 1: 写缓存策略失败测试**

```ts
it('precaches the mapping but does not glob remote audio extensions', () => {
  expect(viteConfigText).toContain('data/wikimedia-pronunciations.json');
  expect(viteConfigText).not.toContain('json,mp3,ogg,oga,webm');
});
```

- [ ] **Step 2: 更新 VitePWA**

`includeAssets` 加入 `data/wikimedia-pronunciations.json`。`globPatterns` 保留本地 `mp3` 兜底文件，但不要添加 `ogg/oga/webm`，因为远程真人录音由业务 Cache Storage 管理。`cacheId` 通过 base path 区分：

```ts
cacheId: `ci-ji-app-${base.replace(/\W+/g, '-') || 'root'}`,
```

- [ ] **Step 3: 更新版本显示**

设置页显示 `1.2.0`，并将试听示例通过 resolver 播放 `atmosphere`，不再直接硬编码本地 MP3 为主来源。

- [ ] **Step 4: 更新联合 Pages 部署**

工作流 checkout `feature/v1.2-wikimedia-pronunciation`，解压构建产物到 `site/preview-v1-2`；验证：

```bash
test -f site/preview-v1-2/data/wikimedia-pronunciations.json
node -e "const m=require('./site/preview-v1-2/data/wikimedia-pronunciations.json'); if(Object.keys(m.words).length!==131) process.exit(1)"
```

不再用“262 个 MP3”作为 v1.2 成功条件；保留 v1.1 本地音频作为 fallback 的构建检查。

- [ ] **Step 5: 运行类型、单测和构建**

Run:

```bash
npm run typecheck
npm test
CI_JI_BASE_PATH=/ci-ji/preview-v1-2/ npm run build
```

Expected: 全部 PASS，`dist/data/wikimedia-pronunciations.json` 存在。

- [ ] **Step 6: 提交**

```bash
git add vite.config.ts src/settings/SettingsPage.tsx .github/workflows/deploy-pages.yml tests/app/basePath.test.ts tests/pwa/pronunciationCachePolicy.test.ts
git commit -m "ci: prepare v1.2 Wikimedia pronunciation preview"
```

---

### Task 14: 端到端测试、离线验证和 Mate X7 实机验收

**Files:**
- Create: `e2e/pronunciation.spec.ts`
- Modify: `e2e/helpers.ts`
- Modify: `RELEASE_CHECKLIST.md`
- Create: `docs/pronunciation/mate-x7-verification.md`

**Interfaces:**
- Produces: 可重复的浏览器自动化验证和实机记录。

- [ ] **Step 1: 增加 Wikimedia API 和音频 route mock**

在 Playwright helper 中拦截：

```ts
await page.route('https://en.wiktionary.org/**', (route) => route.fulfill({ json: wiktionaryFixture }));
await page.route('https://commons.wikimedia.org/**', (route) => route.fulfill({ json: commonsFixture }));
function createSilentWavBuffer(durationMs = 200): Buffer {
  const sampleRate = 8000;
  const samples = Math.floor(sampleRate * durationMs / 1000);
  const buffer = Buffer.alloc(44 + samples * 2);
  buffer.write('RIFF', 0); buffer.writeUInt32LE(36 + samples * 2, 4); buffer.write('WAVEfmt ', 8);
  buffer.writeUInt32LE(16, 16); buffer.writeUInt16LE(1, 20); buffer.writeUInt16LE(1, 22);
  buffer.writeUInt32LE(sampleRate, 24); buffer.writeUInt32LE(sampleRate * 2, 28);
  buffer.writeUInt16LE(2, 32); buffer.writeUInt16LE(16, 34); buffer.write('data', 36);
  buffer.writeUInt32LE(samples * 2, 40);
  return buffer;
}

await page.route('https://upload.wikimedia.org/**', (route) => route.fulfill({
  status: 200,
  contentType: 'audio/wav',
  body: createSilentWavBuffer(),
}));
```

- [ ] **Step 2: 编写端到端场景**

必须覆盖：

```ts
test('approved Wikimedia pronunciation plays and attribution opens', async ({ page }) => { /* 导入、播放、检查状态与署名 */ });
test('network failure falls back to same-accent local audio', async ({ page }) => { /* upload 500，检查“正在使用备用发音” */ });
test('opposite accent is never used', async ({ page }) => { /* 仅美式 approved，设置英式，断言美式 URL 未请求 */ });
test('cached recording works offline', async ({ page, context }) => { /* 在线播放一次，context.setOffline(true)，再次播放 */ });
test('new word enters review queue and can be approved', async ({ page }) => { /* 新增词、搜索、试听、确认 */ });
test('clearing audio cache preserves mastery', async ({ page }) => { /* 评分、清缓存、检查评分仍在 */ });
```

- [ ] **Step 3: 运行完整自动化验证**

Run:

```bash
npm run typecheck
npm test
npm run build
npm run test:e2e
npm run validate:pronunciations
```

Expected: 全部 PASS。

- [ ] **Step 4: 部署 v1.2 预览并验证直达 URL**

验证：

```text
https://lsad-max.github.io/ci-ji/preview-v1-2/
```

在桌面 Chrome DevTools Network 中确认播放已批准单词时请求 `upload.wikimedia.org`，第二次播放使用 Cache Storage；强制 offline 后仍能播放已缓存项。

- [ ] **Step 5: Mate X7 实机执行固定步骤**

在 `docs/pronunciation/mate-x7-verification.md` 记录：

```markdown
- 设备：Huawei Mate X7
- 系统：HarmonyOS 6
- 浏览器及版本：执行实机测试时记录浏览器“关于”页面显示的完整版本
- 测试日期：执行实机测试当天的 YYYY-MM-DD
- 预览提交 SHA：本次预览部署对应的 40 位 Git commit SHA
- atmosphere 英式真人：通过/失败
- atmosphere 美式真人：通过/失败
- 断网缓存播放：通过/失败
- 真人失败→本地英式：通过/失败
- 连续点击停止上一条：通过/失败
- 署名与来源页：通过/失败
- 学习记录升级保留：通过/失败
- 备注：记录实际音量、加载耗时、失败提示和任何异常现象；无异常时写“无”
```

这些尖括号字段是实机执行记录，不得在发布前保留；完成者必须填入真实值。

- [ ] **Step 6: 仅在实机通过后勾选发布清单**

若 Mate X7 无声：先打开该 approved recording 的原始 `upload.wikimedia.org` URL。原始 URL 无声则更换候选；原始 URL 有声而应用无声则保留失败状态并抓取 Console、Network、Cache Storage 证据，禁止宣布完成。

- [ ] **Step 7: 最终提交**

```bash
git add e2e/pronunciation.spec.ts e2e/helpers.ts RELEASE_CHECKLIST.md docs/pronunciation/mate-x7-verification.md
git commit -m "test: verify v1.2 pronunciation on web and Mate X7"
```

---

## Final Verification Gate

按顺序执行：

```bash
npm ci
npm run typecheck
npm test
npm run validate:pack
npm run validate:pronunciations
CI_JI_BASE_PATH=/ci-ji/preview-v1-2/ npm run build
npm run test:e2e
```

必须确认：

1. `public/data/wikimedia-pronunciations.json` 覆盖 131 个 normalizedKey 和 262 个口音槽。
2. 每条 `approved` 记录具备作者、许可证、Commons 文件页和 HTTPS 音频 URL。
3. 每条 `missing` 记录会进入同口音本地音频/系统语音降级，不会借用另一口音。
4. v1 数据库升级、v1 备份恢复、v2 备份往返均通过。
5. 候选审核、批量下载、缓存清理和离线播放均通过。
6. GitHub Pages v1.2 预览部署为绿色。
7. Mate X7 实机记录全部关键项通过。

完成上述门槛后，才可创建合并到 `main` 的 Pull Request。
