# 词迹 PWA Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a mobile-first, installable, offline-capable vocabulary-recognition PWA that ships with the validated 2026-07-11 “自然地理与环境” 131-word pack and supports daily pack import, card study, immersive browsing, local review scheduling, pronunciation, library management, records, backup, and restore.

**Architecture:** Use a React + TypeScript single-page application with feature modules and domain services. Persist all user data in IndexedDB behind repository interfaces; validate external JSON with Zod; keep scheduling, import merging, statistics, and pronunciation in framework-independent services so they can be unit-tested without rendering pages. Use `vite-plugin-pwa` for the app manifest, service worker, update lifecycle, and offline app shell.

**Tech Stack:** React, TypeScript, Vite, React Router, `idb`, Zod, `fflate`, `vite-plugin-pwa`, Lucide React, Vitest, React Testing Library, `fake-indexeddb`, Playwright.

## Global Constraints

- Product name is exactly `词迹`; desktop/PWA short name is also `词迹`.
- Default learning direction is English → Chinese; Chinese → English remains selectable and never requires spelling input.
- Default pronunciation is British English, rate `0.85`; selectable rates are exactly `0.75`, `0.85`, `1.0`, and `1.15`.
- The three user ratings are exactly `不认识`, `模糊`, and `认识`; rating controls are unavailable before the answer is revealed.
- Daily first-pass order follows the pack’s original order; historical review defaults to random order.
- Same-day reinforcement inserts `不认识` after 3–5 cards and `模糊` after 8–12 cards; `认识` does not repeat in that first-pass session.
- Cross-day intervals are exactly: unknown 1 day, fuzzy 2 days, first known 3 days, second consecutive known 7 days, third 15 days, fourth and later 30 days.
- Every daily pack remains distinct while identical normalized English spellings share one master word record.
- Dates are stored and compared as local `YYYY-MM-DD` strings; do not round-trip pack dates through UTC.
- User data is local-only in IndexedDB; first release has no account, cloud sync, server database, system notifications, OCR, AI categorization, or spelling test.
- First release must support Android Chrome/Edge and iPhone Safari/add-to-home-screen; primary layout is portrait and touch targets are at least 44 CSS pixels.
- App must work offline after the first successful online load; updating app code must not clear IndexedDB.
- All destructive bulk actions require the exact confirmation text `确认清空`.
- The first build preloads `2026-07-11｜自然地理与环境｜131词` and also includes the same pack as a standalone JSON import fixture.

---

## Planned File Map

```text
ci-ji-pwa/
├─ package.json
├─ package-lock.json
├─ vite.config.ts
├─ tsconfig.json
├─ playwright.config.ts
├─ index.html
├─ public/
│  ├─ packs/2026-07-11-自然地理与环境-131词.json
│  └─ icons/{icon.svg,icon-192.png,icon-512.png,maskable-512.png,apple-touch-icon.png}
├─ scripts/
│  ├─ validate-pack.ts
│  └─ generate-icons.mjs
├─ src/
│  ├─ main.tsx
│  ├─ app/App.tsx
│  ├─ app/routes.tsx
│  ├─ app/AppShell.tsx
│  ├─ app/UpdatePrompt.tsx
│  ├─ app/styles/{tokens.css,global.css}
│  ├─ domain/{models.ts,constants.ts,dates.ts,normalize.ts}
│  ├─ db/{schema.ts,openDb.ts,repositories.ts,transactions.ts,seed.ts}
│  ├─ packs/{packSchema.ts,parsePack.ts,previewImport.ts,commitImport.ts,mergeWord.ts}
│  ├─ study/{scheduler.ts,sessionEngine.ts,studyRepository.ts}
│  ├─ speech/{speechService.ts,useSpeech.ts}
│  ├─ settings/{settingsRepository.ts,SettingsProvider.tsx,SettingsPage.tsx}
│  ├─ onboarding/{Onboarding.tsx,onboarding.css}
│  ├─ home/{HomePage.tsx,homeQueries.ts}
│  ├─ cards/{CardStudyPage.tsx,StudyCard.tsx,RatingBar.tsx,useCardSession.ts}
│  ├─ immersive/{ImmersivePage.tsx,ImmersiveRow.tsx,immersiveQueries.ts}
│  ├─ library/{LibraryPage.tsx,WordEditor.tsx,BulkPastePage.tsx,TrashPage.tsx,libraryQueries.ts}
│  ├─ records/{RecordsPage.tsx,RecordsDetailPage.tsx,statistics.ts}
│  ├─ backup/{backupSchema.ts,exportBackup.ts,restoreBackup.ts,BackupPage.tsx}
│  ├─ pwa/{install.ts,cacheRepair.ts}
│  └─ components/{BottomNav.tsx,PageHeader.tsx,ConfirmPhraseDialog.tsx,EmptyState.tsx}
├─ tests/
│  ├─ setup.ts
│  ├─ fixtures/samplePack.ts
│  ├─ domain/{normalize.test.ts,dates.test.ts}
│  ├─ db/repositories.test.ts
│  ├─ packs/{parsePack.test.ts,previewImport.test.ts,commitImport.test.ts}
│  ├─ study/{scheduler.test.ts,sessionEngine.test.ts}
│  ├─ speech/speechService.test.ts
│  ├─ cards/CardStudyPage.test.tsx
│  ├─ immersive/ImmersivePage.test.tsx
│  ├─ library/LibraryPage.test.tsx
│  ├─ records/statistics.test.ts
│  └─ backup/restoreBackup.test.ts
├─ e2e/
│  ├─ first-run.spec.ts
│  ├─ study-flow.spec.ts
│  ├─ immersive.spec.ts
│  ├─ import-backup.spec.ts
│  └─ offline.spec.ts
└─ docs/
   ├─ USER_GUIDE.md
   ├─ PACK_FORMAT.md
   ├─ BACKUP_FORMAT.md
   ├─ LOCAL_PREVIEW.md
   ├─ DEPLOY_GITHUB_PAGES.md
   └─ DEPLOY_VERCEL.md
```

---

### Task 1: Scaffold the application and lock the domain contracts

**Files:**
- Create: `package.json`
- Create: `vite.config.ts`
- Create: `playwright.config.ts`
- Create: `src/main.tsx`
- Create: `src/app/App.tsx`
- Create: `src/domain/models.ts`
- Create: `src/domain/constants.ts`
- Create: `src/domain/normalize.ts`
- Create: `src/domain/dates.ts`
- Create: `tests/setup.ts`
- Create: `tests/domain/normalize.test.ts`
- Create: `tests/domain/dates.test.ts`

**Interfaces:**
- Produces: all shared domain types used by every later task.
- Produces: `normalizeWordKey(word: string): string`.
- Produces: `addLocalDays(date: LocalDate, days: number): LocalDate` and `todayLocal(): LocalDate`.

- [ ] **Step 1: Create the Vite/React/TypeScript project and install runtime/test dependencies**

Run:

```bash
cd /mnt/data/ci-ji-pwa
npm init -y
npm install react react-dom react-router-dom idb zod fflate lucide-react
npm install -D typescript vite @vitejs/plugin-react vite-plugin-pwa vitest jsdom @testing-library/react @testing-library/jest-dom @testing-library/user-event fake-indexeddb @playwright/test tsx
```

Replace `package.json` scripts with:

```json
{
  "scripts": {
    "dev": "vite",
    "build": "tsc -b && vite build",
    "preview": "vite preview",
    "test": "vitest run",
    "test:watch": "vitest",
    "test:e2e": "playwright test",
    "typecheck": "tsc -b --pretty false",
    "validate:pack": "tsx scripts/validate-pack.ts public/packs/2026-07-11-自然地理与环境-131词.json"
  }
}
```

Expected: npm creates `package-lock.json`; `npm run dev -- --host 127.0.0.1` starts without dependency errors.

- [ ] **Step 2: Write failing normalization and local-date tests**

Create `tests/domain/normalize.test.ts`:

```ts
import { describe, expect, it } from 'vitest';
import { normalizeWordKey } from '../../src/domain/normalize';

describe('normalizeWordKey', () => {
  it('trims, lowercases, collapses spaces, and normalizes curly apostrophes', () => {
    expect(normalizeWordKey("  Earth’S   atmosphere  ")).toBe("earth's atmosphere");
  });

  it('does not conflate different word forms', () => {
    expect(normalizeWordKey('pollute')).not.toBe(normalizeWordKey('pollution'));
  });
});
```

Create `tests/domain/dates.test.ts`:

```ts
import { describe, expect, it } from 'vitest';
import { addLocalDays, isLocalDate } from '../../src/domain/dates';

describe('local date helpers', () => {
  it('adds calendar days without UTC conversion', () => {
    expect(addLocalDays('2026-07-11', 1)).toBe('2026-07-12');
    expect(addLocalDays('2026-12-31', 1)).toBe('2027-01-01');
  });

  it('validates the exact YYYY-MM-DD representation', () => {
    expect(isLocalDate('2026-07-11')).toBe(true);
    expect(isLocalDate('2026-7-11')).toBe(false);
  });
});
```

- [ ] **Step 3: Run the tests and verify failure**

Run:

```bash
npm test -- tests/domain/normalize.test.ts tests/domain/dates.test.ts
```

Expected: FAIL because `src/domain/normalize.ts` and `src/domain/dates.ts` do not exist.

- [ ] **Step 4: Add the shared domain contracts and minimal helpers**

Create `src/domain/models.ts`:

```ts
export type LocalDate = `${number}-${number}-${number}`;
export type Rating = 'unknown' | 'fuzzy' | 'known';
export type MasteryStatus = 'unseen' | Rating;
export type LearningDirection = 'en-zh' | 'zh-en';
export type Accent = 'en-GB' | 'en-US';
export type ThemeMode = 'light' | 'dark' | 'system';
export type FontSize = 'small' | 'medium' | 'large';
export type ListDensity = 'compact' | 'comfortable';
export type PackOrderMode = 'source' | 'random';

export interface BilingualText { en: string; zh: string }

export interface WordEntry {
  id: string;
  normalizedKey: string;
  word: string;
  phoneticUK: string | null;
  phoneticUS: string | null;
  partOfSpeech: string[];
  meanings: string[];
  supplementaryMeanings: string[];
  categories: string[];
  phrases: BilingualText[];
  examples: BilingualText[];
  confusables: string[];
  audioUK: string | null;
  audioUS: string | null;
  appearedDates: LocalDate[];
  occurrenceCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface DailyPack {
  id: string;
  schemaVersion: 1;
  date: LocalDate;
  theme: string;
  wordCount: number;
  createdAt: string;
  notes: string;
  wordIds: string[];
  categories: string[];
}

export interface StudyEvent {
  id: string;
  wordId: string;
  packId: string | null;
  rating: Rating;
  studiedAt: string;
  localDate: LocalDate;
  direction: LearningDirection;
  phase: 'first-pass' | 'reinforcement' | 'review';
}

export interface StudyState {
  wordId: string;
  status: MasteryStatus;
  consecutiveKnown: number;
  nextReviewDate: LocalDate | null;
  lastStudiedAt: string | null;
  knownCount: number;
  fuzzyCount: number;
  unknownCount: number;
}

export interface SessionCard {
  wordId: string;
  phase: 'first-pass' | 'reinforcement' | 'review';
}

export interface StudySession {
  id: string;
  packId: string | null;
  kind: 'daily' | 'review';
  direction: LearningDirection;
  queue: SessionCard[];
  cursor: number;
  firstPassSeenWordIds: string[];
  ratingCounts: Record<Rating, number>;
  undo: { card: SessionCard; previousState: StudyState | null; eventId: string } | null;
  completedFirstPassAt: string | null;
  completedAt: string | null;
  updatedAt: string;
}

export interface AppSettings {
  id: 'singleton';
  direction: LearningDirection;
  showPhonetic: boolean;
  gesturesEnabled: boolean;
  defaultOrder: PackOrderMode;
  fontSize: FontSize;
  accent: Accent;
  speechRate: 0.75 | 0.85 | 1 | 1.15;
  autoSpeakCards: boolean;
  autoSpeakImmersive: boolean;
  theme: ThemeMode;
  immersiveDensity: ListDensity;
  onboardingSeen: boolean;
  gestureHintSeen: boolean;
}

export interface ImportRecord {
  id: string;
  fileName: string;
  packId: string;
  importedAt: string;
  newWordCount: number;
  linkedWordCount: number;
  supplementedWordCount: number;
}

export interface TrashRecord {
  id: string;
  word: WordEntry;
  deletedAt: string;
  expiresAt: string;
}
```

Create `src/domain/constants.ts`:

```ts
import type { AppSettings } from './models';

export const DEFAULT_SETTINGS: AppSettings = {
  id: 'singleton', direction: 'en-zh', showPhonetic: true,
  gesturesEnabled: false, defaultOrder: 'source', fontSize: 'medium',
  accent: 'en-GB', speechRate: 0.85, autoSpeakCards: true,
  autoSpeakImmersive: true, theme: 'light', immersiveDensity: 'comfortable',
  onboardingSeen: false, gestureHintSeen: false,
};

export const RATING_LABELS = {
  unknown: '不认识', fuzzy: '模糊', known: '认识',
} as const;
```

Create `src/domain/normalize.ts`:

```ts
export function normalizeWordKey(word: string): string {
  return word
    .trim()
    .toLocaleLowerCase('en')
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/\s+/g, ' ');
}
```

Create `src/domain/dates.ts`:

```ts
import type { LocalDate } from './models';

export function isLocalDate(value: string): value is LocalDate {
  return /^\d{4}-\d{2}-\d{2}$/.test(value);
}

export function todayLocal(now = new Date()): LocalDate {
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}` as LocalDate;
}

export function addLocalDays(date: LocalDate, days: number): LocalDate {
  const [year, month, day] = date.split('-').map(Number);
  const localNoon = new Date(year, month - 1, day, 12, 0, 0, 0);
  localNoon.setDate(localNoon.getDate() + days);
  return todayLocal(localNoon);
}
```

Create `tests/setup.ts`:

```ts
import '@testing-library/jest-dom/vitest';
import 'fake-indexeddb/auto';
```

Configure Vitest in `vite.config.ts` to use `jsdom`, `tests/setup.ts`, and React plugin.

- [ ] **Step 5: Run unit tests, typecheck, and commit**

Run:

```bash
npm test -- tests/domain/normalize.test.ts tests/domain/dates.test.ts
npm run typecheck
```

Expected: all tests PASS and typecheck exits 0.

Commit:

```bash
git add package.json package-lock.json vite.config.ts tsconfig*.json index.html src tests playwright.config.ts
git commit -m "chore: scaffold ci ji app and define domain contracts"
```

---

### Task 2: Build the IndexedDB data layer and transactional repositories

**Files:**
- Create: `src/db/schema.ts`
- Create: `src/db/openDb.ts`
- Create: `src/db/repositories.ts`
- Create: `src/db/transactions.ts`
- Create: `tests/db/repositories.test.ts`

**Interfaces:**
- Consumes: domain types from Task 1.
- Produces: `openCiJiDb(name?: string): Promise<IDBPDatabase<CiJiDb>>`.
- Produces: repository factories `wordRepository`, `packRepository`, `studyRepository`, `settingsRepository`, `sessionRepository`, `importRepository`, `trashRepository`.
- Produces: `runReadWriteTransaction(storeNames, callback)` for all-or-nothing imports/restores.

- [ ] **Step 1: Write failing repository tests**

Create `tests/db/repositories.test.ts` with isolated database names:

```ts
import { afterEach, describe, expect, it } from 'vitest';
import { deleteDB } from 'idb';
import { createRepositories } from '../../src/db/repositories';
import { DEFAULT_SETTINGS } from '../../src/domain/constants';

const names: string[] = [];
const nextName = () => { const name = `ci-ji-test-${crypto.randomUUID()}`; names.push(name); return name; };
afterEach(async () => Promise.all(names.splice(0).map(deleteDB)));

describe('IndexedDB repositories', () => {
  it('stores a word and resolves it by normalized key', async () => {
    const repos = await createRepositories(nextName());
    const word = {
      id: 'word-atmosphere', normalizedKey: 'atmosphere', word: 'atmosphere',
      phoneticUK: '/ˈætməsfɪə/', phoneticUS: null, partOfSpeech: ['n.'],
      meanings: ['大气', '大气层'], supplementaryMeanings: [], categories: ['地球结构与圈层'],
      phrases: [], examples: [], confusables: [], audioUK: null, audioUS: null,
      appearedDates: ['2026-07-11'] as const, occurrenceCount: 1,
      createdAt: '2026-07-11T00:00:00.000Z', updatedAt: '2026-07-11T00:00:00.000Z',
    };
    await repos.words.put(word);
    expect((await repos.words.getByNormalizedKey('atmosphere'))?.id).toBe(word.id);
  });

  it('creates default settings exactly once', async () => {
    const repos = await createRepositories(nextName());
    expect(await repos.settings.get()).toEqual(DEFAULT_SETTINGS);
    await repos.settings.patch({ theme: 'dark' });
    expect((await repos.settings.get()).theme).toBe('dark');
  });
});
```

- [ ] **Step 2: Run the repository test and verify failure**

Run:

```bash
npm test -- tests/db/repositories.test.ts
```

Expected: FAIL because the database files do not exist.

- [ ] **Step 3: Define the database schema and indexes**

Create `src/db/schema.ts` with `DBSchema` stores:

```ts
import type { DBSchema } from 'idb';
import type { AppSettings, DailyPack, ImportRecord, StudyEvent, StudySession, StudyState, TrashRecord, WordEntry } from '../domain/models';

export interface CiJiDb extends DBSchema {
  words: { key: string; value: WordEntry; indexes: { 'by-normalized': string; 'by-updated': string } };
  packs: { key: string; value: DailyPack; indexes: { 'by-date': string } };
  studyStates: { key: string; value: StudyState; indexes: { 'by-status': string; 'by-next-review': string } };
  studyEvents: { key: string; value: StudyEvent; indexes: { 'by-word': string; 'by-local-date': string } };
  sessions: { key: string; value: StudySession; indexes: { 'by-updated': string } };
  settings: { key: 'singleton'; value: AppSettings };
  imports: { key: string; value: ImportRecord; indexes: { 'by-imported': string } };
  trash: { key: string; value: TrashRecord; indexes: { 'by-expires': string } };
  meta: { key: string; value: { key: string; value: unknown } };
}
```

Create `src/db/openDb.ts` with version `1`, all stores, and exact indexes. The database name defaults to `ci-ji` but accepts an override for tests.

- [ ] **Step 4: Implement focused repositories and settings initialization**

Implement `createRepositories(dbName?: string)` returning repository objects with these exact methods:

```ts
words: {
  get(id: string): Promise<WordEntry | undefined>;
  getMany(ids: string[]): Promise<WordEntry[]>;
  getAll(): Promise<WordEntry[]>;
  getByNormalizedKey(key: string): Promise<WordEntry | undefined>;
  put(word: WordEntry): Promise<void>;
  delete(id: string): Promise<void>;
};
packs: {
  get(id: string): Promise<DailyPack | undefined>;
  getByDate(date: LocalDate): Promise<DailyPack[]>;
  getAll(): Promise<DailyPack[]>;
  put(pack: DailyPack): Promise<void>;
};
studyStates: {
  get(wordId: string): Promise<StudyState | undefined>;
  put(state: StudyState): Promise<void>;
  getDue(onOrBefore: LocalDate): Promise<StudyState[]>;
};
studyEvents: {
  add(event: StudyEvent): Promise<void>;
  delete(id: string): Promise<void>;
  getByWord(wordId: string): Promise<StudyEvent[]>;
  getAll(): Promise<StudyEvent[]>;
};
sessions: {
  get(id: string): Promise<StudySession | undefined>;
  put(session: StudySession): Promise<void>;
  delete(id: string): Promise<void>;
};
settings: {
  get(): Promise<AppSettings>;
  patch(patch: Partial<Omit<AppSettings, 'id'>>): Promise<AppSettings>;
};
imports: { add(record: ImportRecord): Promise<void>; getAll(): Promise<ImportRecord[]> };
trash: { put(record: TrashRecord): Promise<void>; getAll(): Promise<TrashRecord[]>; restore(id: string): Promise<WordEntry>; purgeExpired(nowIso: string): Promise<number> };
```

Use one transaction per repository mutation, initialize `DEFAULT_SETTINGS` lazily in `settings.get()`, and preserve array order in `getMany`.

- [ ] **Step 5: Add a general all-or-nothing transaction helper**

Create `src/db/transactions.ts`:

```ts
import type { IDBPDatabase, StoreNames } from 'idb';
import type { CiJiDb } from './schema';

export async function runReadWriteTransaction<T>(
  db: IDBPDatabase<CiJiDb>,
  storeNames: StoreNames<CiJiDb>[],
  work: (tx: ReturnType<IDBPDatabase<CiJiDb>['transaction']>) => Promise<T>,
): Promise<T> {
  const tx = db.transaction(storeNames, 'readwrite');
  try {
    const result = await work(tx as never);
    await tx.done;
    return result;
  } catch (error) {
    tx.abort();
    throw error;
  }
}
```

Adjust the type annotation to compile against the installed `idb` version without using `any` in public interfaces.

- [ ] **Step 6: Run data-layer tests and commit**

Run:

```bash
npm test -- tests/db/repositories.test.ts
npm run typecheck
```

Expected: PASS; no IndexedDB connections leak after test cleanup.

Commit:

```bash
git add src/db tests/db
git commit -m "feat: add indexeddb repositories and transactions"
```

---

### Task 3: Validate, preview, merge, and transactionally import daily word packs

**Files:**
- Create: `src/packs/packSchema.ts`
- Create: `src/packs/parsePack.ts`
- Create: `src/packs/mergeWord.ts`
- Create: `src/packs/previewImport.ts`
- Create: `src/packs/commitImport.ts`
- Create: `tests/fixtures/samplePack.ts`
- Create: `tests/packs/parsePack.test.ts`
- Create: `tests/packs/previewImport.test.ts`
- Create: `tests/packs/commitImport.test.ts`

**Interfaces:**
- Produces: `parsePackJson(text: string): PackParseResult`.
- Produces: `buildImportPreview(pack, existingWords): ImportPreview`.
- Produces: `mergeWord(existing, incoming, choice): WordEntry`.
- Produces: `commitPackImport(db, preview, resolutions): Promise<ImportRecord>`.

- [ ] **Step 1: Define sample pack fixtures and failing validation tests**

Create a two-word valid fixture and invalid variants. Test exact failures for malformed JSON, missing date/theme, mismatched `wordCount`, empty word, empty meanings, and unsupported `schemaVersion`.

Core assertion example:

```ts
const result = parsePackJson(JSON.stringify(validPack));
expect(result.ok).toBe(true);
if (result.ok) expect(result.pack.words).toHaveLength(2);
```

Expected issue format:

```ts
interface PackIssue {
  code: 'json' | 'schema' | 'count' | 'unsupported-version';
  path: string;
  message: string;
  wordIndex: number | null;
}
```

- [ ] **Step 2: Run pack tests and verify failure**

Run:

```bash
npm test -- tests/packs/parsePack.test.ts tests/packs/previewImport.test.ts tests/packs/commitImport.test.ts
```

Expected: FAIL because pack modules do not exist.

- [ ] **Step 3: Implement the Zod pack schema and parser**

Create `src/packs/packSchema.ts` with strict top-level schema version `1` and nullable audio/phonetic fields. Normalize empty optional strings to `null`, but reject empty `word` and an empty `meanings` array.

The parsed pack contract is:

```ts
export interface IncomingPack {
  schemaVersion: 1;
  date: LocalDate;
  theme: string;
  wordCount: number;
  createdAt: string;
  notes: string;
  words: IncomingWord[];
}
```

`parsePackJson` must return `{ ok: true, pack }` or `{ ok: false, issues }` and never throw for user-provided text.

- [ ] **Step 4: Implement preview classification and deterministic merge rules**

For each incoming word, calculate its normalized key and classify as:

```ts
type PreviewAction = 'create' | 'link-identical' | 'supplement' | 'conflict' | 'invalid';
```

`ImportPreview` must include counts, category counts, and one `PreviewWord` row per source word preserving original order.

Implement `mergeWord` rules:

- union arrays while preserving existing order;
- fill missing phonetics/audio from incoming values;
- append new categories, phrases, examples, confusables, and supplementary meanings;
- add the pack date once and increment occurrence count once for that new pack;
- never change study state or history;
- conflict resolution choices are exactly `merge`, `keep-existing`, `use-incoming`, `skip`.

- [ ] **Step 5: Implement all-or-nothing import commit**

`commitPackImport` must use one IndexedDB transaction covering `words`, `packs`, and `imports`. Before writing, call `navigator.storage.estimate()` when available and stop if estimated free quota is below the JSON payload size plus a 1 MB safety margin.

The transaction must:

1. reject a duplicate pack id unless the caller explicitly chooses replace;
2. create/link/merge words according to preview and explicit conflict resolutions;
3. preserve source order in `DailyPack.wordIds`;
4. write the `DailyPack` and one `ImportRecord`;
5. abort on any exception so no store receives partial data.

Add a test that deliberately throws after the first word write and asserts that no word, pack, or import record remains.

- [ ] **Step 6: Run pack tests and commit**

Run:

```bash
npm test -- tests/packs
npm run typecheck
```

Expected: all pack tests PASS, including transaction rollback.

Commit:

```bash
git add src/packs tests/packs tests/fixtures
git commit -m "feat: add validated transactional word pack import"
```

---

### Task 4: Produce and preload the validated 131-word seed pack

**Files:**
- Create: `public/packs/2026-07-11-自然地理与环境-131词.json`
- Create: `scripts/validate-pack.ts`
- Create: `src/db/seed.ts`
- Create: `tests/db/seed.test.ts`
- Reference source images: `/mnt/data/IMG_20260711_163242.jpg`, `/mnt/data/IMG_20260711_163251.jpg`, `/mnt/data/IMG_20260711_163259.jpg`, `/mnt/data/IMG_20260711_163304.jpg`

**Interfaces:**
- Produces: `ensureBundledSeedImported(repositories): Promise<'imported' | 'already-present'>`.
- Produces: a standalone JSON file accepted by Task 3’s parser.

- [ ] **Step 1: Add a failing seed validation test**

Create `tests/db/seed.test.ts` to load the public JSON file and assert:

```ts
expect(pack.schemaVersion).toBe(1);
expect(pack.date).toBe('2026-07-11');
expect(pack.theme).toBe('自然地理与环境');
expect(pack.wordCount).toBe(131);
expect(pack.words).toHaveLength(131);
expect(new Set(pack.words.map((item) => normalizeWordKey(item.word))).size).toBe(131);
expect(pack.words[0].word).toBe('atmosphere');
expect(pack.words.at(-1)?.word).toBe('upgrade');
```

Also assert every word has at least one category, one part of speech, one Chinese meaning, and a non-empty British phonetic unless the source genuinely lacks a reliable phonetic and the value is explicitly `null`.

- [ ] **Step 2: Transcribe, correct, categorize, and validate all 131 rows**

Create the pack JSON in source order 1–131 from the four supplied images. Apply the agreed editorial corrections, including:

- `temperate`: adjective, `温带的；气候温和的`;
- `eco-friendly`: adjective, `环保的；对环境友好的`;
- `thermodynamic`: adjective, `热力学的`;
- `precipitation`: noun, `降水；降水量`;
- `current`: adjective and noun senses where present, `当前的；水流；电流`;
- `alternative`: adjective, `替代的；可供选择的`;
- `fog`: noun, `雾`;
- `fume`: noun, `烟气；有害气体`;
- `recycle`: verb, `回收利用；再循环`;
- `upgrade`: verb, `升级；改进`.

Assign one or more of these controlled categories to every item:

```text
地球结构与方位
地形地貌
地质活动与灾害
气象与气候
生态与环境保护
能源与污染
过程与变化
通用学术词汇
```

Use standard British IPA, standardize parts of speech to `n.`, `v.`, `adj.`, `adv.`, and add only concise, reliable phrases/examples; do not invent uncertain data.

- [ ] **Step 3: Implement the standalone validator script**

Create `scripts/validate-pack.ts`:

```ts
import { readFile } from 'node:fs/promises';
import { parsePackJson } from '../src/packs/parsePack';

const file = process.argv[2];
if (!file) throw new Error('Usage: npm run validate:pack -- <path>');
const result = parsePackJson(await readFile(file, 'utf8'));
if (!result.ok) {
  console.error(JSON.stringify(result.issues, null, 2));
  process.exit(1);
}
console.log(`VALID ${result.pack.date} ${result.pack.theme} ${result.pack.wordCount}`);
```

- [ ] **Step 4: Implement idempotent first-run seed import**

`ensureBundledSeedImported` must fetch the bundled JSON, parse it, check a meta key `seed:2026-07-11:v1`, import through the same preview/commit path used for user files, and set the meta key only after successful commit. A second call returns `already-present` and makes no writes.

- [ ] **Step 5: Run seed validation and commit**

Run:

```bash
npm run validate:pack
npm test -- tests/db/seed.test.ts
```

Expected output begins with:

```text
VALID 2026-07-11 自然地理与环境 131
```

Commit:

```bash
git add public/packs scripts/validate-pack.ts src/db/seed.ts tests/db/seed.test.ts
git commit -m "feat: add validated 131-word geography seed pack"
```

---

### Task 5: Implement app shell, navigation, settings, theme, and onboarding

**Files:**
- Create: `src/app/AppShell.tsx`
- Create: `src/app/routes.tsx`
- Create: `src/components/BottomNav.tsx`
- Create: `src/settings/settingsRepository.ts`
- Create: `src/settings/SettingsProvider.tsx`
- Create: `src/settings/SettingsPage.tsx`
- Create: `src/onboarding/Onboarding.tsx`
- Create: `src/app/styles/tokens.css`
- Create: `src/app/styles/global.css`
- Create: `tests/settings/SettingsProvider.test.tsx`
- Create: `tests/onboarding/Onboarding.test.tsx`

**Interfaces:**
- Produces: `useSettings()` with `{ settings, patchSettings, isReady }`.
- Produces: four persistent routes `/`, `/library`, `/records`, `/settings` plus nested feature routes.

- [ ] **Step 1: Write failing settings persistence and onboarding tests**

Test that defaults are British/0.85/light/medium, patching theme persists after remount, first launch shows three onboarding pages, skip sets `onboardingSeen`, and settings can reopen the onboarding route.

- [ ] **Step 2: Run UI tests and verify failure**

Run:

```bash
npm test -- tests/settings tests/onboarding
```

Expected: FAIL because providers/pages do not exist.

- [ ] **Step 3: Implement settings context and root theme application**

`SettingsProvider` loads from IndexedDB before rendering children, writes patches immediately, and applies these root attributes:

```ts
document.documentElement.dataset.theme = resolvedTheme;
document.documentElement.dataset.fontSize = settings.fontSize;
document.documentElement.dataset.listDensity = settings.immersiveDensity;
```

For `theme: 'system'`, subscribe to `matchMedia('(prefers-color-scheme: dark)')` and remove the listener on unmount.

- [ ] **Step 4: Implement the mobile app shell and exact navigation**

Bottom navigation entries are exactly:

```ts
[
  { to: '/', label: '首页' },
  { to: '/library', label: '词库' },
  { to: '/records', label: '记录' },
  { to: '/settings', label: '设置' },
]
```

Use `aria-current="page"`, 44px minimum targets, safe-area padding, no hover-only behavior, and hide the bottom navigation on full-screen card/immersive routes.

- [ ] **Step 5: Implement three-step onboarding and settings controls**

Onboarding pages use the exact sequence:

1. `导入每日词包`
2. `判断认识、模糊、不认识`
3. `用沉浸词表快速浏览`

Settings must expose every confirmed control, current app version, current selected theme/accent/rate/size, and a `重新查看新手引导` action.

- [ ] **Step 6: Add global visual tokens and responsive rules**

Define semantic variables for light/dark backgrounds, surfaces, borders, text, accent, known/fuzzy/unknown states, safe areas, and three font scales. Honor `prefers-reduced-motion: reduce` by disabling nonessential card/list transitions.

- [ ] **Step 7: Run tests, render a mobile smoke check, and commit**

Run:

```bash
npm test -- tests/settings tests/onboarding
npm run typecheck
npm run build
```

Expected: PASS and production build succeeds.

Commit:

```bash
git add src/app src/components src/settings src/onboarding tests/settings tests/onboarding
git commit -m "feat: add app shell settings themes and onboarding"
```

---

### Task 6: Add pronunciation with British/American selection and audio fallback

**Files:**
- Create: `src/speech/speechService.ts`
- Create: `src/speech/useSpeech.ts`
- Create: `src/speech/SpeechButton.tsx`
- Create: `tests/speech/speechService.test.ts`

**Interfaces:**
- Produces: `selectVoice(voices, accent): SpeechSynthesisVoice | null`.
- Produces: `speakWord(word, options): Promise<SpeechResult>`.
- Produces: `useSpeech()` with current voice name, availability, `speak`, and `cancel`.

- [ ] **Step 1: Write failing voice selection and fallback tests**

Cover:

- British preference picks `en-GB` before generic English;
- American preference picks `en-US`;
- generic English fallback is used when requested accent is absent;
- attached audio URL is attempted before speech synthesis;
- audio error falls back to speech synthesis;
- long press requests rate `0.75` without changing persisted settings.

- [ ] **Step 2: Run tests and verify failure**

Run:

```bash
npm test -- tests/speech/speechService.test.ts
```

Expected: FAIL because speech service does not exist.

- [ ] **Step 3: Implement deterministic voice scoring**

Score voices by:

1. exact `lang` match (`en-GB` or `en-US`);
2. voice name containing `United Kingdom`/`British` or `United States`/`American`;
3. generic `en-*`;
4. no voice returns `null`.

Wait for the browser’s `voiceschanged` event when `getVoices()` initially returns an empty list, but resolve with a timeout so playback cannot hang forever.

- [ ] **Step 4: Implement independent-audio-first playback**

`speakWord` options:

```ts
interface SpeakOptions {
  accent: 'en-GB' | 'en-US';
  rate: 0.75 | 0.85 | 1 | 1.15;
  audioUrl: string | null;
  signal?: AbortSignal;
}
```

Return:

```ts
type SpeechResult =
  | { ok: true; source: 'audio' | 'synthesis'; voiceName: string | null }
  | { ok: false; reason: 'unsupported' | 'cancelled' | 'playback-failed' };
```

Always synthesize `word`, never IPA. Cancel previous utterances before a new card speaks. Surface a Chinese error message through the hook rather than throwing into the page.

- [ ] **Step 5: Implement accessible click and long-press button behavior**

The button must have `aria-label="播放读音"`; pointer down longer than 450ms triggers one slow playback and suppresses the following click; keyboard Enter/Space uses normal speed.

- [ ] **Step 6: Run tests and commit**

Run:

```bash
npm test -- tests/speech
npm run typecheck
```

Commit:

```bash
git add src/speech tests/speech
git commit -m "feat: add pronunciation service with audio fallback"
```

---

### Task 7: Implement the review scheduler and resumable session engine

**Files:**
- Create: `src/study/scheduler.ts`
- Create: `src/study/sessionEngine.ts`
- Create: `src/study/studyRepository.ts`
- Create: `tests/study/scheduler.test.ts`
- Create: `tests/study/sessionEngine.test.ts`

**Interfaces:**
- Produces: `applyRating(previous, rating, localDate, studiedAt): StudyState`.
- Produces: `createDailySession(pack, settings, random): StudySession`.
- Produces: `createReviewSession(dueStates, random): StudySession`.
- Produces: `rateCurrentCard(session, state, rating, random): SessionMutation`.
- Produces: `undoLastRating(session): UndoMutation`.

- [ ] **Step 1: Write exact scheduler tests**

Assert the date table:

```ts
expect(applyRating(undefined, 'unknown', '2026-07-11', now).nextReviewDate).toBe('2026-07-12');
expect(applyRating(undefined, 'fuzzy', '2026-07-11', now).nextReviewDate).toBe('2026-07-13');
expect(applyRating(undefined, 'known', '2026-07-11', now).nextReviewDate).toBe('2026-07-14');
```

Then assert consecutive known dates at 7, 15, and 30 days; any unknown resets the streak to zero; fuzzy resets to zero and schedules two days.

- [ ] **Step 2: Write exact session queue tests**

Inject a deterministic random function. Assert:

- source order is preserved for first pass;
- unknown reinforcement index is current + integer in `[3,5]`;
- fuzzy reinforcement index is current + integer in `[8,12]`;
- known is not inserted;
- first-pass progress counts unique first-pass word ids only;
- reinforcement cards carry `phase: 'reinforcement'`;
- completing all first-pass cards sets `completedFirstPassAt` even while reinforcement remains;
- session JSON can be persisted and resumed at the same cursor;
- undo removes the event, restores the prior state, returns the card to the current position, and clears the one-level undo slot.

- [ ] **Step 3: Run study tests and verify failure**

Run:

```bash
npm test -- tests/study
```

Expected: FAIL because study modules do not exist.

- [ ] **Step 4: Implement the pure scheduler**

Use this exact known interval map:

```ts
const KNOWN_INTERVALS = [3, 7, 15, 30] as const;
const days = KNOWN_INTERVALS[Math.min(consecutiveKnown - 1, KNOWN_INTERVALS.length - 1)];
```

Keep all calculations pure and based on injected `localDate`/`studiedAt`, never `Date.now()` inside the function.

- [ ] **Step 5: Implement the pure session engine**

Do not mutate input session/state objects. Return:

```ts
interface SessionMutation {
  session: StudySession;
  nextState: StudyState;
  event: StudyEvent;
  previousState: StudyState | null;
}
```

Use deterministic id factories in tests and crypto UUID in production wrappers. Distinguish first-pass and reinforcement counts so the visible numerator cannot exceed pack size.

- [ ] **Step 6: Add atomic persistence wrapper**

`studyRepository.commitRating(mutation)` writes state, event, and session in one transaction. `undoLast(sessionId)` deletes the event, restores/deletes the previous state as applicable, and persists the rewound session in one transaction.

- [ ] **Step 7: Run tests and commit**

Run:

```bash
npm test -- tests/study
npm run typecheck
```

Commit:

```bash
git add src/study tests/study
git commit -m "feat: add transparent review scheduler and session engine"
```

---

### Task 8: Build the full-screen card study experience

**Files:**
- Create: `src/cards/CardStudyPage.tsx`
- Create: `src/cards/StudyCard.tsx`
- Create: `src/cards/RatingBar.tsx`
- Create: `src/cards/useCardSession.ts`
- Create: `src/cards/card-study.css`
- Create: `tests/cards/CardStudyPage.test.tsx`

**Interfaces:**
- Consumes: pack/word repositories, Task 6 speech hook, Task 7 session engine.
- Produces routes: `/study/today`, `/study/review`, `/study/continue/:sessionId`.

- [ ] **Step 1: Write failing card interaction tests**

Test English → Chinese and Chinese → English. Required assertions:

- front shows word + British phonetic + speech button;
- rating buttons are absent or disabled before reveal;
- tapping card reveals part of speech + core Chinese meanings;
- `更多内容` expands phrases/examples/confusables only when data exists;
- rating saves once and advances;
- undo restores the previous card/status;
- reinforcement label shows while progress remains `47 / 131` style;
- auto-speak occurs on card entry, not flip;
- auto-speak off suppresses entry playback;
- unmount and remount resumes persisted cursor.

- [ ] **Step 2: Run the card tests and verify failure**

Run:

```bash
npm test -- tests/cards/CardStudyPage.test.tsx
```

Expected: FAIL because card components do not exist.

- [ ] **Step 3: Implement the session-loading hook**

`useCardSession` must:

1. load or create the correct daily/review session;
2. fetch the current word;
3. expose first-pass numerator/denominator separately from queue cursor;
4. persist after every rating;
5. expose `reveal`, `rate`, `undo`, `resetSession`, `restartViewKeepMastery`;
6. return explicit loading, empty, active, first-pass-complete, and fully-complete states.

- [ ] **Step 4: Implement card visual states and layered answer content**

Use a full-screen route without bottom navigation. Header contains back button, pack title, progress, and menu. Bottom rating bar is safe-area aware. Long meanings scroll inside the card without moving the rating buttons.

For missing phonetic display exactly `暂无音标`; do not hide the row silently.

- [ ] **Step 5: Implement optional gestures with protection**

Only enable after reveal and only when `gesturesEnabled` is true. Threshold is 72 CSS pixels. Directions are exact: left unknown, up fuzzy, right known. Below threshold, animate back. Buttons remain visible. On first enable, show one dismissible hint and persist `gestureHintSeen`.

- [ ] **Step 6: Implement completion and reset flows**

First-pass summary displays total and three counts, with `继续强化`, `返回首页`, and `进入沉浸词表`. Full completion shows a concise summary. Reset menu must distinguish:

- `重新开始本次学习`;
- `清空今日进度` (requires confirmation but not the global phrase because it is scoped to one pack);
- `从头浏览但保留掌握记录`.

- [ ] **Step 7: Run card tests, mobile component check, and commit**

Run:

```bash
npm test -- tests/cards
npm run typecheck
npm run build
```

Commit:

```bash
git add src/cards tests/cards
git commit -m "feat: add resumable card study experience"
```

---

### Task 9: Build the immersive single-open vocabulary list

**Files:**
- Create: `src/immersive/ImmersivePage.tsx`
- Create: `src/immersive/ImmersiveRow.tsx`
- Create: `src/immersive/immersiveQueries.ts`
- Create: `src/immersive/immersive.css`
- Create: `tests/immersive/ImmersivePage.test.tsx`

**Interfaces:**
- Route: `/immersive/:packId` and query parameters for order/filter/search.
- Does not write study states or events.

- [ ] **Step 1: Write failing immersive behavior tests**

Assert:

- all meanings start collapsed;
- clicking row A opens A;
- clicking row B closes A and opens B;
- clicking B again closes B;
- clicking the list background closes the open row;
- speech icon click does not toggle row;
- route/filter/order changes close any row;
- auto-speech can be disabled;
- source and grouped category modes render correct numbering/counts;
- scroll position saves on unmount and restores on return;
- no study event is written.

- [ ] **Step 2: Run immersive tests and verify failure**

Run:

```bash
npm test -- tests/immersive/ImmersivePage.test.tsx
```

- [ ] **Step 3: Implement query projection without changing source data**

`buildImmersiveRows(pack, words, states, options)` returns source-order rows or category groups and supports exact filters `all`, `unseen`, `fuzzy`, `unknown`. Search matches normalized English and Chinese meanings.

- [ ] **Step 4: Implement single-open row state and event boundaries**

Use one `openWordId: string | null`. Stop propagation on speech and action controls. Background close only fires when the target is the list container, not when text inside an expanded answer is tapped.

- [ ] **Step 5: Add category accordion and density modes**

Category headers show name and count, support expand all/collapse all, and preserve the invariant that only one word answer is open across all groups. Apply compact/comfortable spacing from settings.

- [ ] **Step 6: Run tests and commit**

Run:

```bash
npm test -- tests/immersive
npm run typecheck
```

Commit:

```bash
git add src/immersive tests/immersive
git commit -m "feat: add immersive single-open word list"
```

---

### Task 10: Implement the searchable library, editors, duplicate merge, and recycle bin

**Files:**
- Create: `src/library/LibraryPage.tsx`
- Create: `src/library/libraryQueries.ts`
- Create: `src/library/WordEditor.tsx`
- Create: `src/library/BulkPastePage.tsx`
- Create: `src/library/ImportPackPage.tsx`
- Create: `src/library/TrashPage.tsx`
- Create: `src/components/ConfirmPhraseDialog.tsx`
- Create: `tests/library/libraryQueries.test.ts`
- Create: `tests/library/LibraryPage.test.tsx`
- Create: `tests/library/BulkPastePage.test.tsx`

**Interfaces:**
- Produces filters by pack/date/status/learned/audio and sorts by source/alphabetical/recent-add/recent-study/error-count/occurrence-count.
- Produces a relaxed bulk parser with row-level errors.

- [ ] **Step 1: Write failing query and bulk parser tests**

Test English and Chinese search, every specified sort/filter, and these input lines:

```text
atmosphere | n. | 大气；大气层
humidity\tn.\t湿度
erode, v., 侵蚀
```

The parser must return three rows and mark ambiguous/missing rows with exact `lineNumber` and message instead of saving them.

- [ ] **Step 2: Run library tests and verify failure**

Run:

```bash
npm test -- tests/library
```

- [ ] **Step 3: Implement library projections and stable sorting**

All sorts must be stable and preserve source order as a final tie-breaker. Error count equals `unknownCount + fuzzyCount`; appearance frequency uses `occurrenceCount`.

- [ ] **Step 4: Implement pack import UI using Task 3 services**

The page must show three stages: check, preview, commit. Preview has tabs for all/new/duplicate/problem/category, count summary, and explicit conflict resolution. On failure, keep current data and display precise issues.

- [ ] **Step 5: Implement single-word editor and bulk paste preview**

Require word and at least one Chinese core meaning. Optional fields must map exactly to the domain model. Missing phonetic remains `null`. Editing a word that changes normalized key must check duplicates and branch to merge instead of silently creating two master records.

- [ ] **Step 6: Implement delete, restore, permanent purge, and manual duplicate merge**

Normal delete moves the whole `WordEntry` into `trash` with expiry 30 calendar days later and removes it from active packs only after showing affected pack counts. Restore re-links the saved word to its recorded dates. Manual merge presents both records side-by-side and preserves unioned dates/history/mastery using the same merge service.

- [ ] **Step 7: Implement destructive bulk confirmation**

`ConfirmPhraseDialog` enables the action only when the input equals `确认清空` exactly. Use it for clear-learning-history and clear-all-data actions; no alternate phrase is accepted.

- [ ] **Step 8: Run tests and commit**

Run:

```bash
npm test -- tests/library
npm run typecheck
```

Commit:

```bash
git add src/library src/components/ConfirmPhraseDialog.tsx tests/library
git commit -m "feat: add library import editing search and recycle bin"
```

---

### Task 11: Add smart home state and layered learning statistics

**Files:**
- Create: `src/home/homeQueries.ts`
- Create: `src/home/HomePage.tsx`
- Create: `src/records/statistics.ts`
- Create: `src/records/RecordsPage.tsx`
- Create: `src/records/RecordsDetailPage.tsx`
- Create: `tests/home/homeQueries.test.ts`
- Create: `tests/records/statistics.test.ts`

**Interfaces:**
- Produces: `buildHomeSummary(today, packs, states, sessions)`.
- Produces: `buildStatistics(events, words, packs, today)`.

- [ ] **Step 1: Write failing home-state tests**

Cover exact priority:

1. no today pack → `import` primary action;
2. incomplete first pass → `continue-study`;
3. first pass complete with reinforcement → `continue-reinforcement`;
4. otherwise completed state;
5. due review is separate and never blocks today action.

Also assert startup never calls speech.

- [ ] **Step 2: Write failing statistics tests**

Use fixed event fixtures to assert today counts, total unique words, mastery counts/percentages, consecutive learning days, 7-day series, 30-day series, theme mastery, high-error ranking, pack completion, and per-word chronological history.

- [ ] **Step 3: Run tests and verify failure**

Run:

```bash
npm test -- tests/home tests/records
```

- [ ] **Step 4: Implement the home query and minimal dashboard**

Show only the primary action, immersive entry, separate review action, today progress, due count, fuzzy count, unknown count, and in-app reminder text. Do not render dense charts on home.

- [ ] **Step 5: Implement framework-independent statistics**

Calculate percentages with zero-safe denominators. Consecutive days count backwards from today only if today or yesterday has activity, avoiding UTC conversions. Group themes by pack membership and count a master word once per theme.

- [ ] **Step 6: Render overview and detailed records**

Overview: today, total, three mastery states, streak, seven-day bars. Detail: 30-day trend, theme mastery, high-error words, daily pack completion, and word history. Use accessible SVG or semantic HTML; do not add a chart dependency.

- [ ] **Step 7: Run tests and commit**

Run:

```bash
npm test -- tests/home tests/records
npm run typecheck
```

Commit:

```bash
git add src/home src/records tests/home tests/records
git commit -m "feat: add smart home and learning records"
```

---

### Task 12: Implement complete backup, merge restore, replacement restore, and rollback

**Files:**
- Create: `src/backup/backupSchema.ts`
- Create: `src/backup/exportBackup.ts`
- Create: `src/backup/restoreBackup.ts`
- Create: `src/backup/BackupPage.tsx`
- Create: `tests/backup/restoreBackup.test.ts`

**Interfaces:**
- Produces: `exportCompleteBackup(db): Promise<Blob>`.
- Produces: `previewRestore(file): Promise<RestorePreview>`.
- Produces: `mergeRestore(db, backup, resolutions): Promise<RestoreReport>`.
- Produces: `replaceRestoreWithRollback(db, backup): Promise<RestoreReport>`.

- [ ] **Step 1: Write failing backup/restore tests**

Assert:

- JSON export contains words, packs, states, events, sessions, settings, imports, and metadata;
- filename format is `词迹完整备份-YYYY-MM-DD.json` when no independent audio exists;
- merge preserves current data and uses duplicate merge rules;
- replacement clears all relevant stores only after backup validation;
- simulated write failure restores the original snapshot;
- malformed or newer unsupported backup version causes no writes.

- [ ] **Step 2: Run tests and verify failure**

Run:

```bash
npm test -- tests/backup/restoreBackup.test.ts
```

- [ ] **Step 3: Implement versioned backup schema and exporter**

Use top-level:

```ts
interface CompleteBackupV1 {
  schemaVersion: 1;
  app: '词迹';
  exportedAt: string;
  localDate: LocalDate;
  data: {
    words: WordEntry[]; packs: DailyPack[]; studyStates: StudyState[];
    studyEvents: StudyEvent[]; sessions: StudySession[]; settings: AppSettings;
    imports: ImportRecord[]; trash: TrashRecord[];
  };
}
```

If any word has audio URL backed by an imported Blob store, export a ZIP containing `backup.json` and audio files; otherwise export JSON. In first release, bundled HTTP audio URLs do not require embedding.

- [ ] **Step 4: Implement preview and merge restore**

Validate first, produce counts/conflicts, then use one transaction and Task 3 merge semantics. Do not alter data during preview.

- [ ] **Step 5: Implement replacement restore with safety snapshot and rollback**

Algorithm:

1. validate backup fully;
2. read current stores into an in-memory safety snapshot;
3. open one readwrite transaction, clear/write all stores;
4. if transaction fails, open a second transaction and restore snapshot;
5. report whether rollback succeeded; never claim success if either operation failed.

The UI requires `确认清空` before replacement restore.

- [ ] **Step 6: Run tests and commit**

Run:

```bash
npm test -- tests/backup
npm run typecheck
```

Commit:

```bash
git add src/backup tests/backup
git commit -m "feat: add complete backup and safe restore"
```

---

### Task 13: Complete PWA branding, installability, offline cache, update prompt, and cache repair

**Files:**
- Modify: `vite.config.ts`
- Create: `src/app/UpdatePrompt.tsx`
- Create: `src/pwa/install.ts`
- Create: `src/pwa/cacheRepair.ts`
- Create: `public/icons/icon.svg`
- Create: `scripts/generate-icons.mjs`
- Create: `tests/pwa/cacheRepair.test.ts`

**Interfaces:**
- Produces install prompt state for supported Android browsers and instructions for iOS Safari.
- Produces `repairAppCache(): Promise<void>` that removes only Cache Storage entries owned by the app.

- [ ] **Step 1: Write failing cache-repair tests**

Mock `caches.keys()` with app and non-app names. Assert only names starting `ci-ji-` are deleted and IndexedDB is never opened or deleted.

- [ ] **Step 2: Configure manifest and service worker**

Use `VitePWA` with:

```ts
manifest: {
  name: '词迹', short_name: '词迹', lang: 'zh-CN',
  start_url: '/', display: 'standalone', orientation: 'portrait-primary',
  theme_color: '#0f766e', background_color: '#f4fbfa',
  icons: [
    { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png' },
    { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png' },
    { src: '/icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
  ]
}
```

Use `registerType: 'prompt'`, cache the app shell and bundled seed pack, and use navigation fallback. Do not cache arbitrary user audio URLs indefinitely.

- [ ] **Step 3: Create the A + trajectory icon source and generated sizes**

`icon.svg` must contain a bold, simple `A`, an ascending curved path with 3 nodes, and a blue-green gradient; no text besides the letterform. `scripts/generate-icons.mjs` renders 192, 512, maskable 512, and Apple touch icon. Use a deterministic local renderer installed as a dev dependency if necessary and commit the generated PNGs, not font files.

- [ ] **Step 4: Implement update and install UX**

On a waiting service worker, show `发现新版本` with `立即更新` and `稍后`. Updating calls the generated `updateServiceWorker(true)` and reloads only after the worker activates. Android install uses `beforeinstallprompt`; iOS shows Safari share → `添加到主屏幕` instructions.

- [ ] **Step 5: Implement cache repair**

Explain that repair removes app files only, not words or records. Delete only app-owned Cache Storage names, unregister current service workers, and reload after confirmation. Do not call `indexedDB.deleteDatabase`.

- [ ] **Step 6: Verify installability/offline build and commit**

Run:

```bash
npm test -- tests/pwa
npm run build
npx vite preview --host 127.0.0.1 --port 4173
```

In another shell, run a Lighthouse/PWA manual check or Playwright offline test from Task 14. Expected: manifest and service worker are served; reload works after taking browser context offline.

Commit:

```bash
git add vite.config.ts src/app/UpdatePrompt.tsx src/pwa public/icons scripts/generate-icons.mjs tests/pwa
git commit -m "feat: add installable offline pwa lifecycle"
```

---

### Task 14: Add end-to-end coverage, accessibility verification, documentation, and release packaging

**Files:**
- Create: `e2e/first-run.spec.ts`
- Create: `e2e/study-flow.spec.ts`
- Create: `e2e/immersive.spec.ts`
- Create: `e2e/import-backup.spec.ts`
- Create: `e2e/offline.spec.ts`
- Create: `docs/USER_GUIDE.md`
- Create: `docs/PACK_FORMAT.md`
- Create: `docs/BACKUP_FORMAT.md`
- Create: `docs/LOCAL_PREVIEW.md`
- Create: `docs/DEPLOY_GITHUB_PAGES.md`
- Create: `docs/DEPLOY_VERCEL.md`
- Create: `RELEASE_CHECKLIST.md`

**Interfaces:**
- Produces the first release zip containing source, `dist`, seed pack, corrected word table, and all documentation.

- [ ] **Step 1: Configure Playwright mobile projects**

Use Chromium with a Pixel-class viewport and WebKit with an iPhone-class viewport. Keep tests independent by clearing IndexedDB and service workers in `beforeEach` except the offline persistence test.

- [ ] **Step 2: Write first-run and complete study-flow E2E tests**

`first-run.spec.ts` must verify the three onboarding screens, preloaded 131 pack, four navigation tabs, and no sound on startup.

`study-flow.spec.ts` must verify reveal-before-rating, three rating buttons, progress unaffected by reinforcement, auto-resume after page reload, undo, first-pass completion, and Chinese → English mode without input fields.

- [ ] **Step 3: Write immersive, import, backup, and offline E2E tests**

`immersive.spec.ts`: single-open invariant, background close, category switch, speech icon does not toggle.

`import-backup.spec.ts`: import the bundled pack after deleting it, verify duplicate preview, export backup, clear data with exact phrase, restore, and recover 131 words.

`offline.spec.ts`: visit online, wait for service worker, close/reopen context offline, verify home/library/study still render and IndexedDB remains.

- [ ] **Step 4: Run the complete verification matrix**

Run:

```bash
npm test
npm run typecheck
npm run build
npx playwright install chromium webkit
npm run test:e2e
```

Expected: all unit/component/E2E tests PASS, typecheck exits 0, build exits 0.

- [ ] **Step 5: Perform manual mobile/accessibility checks**

Record results in `RELEASE_CHECKLIST.md` for:

- Android Chrome install/open/offline;
- Android Edge pronunciation and file import;
- iPhone Safari add-to-home-screen, file picker, safe areas, and speech fallback;
- 44px touch targets;
- light/dark/system themes;
- small/medium/large text and compact/comfortable list density;
- reduced motion;
- screen-reader labels for icon-only controls;
- long words and long meanings without overflow;
- destructive actions requiring `确认清空`.

Do not mark an item complete without observed evidence; record device/browser version and result.

- [ ] **Step 6: Write user and deployment documentation**

Documentation must include exact commands:

```bash
npm ci
npm run dev -- --host 0.0.0.0
npm run build
npm run preview -- --host 0.0.0.0
```

Explain PWA installation on Android and iPhone, how to import a daily JSON pack, how to use batch paste, how to export/restore backups, why system speech may require an installed voice, and how to deploy `dist` to GitHub Pages or Vercel without changing IndexedDB behavior.

`PACK_FORMAT.md` and `BACKUP_FORMAT.md` must include complete valid JSON examples matching the Zod schemas, field semantics, versioning, and conflict behavior.

- [ ] **Step 7: Build the release archive and verify its contents**

Run:

```bash
npm ci
npm run validate:pack
npm test
npm run build
mkdir -p release/词迹-PWA
rsync -a --exclude node_modules --exclude .git ./ release/词迹-PWA/
(cd release && zip -r 词迹-PWA-v1.zip 词迹-PWA)
unzip -l release/词迹-PWA-v1.zip | grep -E 'dist/|public/packs/2026-07-11|docs/USER_GUIDE.md'
```

Expected: archive contains source, `dist`, standalone 131-word pack, docs, tests, and no `node_modules` or `.git`.

- [ ] **Step 8: Final verification commit**

Commit:

```bash
git add e2e docs RELEASE_CHECKLIST.md playwright.config.ts release/词迹-PWA-v1.zip
git commit -m "test: verify and package ci ji pwa v1"
```

---

## Plan Self-Review Results

- **Spec coverage:** All confirmed sections are mapped: daily/total library, 131-word seed, import preview/transaction, duplicate merge, card and immersive flows, speech, same-day reinforcement, cross-day scheduling, local persistence, search/filter/sort, edit/trash, records, backup/restore, themes/settings/onboarding, PWA/offline/update/install/cache repair, accessibility, Android/iPhone checks, documentation, and packaging.
- **Explicit exclusions preserved:** no accounts, cloud sync, OCR, online AI categorization, system notifications, spelling tests, or native app package.
- **Placeholder scan:** No `TBD`, `TODO`, “implement later,” or unspecified test steps remain.
- **Type consistency:** Domain property names and exported signatures are fixed in Tasks 1–3 and referenced consistently thereafter.
- **Execution order:** Each task consumes only interfaces produced in earlier tasks and ends with an independently testable deliverable and commit.
