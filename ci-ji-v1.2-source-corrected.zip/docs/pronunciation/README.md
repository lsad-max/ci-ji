# Wikimedia 真人发音审核说明

## 文件

- `wikimedia-candidates.json`：候选发现脚本输出，不代表已批准。
- `wikimedia-review.csv`：每个词分别包含 `en-GB` 与 `en-US` 两个审核槽。
- `public/data/wikimedia-pronunciations.json`：只由构建脚本从审核 CSV 生成。

## 命令

```bash
npm run discover:pronunciations
npm run build:pronunciations
npm run validate:pronunciations
```

候选发现使用 Wikimedia/Wiktionary 的公开 API，并在 Node 请求中声明
`CiJiPronunciationAudit/1.2 (https://github.com/lsad-max/ci-ji)`。发现结果只能进入待审核列表，不能自动成为正式发音。

## 审核要求

每个口音槽必须打开 Commons 文件页并实际试听。只有同时满足以下条件才能填写 `approved`：目标单词正确、单词级录音、口音地区可确认、音质可用、作者与许可证完整、音频和文件页均为 HTTPS。无法确认时必须填写 `missing`。

## 当前基线状态

当前 CSV 为**保守基线**：262 个口音槽均标记为 `missing`。这不是“Wikimedia 没有录音”，而是尚未完成真人听觉审核；因此应用会继续使用同口音本地音频和系统语音降级。不得把该状态描述为“131 词真人录音已经审核完成”。

## 抽样复核记录

尚未进行真人听觉抽样。发布真人发音前至少完成 20 个槽的实际试听，其中必须包含 `atmosphere`、`climate`、`drought`、`earthquake`、`ecosystem`，并在此处记录审核者、日期、文件页和结论。
