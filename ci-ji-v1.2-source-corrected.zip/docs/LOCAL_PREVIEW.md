# 本地开发与预览

## 环境

- Node.js 20 或更高版本
- npm 10 或更高版本
- 支持 IndexedDB、Service Worker、Web Speech API 的现代浏览器

## 安装与开发

```bash
npm ci
npm run dev -- --host 0.0.0.0
```

终端会显示局域网地址。手机与电脑处于同一网络时，可用手机浏览器打开该地址。开发服务器通常是 HTTP；除 `localhost` 外，PWA 安装与 Service Worker 可能受浏览器安全策略限制。

## 生产构建与本地 PWA 预览

```bash
npm run build
npm run preview -- --host 0.0.0.0
```

默认预览端口由 Vite 给出。手机访问时应使用 HTTPS 反向代理，或部署到 Vercel / GitHub Pages 后测试安装和离线。

## 测试

```bash
npm run validate:pack
npm test
npm run typecheck
npm run build
npm run test:e2e
```
