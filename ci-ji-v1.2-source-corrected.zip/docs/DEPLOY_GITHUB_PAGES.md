# 部署到 GitHub Pages

本项目已针对仓库名 `ci-ji` 配置 GitHub Pages 子路径，正式网址为：

```text
https://lsad-max.github.io/ci-ji/
```

## 仓库要求

- 仓库所有者：`lsad-max`
- 仓库名称：`ci-ji`
- 默认分支：`main`
- GitHub Pages 发布源：`GitHub Actions`

## 自动部署

项目包含 `.github/workflows/deploy-pages.yml`。每次向 `main` 分支推送后，工作流会自动：

1. 安装依赖；
2. 运行测试；
3. 使用 `/ci-ji/` 作为 Vite 与 PWA 基础路径构建；
4. 上传 `dist`；
5. 发布到 GitHub Pages。

## 首次启用

进入仓库的 **Settings → Pages**，在 **Build and deployment → Source** 中选择 **GitHub Actions**。之后进入 **Actions** 页面运行或重新运行 `Deploy 词迹 to GitHub Pages`。

## 本地验证 Pages 构建

```bash
npm ci
npm test
CI_JI_BASE_PATH=/ci-ji/ npm run build
npm run preview -- --host 0.0.0.0
```

本地预览地址通常为：

```text
http://localhost:4173/ci-ji/
```

构建结果还会生成 `dist/404.html`，用于 GitHub Pages 在刷新应用内部路由时重新载入单页应用。
