/// <reference types="vitest/config" />
import { copyFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

function normalizeDeploymentBase(value: string | undefined): string {
  const trimmed = value?.trim() ?? '';
  if (!trimmed || trimmed === '/') return '/';
  const segment = trimmed.replace(/^\/+|\/+$/g, '');
  return segment ? `/${segment}/` : '/';
}

const base = normalizeDeploymentBase(process.env.CI_JI_BASE_PATH);

export default defineConfig({
  base,
  plugins: [
    react(),
    VitePWA({
      registerType: 'prompt',
      includeAssets: [
        'icons/apple-touch-icon.png',
        'icons/icon.svg',
        'packs/2026-07-11-自然地理与环境-131词.json',
        'data/wikimedia-pronunciations.json',
      ],
      manifest: {
        name: '词迹',
        short_name: '词迹',
        description: '每日识词与间隔复习',
        lang: 'zh-CN',
        start_url: base,
        scope: base,
        display: 'standalone',
        orientation: 'portrait-primary',
        theme_color: '#0f766e',
        background_color: '#f4fbfa',
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        cacheId: `ci-ji-app-${base.replace(/\W+/g, '-') || 'root'}`,
        navigateFallback: `${base}index.html`,
        globPatterns: ['**/*.{js,css,html,svg,png,json,mp3}'],
        cleanupOutdatedCaches: true,
        runtimeCaching: [],
      },
    }),
    {
      name: 'github-pages-spa-fallback',
      closeBundle() {
        if (base === '/') return;
        const indexPath = resolve('dist/index.html');
        if (existsSync(indexPath)) copyFileSync(indexPath, resolve('dist/404.html'));
      },
    },
  ],
  test: {
    environment: 'jsdom',
    setupFiles: ['./tests/setup.ts'],
    clearMocks: true,
    exclude: ['e2e/**', 'node_modules/**', 'dist/**', 'release/**'],
  },
});
