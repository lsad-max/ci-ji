const CACHE_PREFIX='ci-ji-';
export async function repairAppCache():Promise<void>{if(!('caches'in globalThis))return;const names=await caches.keys();await Promise.all(names.filter(name=>name.startsWith(CACHE_PREFIX)).map(name=>caches.delete(name)));}
export async function repairCacheAndReload():Promise<void>{await repairAppCache();if('serviceWorker'in navigator){const registrations=await navigator.serviceWorker.getRegistrations();await Promise.all(registrations.map(registration=>registration.unregister()));}location.reload();}
