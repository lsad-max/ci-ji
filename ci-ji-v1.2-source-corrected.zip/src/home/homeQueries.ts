import type { DailyPack, LocalDate, StudySession, StudyState } from '../domain/models';

export type HomePrimaryAction = 'import' | 'continue-study' | 'continue-reinforcement' | 'completed';
export interface HomeSummary {
  todayPack: DailyPack | null;
  session: StudySession | null;
  primaryAction: HomePrimaryAction;
  firstPassDone: number;
  firstPassTotal: number;
  reinforcementRemaining: number;
  dueCount: number;
  fuzzyCount: number;
  unknownCount: number;
  reminder: string;
}

export function buildHomeSummary(today: LocalDate, packs: DailyPack[], states: StudyState[], sessions: StudySession[]): HomeSummary {
  const todayPack = packs.find((pack) => pack.date === today) ?? null;
  const session = todayPack ? sessions.find((item) => item.id === `daily:${todayPack.id}`) ?? null : null;
  let primaryAction: HomePrimaryAction;
  if (!todayPack) primaryAction = 'import';
  else if (!session || !session.completedFirstPassAt) primaryAction = 'continue-study';
  else if (!session.completedAt && session.cursor < session.queue.length) primaryAction = 'continue-reinforcement';
  else primaryAction = 'completed';
  const dueCount = states.filter((state) => state.nextReviewDate !== null && state.nextReviewDate <= today).length;
  const reinforcementRemaining = session ? session.queue.slice(session.cursor).filter((card) => card.phase === 'reinforcement').length : 0;
  const reminder = !todayPack ? '今天还没有词包，导入后即可开始学习。'
    : primaryAction === 'continue-study' ? `今日词包尚未完成，还有${Math.max(0, todayPack.wordCount - (session?.firstPassSeenWordIds.length ?? 0))}个新词。`
    : primaryAction === 'continue-reinforcement' ? `新词已浏览完成，还有${reinforcementRemaining}张强化卡片。`
    : dueCount ? `今日任务已完成，另有${dueCount}个旧词到期。` : '今日任务已完成。';
  return {
    todayPack, session, primaryAction,
    firstPassDone: session?.firstPassSeenWordIds.length ?? 0,
    firstPassTotal: todayPack?.wordCount ?? 0,
    reinforcementRemaining, dueCount,
    fuzzyCount: states.filter((state) => state.status === 'fuzzy').length,
    unknownCount: states.filter((state) => state.status === 'unknown').length,
    reminder,
  };
}
