import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Moon, RefreshCw, RotateCcw, Sun, Volume2 } from 'lucide-react';
import { SPEECH_RATES } from '../domain/constants';
import type { Accent, FontSize, LearningDirection, ThemeMode } from '../domain/models';
import type { PronunciationSourcePreference } from '../pronunciation/types';
import { clearPronunciationCache, getPronunciationCacheStats } from '../pronunciation/audioCache';
import { useSpeech } from '../speech/useSpeech';
import { useSettings } from './SettingsProvider';
import { InstallPanel } from '../pwa/InstallPanel';

const SAMPLE_WORD = {
  word: 'atmosphere',
  audioUK: 'audio/en-GB/001-atmosphere.mp3',
  audioUS: 'audio/en-US/001-atmosphere.mp3',
};

function SelectRow({ label, value, onChange, children }: { label: string; value: string | number; onChange: (value: string) => void; children: React.ReactNode }) {
  return <label className="setting-row"><span>{label}</span><select value={value} onChange={(event) => onChange(event.target.value)}>{children}</select></label>;
}
function ToggleRow({ label, checked, onChange, hint }: { label: string; checked: boolean; onChange: (value: boolean) => void; hint?: string }) {
  return <label className="setting-row setting-row--toggle"><span><b>{label}</b>{hint ? <small>{hint}</small> : null}</span><input type="checkbox" role="switch" checked={checked} onChange={(event) => onChange(event.target.checked)} /></label>;
}

export function SettingsPage() {
  const { settings, patchSettings } = useSettings();
  const { diagnostic, error, lastSource, lastAccent, speak, refreshDiagnostic } = useSpeech();
  const [testing, setTesting] = useState(false);
  const [cacheStats, setCacheStats] = useState({ entries: 0, bytes: 0 });
  const navigate = useNavigate();
  const refreshCacheStats = () => getPronunciationCacheStats().then(setCacheStats);
  useEffect(() => { void refreshCacheStats(); }, []);

  const testSpeech = async () => {
    setTesting(true);
    try { await speak(SAMPLE_WORD); }
    finally { setTesting(false); }
  };

  return <div className="page settings-page">
    <header className="page-header"><div><h1>设置</h1><p>让词迹更适合你的学习习惯</p></div></header>
    <section className="settings-section"><h2>学习设置</h2>
      <SelectRow label="学习方向" value={settings.direction} onChange={(v) => void patchSettings({ direction: v as LearningDirection })}><option value="en-zh">英文 → 中文</option><option value="zh-en">中文 → 英文</option></SelectRow>
      <ToggleRow label="显示音标" checked={settings.showPhonetic} onChange={(v) => void patchSettings({ showPhonetic: v })} />
      <ToggleRow label="滑动手势" hint="左滑不认识，上滑模糊，右滑认识" checked={settings.gesturesEnabled} onChange={(v) => void patchSettings({ gesturesEnabled: v })} />
      <SelectRow label="字体大小" value={settings.fontSize} onChange={(v) => void patchSettings({ fontSize: v as FontSize })}><option value="small">小</option><option value="medium">中</option><option value="large">大</option></SelectRow>
    </section>

    <section className="settings-section"><h2>发音设置</h2>
      <SelectRow label="发音来源" value={settings.pronunciationSource} onChange={(v) => void patchSettings({ pronunciationSource: v as PronunciationSourcePreference })}><option value="wikimedia-first">真人词典优先</option><option value="local-first">本地发音优先</option><option value="system-only">仅系统语音</option></SelectRow>
      <SelectRow label="默认口音" value={settings.accent} onChange={(v) => void patchSettings({ accent: v as Accent })}><option value="en-GB">英式英语</option><option value="en-US">美式英语</option></SelectRow>
      <SelectRow label="朗读速度" value={settings.speechRate} onChange={(v) => void patchSettings({ speechRate: Number(v) as 0.75|0.85|1|1.15 })}>{SPEECH_RATES.map((rate) => <option value={rate} key={rate}>{rate}×</option>)}</SelectRow>
      <ToggleRow label="新卡片自动朗读" hint={settings.speechUnlocked ? '已启用独立音频自动播放' : '首次需点击下方按钮启用'} checked={settings.autoSpeakCards} onChange={(v) => void patchSettings({ autoSpeakCards: v })} />
      <ToggleRow label="沉浸词表点击朗读" checked={settings.autoSpeakImmersive} onChange={(v) => void patchSettings({ autoSpeakImmersive: v })} />
      <ToggleRow label="首次播放后自动缓存" checked={settings.cacheWikimediaAfterPlayback} onChange={(v) => void patchSettings({ cacheWikimediaAfterPlayback: v })} />
      <ToggleRow label="发音失败提示" checked={settings.speechErrorsEnabled} onChange={(v) => void patchSettings({ speechErrorsEnabled: v })} />
      <div className="speech-actions">
        <button className="primary-button" disabled={testing} onClick={() => void testSpeech()}><Volume2 size={18}/>{testing ? '正在试听…' : settings.speechUnlocked ? '试听 atmosphere' : '启用并试听 atmosphere'}</button>
        <button className="secondary-button" onClick={() => void refreshDiagnostic()}><RefreshCw size={18}/>重新检测</button>
      </div>
      {error ? <p className="speech-error" role="alert">{error}</p> : null}
      <div className="speech-diagnostic" aria-label="语音诊断">
        <div><span>当前朗读来源</span><b>{lastSource === 'wikimedia-cache' || lastSource === 'wikimedia-online' ? `Wikimedia 真人${lastAccent === 'en-US' ? '美式' : '英式'}发音` : lastSource === 'local-audio' ? `本地${lastAccent === 'en-US' ? '美式' : '英式'}音频` : lastSource === 'system' ? '系统语音' : '尚未试听'}</b></div>
        <div><span>真人录音缓存</span><b>{cacheStats.entries} 条 · {(cacheStats.bytes / 1024 / 1024).toFixed(1)} MB</b></div>
        <div><span>本地英式音频</span><b>作为备用</b></div>
        <div><span>本地美式音频</span><b>作为备用</b></div>
        <div><span>系统英语语音</span><b>{diagnostic.englishVoices} 个</b></div>
        <div><span>系统实际声音</span><b>{diagnostic.voiceName ?? '未检测到'}</b></div>
        <div><span>首次播放权限</span><b>{settings.speechUnlocked ? '已启用' : '待启用'}</b></div>
      </div>
      <button className="secondary-button" onClick={async()=>{if(!confirm('清除真人录音缓存？学习记录不会受到影响。'))return;await clearPronunciationCache();await refreshCacheStats();}}>清除真人录音缓存</button>
    </section>

    <section className="settings-section"><h2>显示设置</h2>
      <div className="theme-picker">{([['light','浅色',Sun],['dark','深色',Moon],['system','跟随系统',RotateCcw]] as const).map(([value,label,Icon]) => <button key={value} className={settings.theme===value?'theme-choice is-active':'theme-choice'} onClick={() => void patchSettings({ theme: value as ThemeMode })}><Icon size={20}/><span>{label}</span></button>)}</div>
      <SelectRow label="词表密度" value={settings.immersiveDensity} onChange={(v) => void patchSettings({ immersiveDensity: v as 'compact'|'comfortable' })}><option value="compact">紧凑</option><option value="comfortable">舒适</option></SelectRow>
    </section>
    <section className="settings-section"><h2>数据与帮助</h2>
      <Link className="setting-link" to="/backup">备份与恢复<span>›</span></Link>
      <InstallPanel />
      <button className="setting-link" onClick={() => navigate('/onboarding', { state: { force: true } })}>重新查看新手引导<span>›</span></button>
      <div className="setting-row"><span>应用版本</span><span className="muted">1.2.0</span></div>
    </section>
  </div>;
}
