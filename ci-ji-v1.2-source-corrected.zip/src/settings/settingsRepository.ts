import type { AppSettings } from '../domain/models';
import type { Repositories } from '../db/repositories';

export function createSettingsRepository(repositories: Repositories) {
  return {
    get: () => repositories.settings.get(),
    patch: (patch: Partial<Omit<AppSettings, 'id'>>) => repositories.settings.patch(patch),
  };
}
