import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { AppSettings } from '../domain/models';
import { DEFAULT_SETTINGS } from '../domain/constants';
import type { Repositories } from '../db/repositories';
import { createSettingsRepository } from './settingsRepository';

interface SettingsContextValue {
  settings: AppSettings;
  patchSettings: (patch: Partial<Omit<AppSettings, 'id'>>) => Promise<void>;
  isReady: boolean;
}
const SettingsContext = createContext<SettingsContextValue | null>(null);

function resolveTheme(theme: AppSettings['theme'], media?: MediaQueryList): 'light' | 'dark' {
  return theme === 'system' ? (media?.matches ? 'dark' : 'light') : theme;
}

export function SettingsProvider({ children, repositories }: { children: ReactNode; repositories: Repositories }) {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [isReady, setReady] = useState(false);
  const repository = useMemo(() => createSettingsRepository(repositories), [repositories]);

  useEffect(() => {
    let active = true;
    repository.get().then((value) => { if (active) { setSettings(value); setReady(true); } });
    return () => { active = false; };
  }, [repository]);

  useEffect(() => {
    const media = window.matchMedia?.('(prefers-color-scheme: dark)');
    const apply = () => {
      document.documentElement.dataset.theme = resolveTheme(settings.theme, media);
      document.documentElement.dataset.fontSize = settings.fontSize;
      document.documentElement.dataset.listDensity = settings.immersiveDensity;
    };
    apply();
    if (settings.theme === 'system') media?.addEventListener('change', apply);
    return () => media?.removeEventListener('change', apply);
  }, [settings.theme, settings.fontSize, settings.immersiveDensity]);

  const patchSettings = useCallback(async (patch: Partial<Omit<AppSettings, 'id'>>) => {
    const value = await repository.patch(patch);
    setSettings(value);
  }, [repository]);

  const value = useMemo(() => ({ settings, patchSettings, isReady }), [settings, patchSettings, isReady]);
  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
}

export function useSettings(): SettingsContextValue {
  const value = useContext(SettingsContext);
  if (!value) throw new Error('useSettings must be used within SettingsProvider');
  return value;
}
