export function normalizeWordKey(word: string): string {
  return word
    .trim()
    .toLocaleLowerCase('en')
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/\s+/g, ' ');
}
