import type { AppSettings } from './models';

export const DEFAULT_SETTINGS: AppSettings = {
  id: 'singleton', direction: 'en-zh', showPhonetic: true,
  gesturesEnabled: false, defaultOrder: 'source', fontSize: 'medium',
  accent: 'en-GB', speechRate: 0.85, autoSpeakCards: true,
  autoSpeakImmersive: true, speechUnlocked: false, speechErrorsEnabled: false,
  pronunciationSource: 'wikimedia-first', cacheWikimediaAfterPlayback: true,
  theme: 'light', immersiveDensity: 'comfortable',
  onboardingSeen: false, gestureHintSeen: false,
};

export const RATING_LABELS = {
  unknown: '不认识', fuzzy: '模糊', known: '认识',
} as const;

export const APP_NAME = '词迹';
export const DESTRUCTIVE_CONFIRMATION = '确认清空';
export const SPEECH_RATES = [0.75, 0.85, 1, 1.15] as const;
