import { useEffect, useState } from 'react';
import { RouterProvider } from 'react-router-dom';
import { createRepositories, type Repositories } from '../db/repositories';
import { ensureBundledSeedImported } from '../db/seed';
import { RepositoriesProvider } from '../db/RepositoriesContext';
import { SettingsProvider, useSettings } from '../settings/SettingsProvider';
import { Onboarding } from '../onboarding/Onboarding';
import { router } from './routes';
import { UpdatePrompt } from './UpdatePrompt';
import './styles/global.css';

function AppContent() {
  const { settings, patchSettings, isReady } = useSettings();
  if (!isReady) return <div className="app-loading"><span>词迹</span></div>;
  if (!settings.onboardingSeen) return <Onboarding onDone={() => patchSettings({ onboardingSeen: true })} />;
  return <><RouterProvider router={router} /><UpdatePrompt /></>;
}

export function App() {
  const [repositories, setRepositories] = useState<Repositories | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    createRepositories().then(async (repos) => {
      try { await ensureBundledSeedImported(repos); } catch (cause) { console.error(cause); }
      if (active) setRepositories(repos); else repos.close();
    }).catch((cause) => setError(cause instanceof Error ? cause.message : '无法打开本地数据库'));
    return () => { active = false; };
  }, []);
  if (error) return <div className="fatal-error"><h1>词迹无法启动</h1><p>{error}</p></div>;
  if (!repositories) return <div className="app-loading"><span>词迹</span></div>;
  return <RepositoriesProvider repositories={repositories}><SettingsProvider repositories={repositories}><AppContent /></SettingsProvider></RepositoriesProvider>;
}
