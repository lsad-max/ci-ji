import { Outlet, useLocation } from 'react-router-dom';
import { BottomNav } from '../components/BottomNav';

export function AppShell() {
  const { pathname } = useLocation();
  const fullscreen = pathname.startsWith('/study') || pathname.startsWith('/immersive') || pathname === '/onboarding';
  return <div className={fullscreen ? 'app-shell app-shell--fullscreen' : 'app-shell'}><main className="app-main"><Outlet /></main>{fullscreen ? null : <BottomNav />}</div>;
}
