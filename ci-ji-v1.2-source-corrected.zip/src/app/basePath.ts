export function normalizeBasePath(value: string): string {
  const trimmed = value.trim();
  if (!trimmed || trimmed === '/') return '/';

  const segment = trimmed.replace(/^\/+|\/+$/g, '');
  return segment ? `/${segment}/` : '/';
}

export function routerBasenameFromBase(value: string): string | undefined {
  const normalized = normalizeBasePath(value);
  return normalized === '/' ? undefined : normalized.slice(0, -1);
}

export const appBasePath = normalizeBasePath(import.meta.env.BASE_URL);
export const routerBasename = routerBasenameFromBase(appBasePath);
