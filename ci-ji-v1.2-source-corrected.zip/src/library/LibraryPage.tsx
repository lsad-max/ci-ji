import { useEffect, useMemo, useState } from 'react';
import { ChevronRight, MoreVertical, Plus, Search, Trash2, Volume2 } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useRepositories } from '../db/RepositoriesContext';
import type { DailyPack, StudyState, WordEntry } from '../domain/models';
import { todayLocal } from '../domain/dates';
import { useSpeech } from '../speech/useSpeech';
import { buildLibraryRows, type AudioFilter, type LibraryScope, type LibrarySort, type LibraryStatus } from './libraryQueries';
import { moveWordToTrash } from './libraryMutations';
import './library.css';

const statusLabel={unseen:'未学习',known:'认识',fuzzy:'模糊',unknown:'不认识'} as const;
export function LibraryPage(){
 const repos=useRepositories();const navigate=useNavigate();const {speak}=useSpeech();const [words,setWords]=useState<WordEntry[]>([]);const [packs,setPacks]=useState<DailyPack[]>([]);const [states,setStates]=useState<StudyState[]>([]);const [search,setSearch]=useState('');const [scope,setScope]=useState<LibraryScope>('all');const [status,setStatus]=useState<LibraryStatus>('all');const [audio,setAudio]=useState<AudioFilter>('all');const [sort,setSort]=useState<LibrarySort>('source');const [menu,setMenu]=useState(false);const [message,setMessage]=useState('');const [pendingWordCount,setPendingWordCount]=useState(0);
 const load=async()=>{setWords(await repos.words.getAll());setPacks(await repos.packs.getAll());setStates(await repos.studyStates.getAll());const pending=await repos.pronunciationReviews.getByStatus('unreviewed');setPendingWordCount(new Set(pending.map(item=>item.wordId)).size);};useEffect(()=>{void load();},[repos]);
 const rows=useMemo(()=>buildLibraryRows(words,states,packs,{search,scope,status,audio,sort,today:todayLocal()}),[words,states,packs,search,scope,status,audio,sort]);
 return <div className="page library-page"><header className="page-header"><div><h1>词库</h1><p>{words.length}个主词条 · {packs.length}个每日词包</p></div><div className="library-add"><button aria-label="新增" className="icon-button" onClick={()=>setMenu(v=>!v)}><Plus/></button>{menu?<div className="popover"><Link to="/library/import">导入词包</Link><Link to="/library/new">新增一个单词</Link><Link to="/library/bulk">批量粘贴</Link><Link to="/backup">导入数据备份</Link></div>:null}</div></header>
 <Link className="review-entry" to="/library/pronunciation-review">待审核发音 <b>{pendingWordCount}</b></Link>
 <label className="search-field"><Search size={19}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="搜索英文或中文"/></label>
 <div className="library-tabs">{([['all','全部单词'],['today','今日词包'],['history','历史词包']] as const).map(([v,l])=><button className={scope===v?'is-active':''} onClick={()=>setScope(v)} key={v}>{l}</button>)}</div>
 <div className="library-filters"><select aria-label="掌握状态" value={status} onChange={e=>setStatus(e.target.value as LibraryStatus)}><option value="all">全部状态</option><option value="unseen">未学习</option><option value="known">认识</option><option value="fuzzy">模糊</option><option value="unknown">不认识</option></select><select aria-label="音频" value={audio} onChange={e=>setAudio(e.target.value as AudioFilter)}><option value="all">全部音频</option><option value="with-audio">有独立音频</option><option value="without-audio">无独立音频</option></select><select aria-label="排序" value={sort} onChange={e=>setSort(e.target.value as LibrarySort)}><option value="source">导入顺序</option><option value="alphabetical">字母顺序</option><option value="recent-added">最近加入</option><option value="recent-studied">最近学习</option><option value="errors">错误最多</option><option value="frequency">出现频率</option></select></div>
 {message?<p className="notice">{message}</p>:null}<div className="word-list">{rows.map(({word,state})=><article className="word-list-row" key={word.id}><button className="word-main" onClick={()=>navigate(`/library/edit/${word.id}`)}><span><b>{word.word}</b><small>{word.partOfSpeech.join(' ')} {word.meanings.join('；')}</small></span><em data-status={state?.status??'unseen'}>{statusLabel[state?.status??'unseen']}</em><ChevronRight size={18}/></button><button aria-label={`播放${word.word}`} className="row-icon" onClick={()=>void speak(word)}><Volume2 size={18}/></button><button aria-label={`删除${word.word}`} className="row-icon" onClick={async()=>{if(!confirm(`删除“${word.word}”？它将进入回收站30天。`))return;const result=await moveWordToTrash(repos.db,word.id);setMessage(`已移入回收站，并从${result.affectedPacks}个词包移除`);await load();}}><Trash2 size={18}/></button></article>)}</div>
 {!rows.length?<div className="library-empty">没有符合条件的单词</div>:null}<Link className="trash-link" to="/library/trash"><Trash2 size={17}/> 回收站</Link></div>;
}
