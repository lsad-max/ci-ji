import type { DailyPack, MasteryStatus, StudyState, WordEntry } from '../domain/models';
import type { IncomingWord } from '../packs/packSchema';

export type LibraryScope = 'all' | 'today' | 'history';
export type LibraryStatus = 'all' | MasteryStatus;
export type AudioFilter = 'all' | 'with-audio' | 'without-audio';
export type LibrarySort = 'source' | 'alphabetical' | 'recent-added' | 'recent-studied' | 'errors' | 'frequency';

export interface LibraryQueryOptions {
  search?: string;
  scope?: LibraryScope;
  status?: LibraryStatus;
  audio?: AudioFilter;
  sort?: LibrarySort;
  today?: string;
  packId?: string | null;
}

export interface LibraryRow {
  word: WordEntry;
  state: StudyState | null;
  sourceIndex: number;
  packIds: string[];
  errorCount: number;
}

const collator = new Intl.Collator('en', { sensitivity: 'base' });

export function buildLibraryRows(
  words: WordEntry[], states: StudyState[], packs: DailyPack[], options: LibraryQueryOptions = {},
): LibraryRow[] {
  const stateById = new Map(states.map((state) => [state.wordId, state]));
  const packIdsByWord = new Map<string, string[]>();
  const sourceIndexByWord = new Map<string, number>();
  let globalIndex = 0;
  for (const pack of [...packs].sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id))) {
    pack.wordIds.forEach((wordId, index) => {
      const list = packIdsByWord.get(wordId) ?? [];
      list.push(pack.id); packIdsByWord.set(wordId, list);
      if (!sourceIndexByWord.has(wordId)) sourceIndexByWord.set(wordId, globalIndex + index);
    });
    globalIndex += pack.wordIds.length;
  }
  const search = options.search?.trim().toLocaleLowerCase() ?? '';
  const todayPackIds = new Set(packs.filter((pack) => pack.date === options.today).map((pack) => pack.id));
  const selectedPack = options.packId ? packs.find((pack) => pack.id === options.packId) : null;
  const selectedIds = selectedPack ? new Set(selectedPack.wordIds) : null;

  const rows = words.map((word, originalIndex): LibraryRow => {
    const state = stateById.get(word.id) ?? null;
    return {
      word, state,
      sourceIndex: sourceIndexByWord.get(word.id) ?? Number.MAX_SAFE_INTEGER - words.length + originalIndex,
      packIds: packIdsByWord.get(word.id) ?? [],
      errorCount: (state?.unknownCount ?? 0) + (state?.fuzzyCount ?? 0),
    };
  }).filter((row) => {
    const status = row.state?.status ?? 'unseen';
    const searchable = `${row.word.word} ${row.word.meanings.join(' ')} ${row.word.supplementaryMeanings.join(' ')}`.toLocaleLowerCase();
    if (search && !searchable.includes(search)) return false;
    if (selectedIds && !selectedIds.has(row.word.id)) return false;
    if (options.scope === 'today' && !row.packIds.some((id) => todayPackIds.has(id))) return false;
    if (options.scope === 'history' && row.packIds.some((id) => todayPackIds.has(id))) return false;
    if (options.status && options.status !== 'all' && status !== options.status) return false;
    const hasAudio = Boolean(row.word.audioUK || row.word.audioUS);
    if (options.audio === 'with-audio' && !hasAudio) return false;
    if (options.audio === 'without-audio' && hasAudio) return false;
    return true;
  });

  const decorated = rows.map((row, originalIndex) => ({ row, originalIndex }));
  decorated.sort((a, b) => {
    let result = 0;
    switch (options.sort ?? 'source') {
      case 'alphabetical': result = collator.compare(a.row.word.word, b.row.word.word); break;
      case 'recent-added': result = b.row.word.createdAt.localeCompare(a.row.word.createdAt); break;
      case 'recent-studied': result = (b.row.state?.lastStudiedAt ?? '').localeCompare(a.row.state?.lastStudiedAt ?? ''); break;
      case 'errors': result = b.row.errorCount - a.row.errorCount; break;
      case 'frequency': result = b.row.word.occurrenceCount - a.row.word.occurrenceCount; break;
      case 'source': result = a.row.sourceIndex - b.row.sourceIndex; break;
    }
    return result || a.row.sourceIndex - b.row.sourceIndex || a.originalIndex - b.originalIndex;
  });
  return decorated.map(({ row }) => row);
}

export interface BulkParseIssue { lineNumber: number; message: string; raw: string }
export interface BulkParseRow { lineNumber: number; word: IncomingWord; raw: string }
export interface BulkParseResult { rows: BulkParseRow[]; issues: BulkParseIssue[] }

const POS_RE = /^(?:n|v|adj|adv|prep|conj|pron|num|art|aux|modal|phr)\.?$/i;
const splitMeanings = (text: string) => text.split(/[；;]/).map((value) => value.trim()).filter(Boolean);

export function parseBulkWords(input: string): BulkParseResult {
  const rows: BulkParseRow[] = []; const issues: BulkParseIssue[] = [];
  input.split(/\r?\n/).forEach((raw, index) => {
    const lineNumber = index + 1; const line = raw.trim(); if (!line) return;
    const delimiter = line.includes('\t') ? '\t' : line.includes('|') ? '|' : ',';
    const fields = line.split(delimiter).map((value) => value.trim()).filter((value, fieldIndex, all) => value || fieldIndex < all.length - 1);
    if (fields.length < 2) { issues.push({ lineNumber, message: '缺少中文释义', raw }); return; }
    const word = fields[0];
    if (!word || /[\u4e00-\u9fff]/.test(word)) { issues.push({ lineNumber, message: '无法确定英文单词', raw }); return; }
    let pos: string[] = []; let meaningField = '';
    if (fields.length >= 3 && POS_RE.test(fields[1])) { pos = [fields[1].endsWith('.') ? fields[1] : `${fields[1]}.`]; meaningField = fields.slice(2).join('；'); }
    else meaningField = fields.slice(1).join('；');
    const meanings = splitMeanings(meaningField);
    if (!meanings.length || !meanings.some((value) => /[\u4e00-\u9fff]/.test(value))) { issues.push({ lineNumber, message: '无法确定中文释义', raw }); return; }
    rows.push({ lineNumber, raw, word: {
      word, phoneticUK: null, phoneticUS: null, partOfSpeech: pos, meanings,
      supplementaryMeanings: [], categories: [], phrases: [], examples: [], confusables: [], audioUK: null, audioUS: null,
    } });
  });
  return { rows, issues };
}
