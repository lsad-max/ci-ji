import { useEffect, useState } from 'react';
import { ArrowLeft, RotateCcw, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useRepositories } from '../db/RepositoriesContext';
import type { TrashRecord } from '../domain/models';
import { restoreWordFromTrash } from './libraryMutations';
import './library.css';
export function TrashPage(){const nav=useNavigate();const repos=useRepositories();const [records,setRecords]=useState<TrashRecord[]>([]);const load=()=>repos.trash.getAll().then(setRecords);useEffect(()=>{void repos.trash.purgeExpired(new Date().toISOString()).then(load);},[repos]);return <div className="page"><header className="subpage-header"><button className="icon-button" onClick={()=>nav(-1)} aria-label="返回"><ArrowLeft/></button><div><h1>回收站</h1><p>删除的词条保留30天</p></div></header><div className="word-list">{records.map(record=><article className="trash-row" key={record.id}><div><b>{record.word.word}</b><small>{record.word.meanings.join('；')} · 到期 {record.expiresAt.slice(0,10)}</small></div><button className="row-icon" aria-label={`恢复${record.word.word}`} onClick={async()=>{await restoreWordFromTrash(repos.db,record.id);await load();}}><RotateCcw/></button><button className="row-icon" aria-label={`永久删除${record.word.word}`} onClick={async()=>{if(confirm('永久删除后无法恢复，是否继续？')){await repos.trash.delete(record.id);await load();}}}><Trash2/></button></article>)}</div>{!records.length?<div className="library-empty">回收站为空</div>:null}</div>}
