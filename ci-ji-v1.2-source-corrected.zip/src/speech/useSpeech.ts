import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useRepositories } from '../db/RepositoriesContext';
import type { Accent, WordEntry } from '../domain/models';
import { normalizeWordKey } from '../domain/normalize';
import { getBundledPronunciation } from '../pronunciation/bundledMapping';
import {
  cancelPronunciation,
  playPronunciation,
  type PronunciationPlaybackResult,
  type PronunciationPlaybackSource,
} from '../pronunciation/audioPlaybackController';
import { resolvePronunciationPlan, type PronunciationDataSource } from '../pronunciation/pronunciationResolver';
import type { ApprovedPronunciation } from '../pronunciation/types';
import { useSettings } from '../settings/SettingsProvider';
import { inspectSpeech, selectVoice, type SpeechDiagnostic } from './speechService';

export type SpeakableWord = WordEntry | Pick<WordEntry, 'word' | 'audioUK' | 'audioUS'> | string;
export type SpeechUiStatus = 'idle' | 'loading-human' | 'playing-human' | 'playing-fallback' | 'unavailable';

function messageFor(result: Exclude<PronunciationPlaybackResult, { ok: true }>): string | null {
  if (result.reason === 'cancelled') return null;
  if (result.reason === 'autoplay-blocked') return '浏览器阻止了自动播放，请直接点击喇叭。';
  if (result.reason === 'unsupported') return '当前口音的真人录音、本地发音和系统语音均不可用。';
  return '发音暂不可用。';
}

function temporaryWord(value: string, audioUK: string | null = null, audioUS: string | null = null): WordEntry {
  const normalizedKey = normalizeWordKey(value);
  const now = new Date().toISOString();
  return {
    id: `temporary:${normalizedKey}`,
    normalizedKey,
    word: value,
    phoneticUK: null,
    phoneticUS: null,
    partOfSpeech: [],
    meanings: [],
    supplementaryMeanings: [],
    categories: [],
    phrases: [],
    examples: [],
    confusables: [],
    audioUK,
    audioUS,
    appearedDates: [],
    occurrenceCount: 0,
    createdAt: now,
    updatedAt: now,
  };
}

export function useSpeech() {
  const repositories = useRepositories();
  const { settings, patchSettings } = useSettings();
  const [voiceName, setVoiceName] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [lastSource, setLastSource] = useState<PronunciationPlaybackSource | null>(null);
  const [lastAccent, setLastAccent] = useState<Accent | null>(null);
  const [status, setStatus] = useState<SpeechUiStatus>('idle');
  const [attribution, setAttribution] = useState<ApprovedPronunciation | null>(null);
  const requestSequence = useRef(0);
  const [diagnostic, setDiagnostic] = useState<SpeechDiagnostic>({
    supported: typeof window !== 'undefined' && 'speechSynthesis' in window,
    totalVoices: 0,
    englishVoices: 0,
    voiceName: null,
  });

  const source = useMemo<PronunciationDataSource>(() => ({
    getUserReview: (wordId, accent) => repositories.pronunciationReviews.get(wordId, accent),
    getBundled: (normalizedKey, accent) => getBundledPronunciation(normalizedKey, accent).catch(() => null),
  }), [repositories]);

  const refreshDiagnostic = useCallback(async () => {
    const value = await inspectSpeech(settings.accent);
    setDiagnostic(value);
    setVoiceName(value.voiceName);
    return value;
  }, [settings.accent]);

  useEffect(() => {
    if (!('speechSynthesis' in window)) return;
    const update = () => {
      const voices = speechSynthesis.getVoices();
      const englishVoices = voices.filter((voice) => /^en(?:-|$)/i.test(voice.lang));
      const voice = selectVoice(englishVoices, settings.accent);
      setVoiceName(voice?.name ?? null);
      setDiagnostic({
        supported: true,
        totalVoices: voices.length,
        englishVoices: englishVoices.length,
        voiceName: voice?.name ?? null,
      });
    };
    update();
    speechSynthesis.addEventListener?.('voiceschanged', update);
    return () => speechSynthesis.removeEventListener?.('voiceschanged', update);
  }, [settings.accent]);

  const speak = useCallback(async (input: SpeakableWord, slow = false, userInitiated = true) => {
    const requestId = ++requestSequence.current;
    cancelPronunciation();
    const word = typeof input === 'string'
      ? temporaryWord(input)
      : 'id' in input
        ? input
        : temporaryWord(input.word, input.audioUK, input.audioUS);
    setStatus('loading-human');
    setError(null);
    setAttribution(null);
    const plan = await resolvePronunciationPlan(word, settings.accent, settings, source);
    if (requestId !== requestSequence.current) {
      return { ok: false as const, reason: 'cancelled' as const };
    }
    if (!plan.attribution) setStatus('playing-fallback');

    const result = await playPronunciation(plan, {
      rate: slow ? 0.75 : settings.speechRate,
      cacheAfterPlayback: settings.cacheWikimediaAfterPlayback,
      userInitiated,
    });
    if (requestId !== requestSequence.current) return result;
    if (!result.ok) {
      setLastSource(null);
      setLastAccent(null);
      setAttribution(null);
      setStatus(result.reason === 'cancelled' ? 'idle' : 'unavailable');
      setError(settings.speechErrorsEnabled ? messageFor(result) : null);
      return result;
    }

    setError(null);
    setVoiceName(result.voiceName ?? null);
    setLastSource(result.source);
    setLastAccent(result.accent);
    setAttribution(result.attribution);
    setStatus(result.source.startsWith('wikimedia') ? 'playing-human' : 'playing-fallback');
    if (!settings.speechUnlocked) await patchSettings({ speechUnlocked: true });
    return result;
  }, [patchSettings, settings, source]);

  const cancel = useCallback(() => {
    requestSequence.current += 1;
    cancelPronunciation();
    setAttribution(null);
    setStatus('idle');
  }, []);

  return {
    voiceName,
    available: typeof Audio !== 'undefined' || diagnostic.supported,
    error,
    lastSource,
    lastAccent,
    status,
    attribution,
    diagnostic,
    speak,
    refreshDiagnostic,
    cancel,
  };
}
