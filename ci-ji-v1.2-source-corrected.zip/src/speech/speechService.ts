import type { Accent } from '../domain/models';

export type SpeechRate = 0.75 | 0.85 | 1 | 1.15;

export interface SpeakOptions {
  accent: Accent;
  rate: SpeechRate;
  audioUK: string | null;
  audioUS: string | null;
  signal?: AbortSignal;
}

export type SpeechFailureReason = 'unsupported' | 'cancelled' | 'playback-failed' | 'autoplay-blocked';
export type LowLevelPlaybackResult = { ok: true; voiceName?: string } | { ok: false; reason: SpeechFailureReason };
export type SpeechResult =
  | { ok: true; source: 'audio' | 'synthesis'; voiceName: string | null; accent: Accent }
  | { ok: false; reason: SpeechFailureReason };

export interface SpeechDiagnostic {
  supported: boolean;
  totalVoices: number;
  englishVoices: number;
  voiceName: string | null;
}

let activeAudio: HTMLAudioElement | null = null;
let activeUtterance: SpeechSynthesisUtterance | null = null;

export function selectVoice(voices: SpeechSynthesisVoice[], accent: Accent): SpeechSynthesisVoice | null {
  if (!voices.length) return null;
  const regionTerms = accent === 'en-GB'
    ? ['united kingdom', 'british', 'uk english']
    : ['united states', 'american', 'us english'];
  const scored = voices.map((voice, index) => {
    const lang = voice.lang.toLowerCase();
    const name = voice.name.toLowerCase();
    let score = 0;
    if (lang === accent.toLowerCase()) score = 400;
    else if (regionTerms.some((term) => name.includes(term))) score = 300;
    else if (lang.startsWith('en-')) score = 200;
    else if (lang === 'en') score = 100;
    return { voice, score, index };
  }).filter((item) => item.score > 0);
  scored.sort((a, b) => b.score - a.score || Number(b.voice.localService) - Number(a.voice.localService) || a.index - b.index);
  return scored[0]?.voice ?? null;
}

function selectExactAccentVoice(voices: SpeechSynthesisVoice[], accent: Accent): SpeechSynthesisVoice | null {
  const exact = voices.filter((voice) => voice.lang.toLowerCase() === accent.toLowerCase());
  if (exact.length) return selectVoice(exact, accent);
  const terms = accent === 'en-GB'
    ? ['british', 'united kingdom', 'uk english']
    : ['american', 'united states', 'us english'];
  return voices.find((voice) => terms.some((term) => voice.name.toLowerCase().includes(term))) ?? null;
}

async function waitForVoices(timeoutMs = 3000): Promise<SpeechSynthesisVoice[]> {
  if (!('speechSynthesis' in window)) return [];
  const initial = speechSynthesis.getVoices();
  if (initial.length) return initial;

  return new Promise((resolve) => {
    let settled = false;
    const retryDelays = [250, 750, 1500, timeoutMs];
    const timers: number[] = [];
    const finish = (voices: SpeechSynthesisVoice[]) => {
      if (settled) return;
      settled = true;
      timers.forEach((timer) => window.clearTimeout(timer));
      speechSynthesis.removeEventListener?.('voiceschanged', onVoicesChanged);
      resolve(voices);
    };
    const check = () => {
      const voices = speechSynthesis.getVoices();
      if (voices.length) finish(voices);
    };
    const onVoicesChanged = () => check();
    speechSynthesis.addEventListener?.('voiceschanged', onVoicesChanged);
    retryDelays.forEach((delay, index) => {
      timers.push(window.setTimeout(() => {
        const voices = speechSynthesis.getVoices();
        if (voices.length || index === retryDelays.length - 1) finish(voices);
      }, delay));
    });
  });
}

export function resolveAudioUrl(url: string): string {
  if (/^(?:https?:|blob:|data:)/i.test(url)) return url;
  const appRoot = new URL(import.meta.env.BASE_URL, window.location.origin);
  return new URL(url.replace(/^\/+/, ''), appRoot).toString();
}

export function playLocalAudio(
  url: string,
  rate: SpeechRate,
  signal?: AbortSignal,
): Promise<LowLevelPlaybackResult> {
  return new Promise((resolve) => {
    const audio = new Audio(resolveAudioUrl(url));
    audio.preload = 'auto';
    audio.playbackRate = rate;
    activeAudio = audio;
    let settled = false;

    const finish = (result: LowLevelPlaybackResult) => {
      if (settled) return;
      settled = true;
      audio.onended = null;
      audio.onerror = null;
      signal?.removeEventListener('abort', onAbort);
      if (activeAudio === audio) activeAudio = null;
      resolve(result);
    };
    const onAbort = () => {
      audio.pause();
      finish({ ok: false, reason: 'cancelled' });
    };
    audio.onended = () => finish({ ok: true });
    audio.onerror = () => finish({ ok: false, reason: 'playback-failed' });
    signal?.addEventListener('abort', onAbort, { once: true });
    if (signal?.aborted) {
      onAbort();
      return;
    }
    audio.play().catch((error: unknown) => {
      const name = error instanceof DOMException ? error.name : '';
      finish({ ok: false, reason: name === 'NotAllowedError' ? 'autoplay-blocked' : 'playback-failed' });
    });
  });
}

function playSynthesis(
  word: string,
  accent: Accent,
  rate: SpeechRate,
  voice: SpeechSynthesisVoice,
  signal?: AbortSignal,
): Promise<LowLevelPlaybackResult> {
  return new Promise((resolve) => {
    const utterance = new SpeechSynthesisUtterance(word);
    activeUtterance = utterance;
    utterance.lang = accent;
    utterance.rate = rate;
    utterance.voice = voice;
    let settled = false;
    const finish = (result: LowLevelPlaybackResult) => {
      if (settled) return;
      settled = true;
      signal?.removeEventListener('abort', onAbort);
      if (activeUtterance === utterance) activeUtterance = null;
      resolve(result);
    };
    const onAbort = () => {
      speechSynthesis.cancel();
      finish({ ok: false, reason: 'cancelled' });
    };
    signal?.addEventListener('abort', onAbort, { once: true });
    if (signal?.aborted) {
      onAbort();
      return;
    }
    utterance.onend = () => finish({ ok: true, voiceName: voice.name });
    utterance.onerror = (event) => finish({
      ok: false,
      reason: event.error === 'canceled' || event.error === 'interrupted' ? 'cancelled' : 'playback-failed',
    });
    speechSynthesis.resume?.();
    speechSynthesis.speak(utterance);
  });
}

export async function playSystemSpeech(
  word: string,
  accent: Accent,
  rate: SpeechRate,
  signal?: AbortSignal,
): Promise<LowLevelPlaybackResult> {
  if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
    return { ok: false, reason: 'unsupported' };
  }
  const immediate = speechSynthesis.getVoices();
  const voices = immediate.length ? immediate : await waitForVoices();
  if (signal?.aborted) return { ok: false, reason: 'cancelled' };
  const voice = selectExactAccentVoice(voices, accent);
  if (!voice) return { ok: false, reason: 'unsupported' };
  return playSynthesis(word, accent, rate, voice, signal);
}

export function cancelSpeech(): void {
  activeAudio?.pause();
  activeAudio = null;
  activeUtterance = null;
  if ('speechSynthesis' in window) speechSynthesis.cancel();
}

export async function inspectSpeech(accent: Accent): Promise<SpeechDiagnostic> {
  if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
    return { supported: false, totalVoices: 0, englishVoices: 0, voiceName: null };
  }
  const voices = await waitForVoices();
  const englishVoices = voices.filter((voice) => /^en(?:-|$)/i.test(voice.lang));
  return {
    supported: true,
    totalVoices: voices.length,
    englishVoices: englishVoices.length,
    voiceName: selectVoice(englishVoices, accent)?.name ?? null,
  };
}

export async function speakWord(word: string, options: SpeakOptions): Promise<SpeechResult> {
  cancelSpeech();
  if (options.signal?.aborted) return { ok: false, reason: 'cancelled' };

  const preferredAudio = options.accent === 'en-GB' ? options.audioUK : options.audioUS;
  if (preferredAudio) {
    const result = await playLocalAudio(preferredAudio, options.rate, options.signal);
    if (result.ok) return { ok: true, source: 'audio', voiceName: null, accent: options.accent };
    if (result.reason === 'cancelled' || result.reason === 'autoplay-blocked') return result;
  }

  const result = await playSystemSpeech(word, options.accent, options.rate, options.signal);
  if (!result.ok) return result;
  return {
    ok: true,
    source: 'synthesis',
    voiceName: result.voiceName ?? null,
    accent: options.accent,
  };
}
