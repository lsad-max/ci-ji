import { useRef } from 'react';
import { Volume2 } from 'lucide-react';
import { AttributionPanel } from '../pronunciation/AttributionPanel';
import { useSpeech, type SpeakableWord } from './useSpeech';

export function SpeechButton({
  word,
  className = '',
  showAttribution = false,
  compactAttribution = false,
}: {
  word: SpeakableWord;
  className?: string;
  showAttribution?: boolean;
  compactAttribution?: boolean;
}) {
  const { speak, status, attribution, lastSource } = useSpeech();
  const timer = useRef<number | null>(null);
  const slowTriggered = useRef(false);
  const clear = () => {
    if (timer.current !== null) window.clearTimeout(timer.current);
    timer.current = null;
  };
  const label = typeof word === 'string' ? word : word.word;
  const statusText = status === 'loading-human' ? '正在加载真人发音'
    : status === 'playing-human' ? '正在播放真人发音'
      : status === 'playing-fallback' ? '正在使用备用发音'
        : status === 'unavailable' ? '发音暂不可用'
          : '播放发音';
  return <>
    <button
      type="button"
      className={`speech-button ${className}`}
      aria-label={`播放${label}`}
      onPointerDown={() => {
        slowTriggered.current = false;
        timer.current = window.setTimeout(() => {
          slowTriggered.current = true;
          void speak(word, true, true);
        }, 450);
      }}
      onPointerUp={clear}
      onPointerCancel={clear}
      onPointerLeave={clear}
      onClick={(event) => {
        event.stopPropagation();
        if (slowTriggered.current) {
          event.preventDefault();
          slowTriggered.current = false;
          return;
        }
        void speak(word, false, true);
      }}
    >
      <Volume2 size={22} aria-hidden="true" />
      <span className="speech-button__status">{statusText}</span>
    </button>
    {showAttribution && attribution
      ? <AttributionPanel recording={attribution} cached={lastSource === 'wikimedia-cache'} compact={compactAttribution} />
      : null}
  </>;
}
