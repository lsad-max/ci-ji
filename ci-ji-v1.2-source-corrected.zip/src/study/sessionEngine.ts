import type { AppSettings, DailyPack, LocalDate, Rating, SessionCard, StudyEvent, StudySession, StudyState } from '../domain/models';
import { applyRating } from './scheduler';

export interface RatingContext { localDate: LocalDate; studiedAt: string; idFactory?: () => string }
export interface SessionMutation { session: StudySession; nextState: StudyState; event: StudyEvent; previousState: StudyState | null }
export interface UndoMutation { session: StudySession; eventId: string; previousState: StudyState | null }

function shuffle<T>(values: T[], random: () => number): T[] {
  const result = [...values];
  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = Math.floor(random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}
function randomInt(min: number, max: number, random: () => number): number {
  return min + Math.floor(random() * (max - min + 1));
}

export function createDailySession(pack: DailyPack, settings: AppSettings, _random: () => number = Math.random): StudySession {
  return {
    id: `daily:${pack.id}`, packId: pack.id, kind: 'daily', direction: settings.direction,
    queue: pack.wordIds.map((wordId) => ({ wordId, phase: 'first-pass' as const })), cursor: 0,
    firstPassSeenWordIds: [], ratingCounts: { unknown: 0, fuzzy: 0, known: 0 }, undo: null,
    completedFirstPassAt: null, completedAt: null, updatedAt: new Date().toISOString(),
  };
}

export function createReviewSession(dueStates: StudyState[], random: () => number = Math.random, direction: AppSettings['direction'] = 'en-zh'): StudySession {
  return {
    id: `review:${crypto.randomUUID()}`, packId: null, kind: 'review', direction,
    queue: shuffle(dueStates.map((state) => ({ wordId: state.wordId, phase: 'review' as const })), random), cursor: 0,
    firstPassSeenWordIds: [], ratingCounts: { unknown: 0, fuzzy: 0, known: 0 }, undo: null,
    completedFirstPassAt: null, completedAt: null, updatedAt: new Date().toISOString(),
  };
}

export function rateCurrentCard(
  session: StudySession,
  state: StudyState | undefined,
  rating: Rating,
  random: () => number = Math.random,
  context: RatingContext = { localDate: new Date().toISOString().slice(0, 10) as LocalDate, studiedAt: new Date().toISOString() },
): SessionMutation {
  const current = session.queue[session.cursor];
  if (!current) throw new Error('学习队列已经完成');
  const idFactory = context.idFactory ?? (() => crypto.randomUUID());
  const nextState = applyRating(state, rating, context.localDate, context.studiedAt, current.wordId);
  const event: StudyEvent = {
    id: idFactory(), wordId: current.wordId, packId: session.packId, rating,
    studiedAt: context.studiedAt, localDate: context.localDate, direction: session.direction, phase: current.phase,
  };
  const queueBefore = structuredClone(session.queue);
  const cursorBefore = session.cursor;
  const queue = [...session.queue];
  if (rating !== 'known') {
    const [min, max] = rating === 'unknown' ? [3, 5] : [8, 12];
    const index = Math.min(queue.length, session.cursor + randomInt(min, max, random));
    queue.splice(index, 0, { wordId: current.wordId, phase: 'reinforcement' });
  }
  const seen = current.phase === 'first-pass' && !session.firstPassSeenWordIds.includes(current.wordId)
    ? [...session.firstPassSeenWordIds, current.wordId] : [...session.firstPassSeenWordIds];
  const cursor = session.cursor + 1;
  const expectedFirstPass = session.kind === 'daily' ? queueBefore.filter((card) => card.phase === 'first-pass').length : 0;
  const completedFirstPassAt = session.completedFirstPassAt ?? (session.kind === 'daily' && seen.length >= expectedFirstPass ? context.studiedAt : null);
  const completedAt = cursor >= queue.length ? context.studiedAt : null;
  return {
    previousState: state ? structuredClone(state) : null,
    nextState,
    event,
    session: {
      ...session, queue, cursor, firstPassSeenWordIds: seen,
      ratingCounts: { ...session.ratingCounts, [rating]: session.ratingCounts[rating] + 1 },
      undo: { card: current, rating, previousState: state ? structuredClone(state) : null, eventId: event.id, queueBefore, cursorBefore },
      completedFirstPassAt, completedAt, updatedAt: context.studiedAt,
    },
  };
}

export function undoLastRating(session: StudySession): UndoMutation {
  if (!session.undo) throw new Error('没有可撤销的操作');
  const { eventId, previousState, queueBefore, cursorBefore, rating } = session.undo;
  return {
    eventId, previousState,
    session: {
      ...session,
      queue: queueBefore ? structuredClone(queueBefore) : [session.undo.card, ...session.queue.slice(session.cursor)],
      cursor: cursorBefore ?? Math.max(0, session.cursor - 1),
      firstPassSeenWordIds: session.undo.card.phase === 'first-pass' ? session.firstPassSeenWordIds.filter((id) => id !== session.undo!.card.wordId) : session.firstPassSeenWordIds,
      ratingCounts: { ...session.ratingCounts, [rating]: Math.max(0, session.ratingCounts[rating] - 1) },
      undo: null, completedAt: null,
      completedFirstPassAt: session.undo.card.phase === 'first-pass' ? null : session.completedFirstPassAt,
      updatedAt: new Date().toISOString(),
    },
  };
}
