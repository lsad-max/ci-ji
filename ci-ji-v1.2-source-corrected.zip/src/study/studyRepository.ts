import type { Repositories } from '../db/repositories';
import type { SessionMutation } from './sessionEngine';
import { undoLastRating } from './sessionEngine';

export function createStudyRepository(repositories: Repositories) {
  return {
    async commitRating(mutation: SessionMutation): Promise<void> {
      const tx = repositories.db.transaction(['studyStates', 'studyEvents', 'sessions'], 'readwrite');
      try {
        await tx.objectStore('studyStates').put(mutation.nextState);
        await tx.objectStore('studyEvents').put(mutation.event);
        await tx.objectStore('sessions').put(mutation.session);
        await tx.done;
      } catch (error) {
        try { tx.abort(); } catch { /* inactive */ }
        await tx.done.catch(() => undefined);
        throw error;
      }
    },
    async undoLast(sessionId: string) {
      const existing = await repositories.sessions.get(sessionId);
      if (!existing) throw new Error('未找到学习会话');
      const mutation = undoLastRating(existing);
      const tx = repositories.db.transaction(['studyStates', 'studyEvents', 'sessions'], 'readwrite');
      try {
        await tx.objectStore('studyEvents').delete(mutation.eventId);
        const wordId = existing.undo!.card.wordId;
        if (mutation.previousState) await tx.objectStore('studyStates').put(mutation.previousState);
        else await tx.objectStore('studyStates').delete(wordId);
        await tx.objectStore('sessions').put(mutation.session);
        await tx.done;
        return mutation.session;
      } catch (error) {
        try { tx.abort(); } catch { /* inactive */ }
        await tx.done.catch(() => undefined);
        throw error;
      }
    },
  };
}
