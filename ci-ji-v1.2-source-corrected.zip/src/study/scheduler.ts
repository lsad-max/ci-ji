import type { LocalDate, Rating, StudyState } from '../domain/models';
import { addLocalDays } from '../domain/dates';

const KNOWN_INTERVALS = [3, 7, 15, 30] as const;

export function applyRating(
  previous: StudyState | undefined,
  rating: Rating,
  localDate: LocalDate,
  studiedAt: string,
  wordId = previous?.wordId ?? '',
): StudyState {
  const base: StudyState = previous ?? {
    wordId, status: 'unseen', consecutiveKnown: 0, nextReviewDate: null, lastStudiedAt: null,
    knownCount: 0, fuzzyCount: 0, unknownCount: 0,
  };
  if (rating === 'unknown') return {
    ...base, wordId: base.wordId || wordId, status: 'unknown', consecutiveKnown: 0,
    nextReviewDate: addLocalDays(localDate, 1), lastStudiedAt: studiedAt, unknownCount: base.unknownCount + 1,
  };
  if (rating === 'fuzzy') return {
    ...base, wordId: base.wordId || wordId, status: 'fuzzy', consecutiveKnown: 0,
    nextReviewDate: addLocalDays(localDate, 2), lastStudiedAt: studiedAt, fuzzyCount: base.fuzzyCount + 1,
  };
  const consecutiveKnown = base.consecutiveKnown + 1;
  const days = KNOWN_INTERVALS[Math.min(consecutiveKnown - 1, KNOWN_INTERVALS.length - 1)];
  return {
    ...base, wordId: base.wordId || wordId, status: 'known', consecutiveKnown,
    nextReviewDate: addLocalDays(localDate, days), lastStudiedAt: studiedAt, knownCount: base.knownCount + 1,
  };
}
