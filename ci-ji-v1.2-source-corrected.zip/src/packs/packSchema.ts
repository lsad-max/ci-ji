import { z } from 'zod';
import type { BilingualText, LocalDate } from '../domain/models';

const nullableText = z.union([z.string(), z.null(), z.undefined()]).transform((value) => {
  const text = typeof value === 'string' ? value.trim() : '';
  return text.length ? text : null;
});
const stringArray = z.array(z.string().trim().min(1)).default([]);
const bilingualSchema = z.object({ en: z.string().trim().min(1), zh: z.string().trim().min(1) }).strict();

export const incomingWordSchema = z.object({
  word: z.string().trim().min(1),
  phoneticUK: nullableText,
  phoneticUS: nullableText,
  partOfSpeech: stringArray,
  meanings: z.array(z.string().trim().min(1)).min(1),
  supplementaryMeanings: stringArray,
  categories: stringArray,
  phrases: z.array(bilingualSchema).default([]),
  examples: z.array(bilingualSchema).default([]),
  confusables: stringArray,
  audioUK: nullableText,
  audioUS: nullableText,
}).strict();

export const incomingPackSchema = z.object({
  schemaVersion: z.literal(1),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  theme: z.string().trim().min(1),
  wordCount: z.number().int().nonnegative(),
  createdAt: z.string().default(() => new Date().toISOString()),
  notes: z.string().default(''),
  words: z.array(incomingWordSchema),
}).strict();

export interface IncomingWord {
  word: string;
  phoneticUK: string | null;
  phoneticUS: string | null;
  partOfSpeech: string[];
  meanings: string[];
  supplementaryMeanings: string[];
  categories: string[];
  phrases: BilingualText[];
  examples: BilingualText[];
  confusables: string[];
  audioUK: string | null;
  audioUS: string | null;
}

export interface IncomingPack {
  schemaVersion: 1;
  date: LocalDate;
  theme: string;
  wordCount: number;
  createdAt: string;
  notes: string;
  words: IncomingWord[];
}
