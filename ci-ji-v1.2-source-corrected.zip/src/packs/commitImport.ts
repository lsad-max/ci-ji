import type { IDBPDatabase } from 'idb';
import type { DailyPack, ImportRecord } from '../domain/models';
import type { CiJiDb } from '../db/schema';
import { incomingToWord, mergeWord, type ConflictResolution } from './mergeWord';
import type { ImportPreview } from './previewImport';
import { loadBundledPronunciationMapping } from '../pronunciation/bundledMapping';
import { createUnreviewedRecord } from '../pronunciation/pronunciationRepository';

export interface CommitOptions { replacePack?: boolean; simulateFailureAfterWords?: number }

export async function commitPackImport(
  db: IDBPDatabase<CiJiDb>,
  preview: ImportPreview,
  resolutions: Record<number, ConflictResolution>,
  options: CommitOptions = {},
): Promise<ImportRecord> {
  if (navigator.storage?.estimate) {
    const estimate = await navigator.storage.estimate();
    const free = (estimate.quota ?? Number.POSITIVE_INFINITY) - (estimate.usage ?? 0);
    if (free < preview.estimatedBytes + 1024 * 1024) throw new Error('本地存储空间不足，无法导入词包');
  }
  const existingPack = await db.get('packs', preview.packId);
  const bundledMapping = await loadBundledPronunciationMapping().catch(() => null);
  if (existingPack && !options.replacePack) throw new Error('该日期和主题的词包已存在');

  const tx = db.transaction(['words', 'packs', 'imports', 'pronunciationReviews'], 'readwrite');
  try {
    const wordIds: string[] = [];
    let writes = 0;
    for (const row of preview.rows) {
      const choice = resolutions[row.index] ?? (row.action === 'conflict' ? 'merge' : 'merge');
      if (choice === 'skip') continue;
      let word;
      if (!row.existing) word = incomingToWord(row.incoming, preview.pack.date);
      else if (row.action === 'link-identical') {
        word = mergeWord(row.existing, row.incoming, 'merge', preview.pack.date);
      } else word = mergeWord(row.existing, row.incoming, choice, preview.pack.date);
      await tx.objectStore('words').put(word);
      if (!row.existing) {
        for (const accent of ['en-GB', 'en-US'] as const) {
          const mapped = bundledMapping?.words[word.normalizedKey]?.[accent === 'en-GB' ? 'british' : 'american'];
          if (mapped?.status === 'approved') continue;
          const review = createUnreviewedRecord(word.id, word.normalizedKey, accent);
          if (!await tx.objectStore('pronunciationReviews').get(review.id)) {
            await tx.objectStore('pronunciationReviews').put(review);
          }
        }
      }
      wordIds.push(word.id);
      writes += 1;
      if (options.simulateFailureAfterWords === writes) throw new Error('模拟导入失败');
    }
    const categories = [...new Set(preview.pack.words.flatMap((word) => word.categories))];
    const dailyPack: DailyPack = {
      id: preview.packId, schemaVersion: 1, date: preview.pack.date, theme: preview.pack.theme,
      wordCount: wordIds.length, createdAt: preview.pack.createdAt, notes: preview.pack.notes, wordIds, categories,
    };
    if (existingPack && options.replacePack) await tx.objectStore('packs').delete(preview.packId);
    await tx.objectStore('packs').put(dailyPack);
    const record: ImportRecord = {
      id: `import-${crypto.randomUUID()}`, fileName: preview.fileName, packId: preview.packId,
      importedAt: new Date().toISOString(), newWordCount: preview.counts.create,
      linkedWordCount: preview.counts['link-identical'], supplementedWordCount: preview.counts.supplement + preview.counts.conflict,
    };
    await tx.objectStore('imports').put(record);
    await tx.done;
    return record;
  } catch (error) {
    try { tx.abort(); } catch { /* transaction may already be inactive */ }
    await tx.done.catch(() => undefined);
    throw error;
  }
}
