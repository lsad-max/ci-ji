import type { LocalDate, WordEntry } from '../domain/models';
import type { IncomingWord } from './packSchema';
import { normalizeWordKey } from '../domain/normalize';

export type ConflictResolution = 'merge' | 'keep-existing' | 'use-incoming' | 'skip';

function uniqueStrings(existing: string[], incoming: string[]): string[] {
  const seen = new Set(existing);
  return [...existing, ...incoming.filter((item) => !seen.has(item) && (seen.add(item), true))];
}
function uniqueObjects<T extends { en: string; zh: string }>(existing: T[], incoming: T[]): T[] {
  const seen = new Set(existing.map((item) => `${item.en}\u0000${item.zh}`));
  return [...existing, ...incoming.filter((item) => {
    const key = `${item.en}\u0000${item.zh}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  })];
}

export function incomingToWord(incoming: IncomingWord, date: LocalDate, nowIso = new Date().toISOString()): WordEntry {
  return {
    id: `word-${crypto.randomUUID()}`,
    normalizedKey: normalizeWordKey(incoming.word),
    word: incoming.word,
    phoneticUK: incoming.phoneticUK,
    phoneticUS: incoming.phoneticUS,
    partOfSpeech: [...incoming.partOfSpeech],
    meanings: [...incoming.meanings],
    supplementaryMeanings: [...incoming.supplementaryMeanings],
    categories: [...incoming.categories],
    phrases: structuredClone(incoming.phrases),
    examples: structuredClone(incoming.examples),
    confusables: [...incoming.confusables],
    audioUK: incoming.audioUK,
    audioUS: incoming.audioUS,
    appearedDates: [date],
    occurrenceCount: 1,
    createdAt: nowIso,
    updatedAt: nowIso,
  };
}

export function mergeWord(existing: WordEntry, incoming: IncomingWord, choice: ConflictResolution, date?: LocalDate): WordEntry {
  if (choice === 'skip' || choice === 'keep-existing') return structuredClone(existing);
  const occurrenceDate = date ?? existing.appearedDates.at(-1)!;
  if (choice === 'use-incoming') {
    const replacement = incomingToWord(incoming, occurrenceDate, existing.updatedAt);
    return { ...replacement, id: existing.id, createdAt: existing.createdAt, appearedDates: uniqueStrings(existing.appearedDates, [occurrenceDate]) as LocalDate[], occurrenceCount: existing.appearedDates.includes(occurrenceDate) ? existing.occurrenceCount : existing.occurrenceCount + 1 };
  }
  const addedDate = !existing.appearedDates.includes(occurrenceDate);
  return {
    ...existing,
    word: existing.word || incoming.word,
    phoneticUK: existing.phoneticUK ?? incoming.phoneticUK,
    phoneticUS: existing.phoneticUS ?? incoming.phoneticUS,
    partOfSpeech: uniqueStrings(existing.partOfSpeech, incoming.partOfSpeech),
    meanings: uniqueStrings(existing.meanings, incoming.meanings),
    supplementaryMeanings: uniqueStrings(existing.supplementaryMeanings, incoming.supplementaryMeanings),
    categories: uniqueStrings(existing.categories, incoming.categories),
    phrases: uniqueObjects(existing.phrases, incoming.phrases),
    examples: uniqueObjects(existing.examples, incoming.examples),
    confusables: uniqueStrings(existing.confusables, incoming.confusables),
    audioUK: existing.audioUK ?? incoming.audioUK,
    audioUS: existing.audioUS ?? incoming.audioUS,
    appearedDates: uniqueStrings(existing.appearedDates, [occurrenceDate]) as LocalDate[],
    occurrenceCount: existing.occurrenceCount + (addedDate ? 1 : 0),
    updatedAt: new Date().toISOString(),
  };
}
