import type { WordEntry } from '../domain/models';
import { normalizeWordKey } from '../domain/normalize';
import type { IncomingPack, IncomingWord } from './packSchema';

export type PreviewAction = 'create' | 'link-identical' | 'supplement' | 'conflict' | 'invalid';
export interface PreviewWord { index: number; incoming: IncomingWord; existing: WordEntry | null; action: PreviewAction; normalizedKey: string; issues: string[] }
export interface ImportPreview {
  pack: IncomingPack;
  packId: string;
  fileName: string;
  rows: PreviewWord[];
  counts: Record<PreviewAction, number>;
  categoryCounts: Record<string, number>;
  estimatedBytes: number;
}

const sameArray = (a: string[], b: string[]) => a.length === b.length && a.every((value, index) => value === b[index]);
function classify(existing: WordEntry, incoming: IncomingWord): PreviewAction {
  const identical = existing.phoneticUK === incoming.phoneticUK
    && existing.phoneticUS === incoming.phoneticUS
    && sameArray(existing.partOfSpeech, incoming.partOfSpeech)
    && sameArray(existing.meanings, incoming.meanings)
    && incoming.categories.every((category) => existing.categories.includes(category));
  if (identical) return 'link-identical';
  const phoneticConflict = Boolean(existing.phoneticUK && incoming.phoneticUK && existing.phoneticUK !== incoming.phoneticUK)
    || Boolean(existing.phoneticUS && incoming.phoneticUS && existing.phoneticUS !== incoming.phoneticUS);
  return phoneticConflict ? 'conflict' : 'supplement';
}

export function buildImportPreview(pack: IncomingPack, existingWords: WordEntry[], fileName = `${pack.date}-${pack.theme}.json`): ImportPreview {
  const byKey = new Map(existingWords.map((word) => [word.normalizedKey, word]));
  const rows = pack.words.map((incoming, index): PreviewWord => {
    const normalizedKey = normalizeWordKey(incoming.word);
    const existing = byKey.get(normalizedKey) ?? null;
    return { index, incoming, existing, normalizedKey, action: existing ? classify(existing, incoming) : 'create', issues: [] };
  });
  const counts: Record<PreviewAction, number> = { create: 0, 'link-identical': 0, supplement: 0, conflict: 0, invalid: 0 };
  const categoryCounts: Record<string, number> = {};
  for (const row of rows) {
    counts[row.action] += 1;
    for (const category of row.incoming.categories) categoryCounts[category] = (categoryCounts[category] ?? 0) + 1;
  }
  return {
    pack, rows, counts, categoryCounts, fileName,
    packId: `pack-${pack.date}-${normalizeWordKey(pack.theme).replace(/\s+/g, '-')}`,
    estimatedBytes: new TextEncoder().encode(JSON.stringify(pack)).byteLength,
  };
}
