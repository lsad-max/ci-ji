import { ZodError } from 'zod';
import { incomingPackSchema, type IncomingPack } from './packSchema';

export interface PackIssue {
  code: 'json' | 'schema' | 'count' | 'unsupported-version';
  path: string;
  message: string;
  wordIndex: number | null;
}
export type PackParseResult = { ok: true; pack: IncomingPack } | { ok: false; issues: PackIssue[] };

export function parsePackJson(text: string): PackParseResult {
  let raw: unknown;
  try { raw = JSON.parse(text); } catch {
    return { ok: false, issues: [{ code: 'json', path: '', message: 'JSON格式错误', wordIndex: null }] };
  }
  if (typeof raw === 'object' && raw !== null && 'schemaVersion' in raw && (raw as { schemaVersion?: unknown }).schemaVersion !== 1) {
    return { ok: false, issues: [{ code: 'unsupported-version', path: 'schemaVersion', message: '不支持的词包版本', wordIndex: null }] };
  }
  try {
    const parsed = incomingPackSchema.parse(raw) as IncomingPack;
    if (parsed.wordCount !== parsed.words.length) {
      return { ok: false, issues: [{ code: 'count', path: 'wordCount', message: `标注${parsed.wordCount}词，实际${parsed.words.length}词`, wordIndex: null }] };
    }
    return { ok: true, pack: parsed };
  } catch (error) {
    if (!(error instanceof ZodError)) return { ok: false, issues: [{ code: 'schema', path: '', message: '词包结构错误', wordIndex: null }] };
    return {
      ok: false,
      issues: error.issues.map((issue) => ({
        code: 'schema' as const,
        path: issue.path.join('.'),
        message: issue.message,
        wordIndex: issue.path[0] === 'words' && typeof issue.path[1] === 'number' ? issue.path[1] : null,
      })),
    };
  }
}
