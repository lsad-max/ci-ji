import { addLocalDays } from '../domain/dates';
import type { DailyPack, LocalDate, MasteryStatus, StudyEvent, WordEntry } from '../domain/models';

export interface TimePoint { date: LocalDate; count: number }
export interface ThemeStat { theme: string; total: number; known: number; masteryPercent: number }
export interface ErrorWord { wordId: string; word: string; errors: number }
export interface PackCompletion { packId: string; date: LocalDate; theme: string; learned: number; total: number; percent: number }
export interface LearningStatistics {
  todayEvents: number; todayUniqueWords: number; totalUniqueWords: number;
  mastery: Record<MasteryStatus, number>; masteryPercent: Record<MasteryStatus, number>;
  streakDays: number; sevenDay: TimePoint[]; thirtyDay: TimePoint[];
  themes: ThemeStat[]; highErrors: ErrorWord[]; packCompletion: PackCompletion[];
  wordHistory: Record<string, StudyEvent[]>;
}
const percent=(value:number,total:number)=>total?Math.round(value/total*100):0;
function currentStatuses(events:StudyEvent[]):Map<string,MasteryStatus>{const latest=new Map<string,StudyEvent>();for(const event of [...events].sort((a,b)=>a.studiedAt.localeCompare(b.studiedAt)))latest.set(event.wordId,event);return new Map([...latest].map(([id,event])=>[id,event.rating]));}
function series(events:StudyEvent[],today:LocalDate,days:number):TimePoint[]{const counts=new Map<string,number>();for(const event of events)counts.set(event.localDate,(counts.get(event.localDate)??0)+1);return Array.from({length:days},(_,i)=>{const date=addLocalDays(today,i-days+1);return{date,count:counts.get(date)??0};});}
export function buildStatistics(events:StudyEvent[],words:WordEntry[],packs:DailyPack[],today:LocalDate):LearningStatistics{
 const statuses=currentStatuses(events);const mastery:Record<MasteryStatus,number>={unseen:0,known:0,fuzzy:0,unknown:0};for(const word of words)mastery[statuses.get(word.id)??'unseen']+=1;const masteryPercent={unseen:percent(mastery.unseen,words.length),known:percent(mastery.known,words.length),fuzzy:percent(mastery.fuzzy,words.length),unknown:percent(mastery.unknown,words.length)};
 const activeDates=new Set(events.map(e=>e.localDate));let streakDays=0;let cursor=today;if(!activeDates.has(today)){const yesterday=addLocalDays(today,-1);if(activeDates.has(yesterday))cursor=yesterday;else cursor=today;}while(activeDates.has(cursor)){streakDays++;cursor=addLocalDays(cursor,-1);}
 const wordMap=new Map(words.map(w=>[w.id,w]));const themes=[...new Set(packs.map(p=>p.theme))].map(theme=>{const ids=new Set(packs.filter(p=>p.theme===theme).flatMap(p=>p.wordIds));const known=[...ids].filter(id=>statuses.get(id)==='known').length;return{theme,total:ids.size,known,masteryPercent:percent(known,ids.size)};});
 const errors=new Map<string,number>();for(const event of events)if(event.rating!=='known')errors.set(event.wordId,(errors.get(event.wordId)??0)+1);const highErrors=[...errors].map(([wordId,count])=>({wordId,word:wordMap.get(wordId)?.word??wordId,errors:count})).sort((a,b)=>b.errors-a.errors||a.word.localeCompare(b.word)).slice(0,20);
 const packCompletion=packs.map(pack=>{const learned=new Set(events.filter(e=>e.packId===pack.id&&e.phase==='first-pass').map(e=>e.wordId)).size;return{packId:pack.id,date:pack.date,theme:pack.theme,learned,total:pack.wordIds.length,percent:percent(learned,pack.wordIds.length)};}).sort((a,b)=>b.date.localeCompare(a.date));
 const wordHistory:Record<string,StudyEvent[]>={};for(const event of [...events].sort((a,b)=>a.studiedAt.localeCompare(b.studiedAt)))(wordHistory[event.wordId]??=[]).push(event);
 return{todayEvents:events.filter(e=>e.localDate===today).length,todayUniqueWords:new Set(events.filter(e=>e.localDate===today).map(e=>e.wordId)).size,totalUniqueWords:words.length,mastery,masteryPercent,streakDays,sevenDay:series(events,today,7),thirtyDay:series(events,today,30),themes,highErrors,packCompletion,wordHistory};
}
