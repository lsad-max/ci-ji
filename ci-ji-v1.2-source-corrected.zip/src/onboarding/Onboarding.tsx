import { useState } from 'react';
import { BookOpenCheck, Layers3, Upload } from 'lucide-react';
import './onboarding.css';

const steps = [
  { title: '导入每日词包', body: '每天导入一个经过校对的词包，按日期留下清晰的学习轨迹。', Icon: Upload },
  { title: '判断认识、模糊、不认识', body: '先看英文并揭晓中文，再用三档按钮记录真实掌握程度。', Icon: BookOpenCheck },
  { title: '用沉浸词表快速浏览', body: '所有释义默认收起，点一个词只展开一个解释，适合快速刷词。', Icon: Layers3 },
] as const;

export function Onboarding({ onDone }: { onDone: () => void | Promise<void> }) {
  const [index, setIndex] = useState(0);
  const step = steps[index];
  return (
    <section className="onboarding" aria-label="新手引导">
      <button className="text-button onboarding__skip" onClick={() => void onDone()}>跳过</button>
      <div className="onboarding__art"><step.Icon size={54} strokeWidth={1.7} aria-hidden="true" /></div>
      <div className="onboarding__copy">
        <p className="onboarding__count">{index + 1} / 3</p>
        <h1>{step.title}</h1>
        <p>{step.body}</p>
      </div>
      <div className="onboarding__dots" aria-hidden="true">{steps.map((_, i) => <span key={i} className={i === index ? 'is-active' : ''} />)}</div>
      <button className="primary-button onboarding__next" onClick={() => index < 2 ? setIndex(index + 1) : void onDone()}>
        {index < 2 ? '下一步' : '开始使用'}
      </button>
    </section>
  );
}
