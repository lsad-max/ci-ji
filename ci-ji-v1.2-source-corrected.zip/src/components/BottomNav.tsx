import { BookOpen, ChartNoAxesColumnIncreasing, Home, Settings } from 'lucide-react';
import { NavLink } from 'react-router-dom';

const items = [
  { to: '/', label: '首页', Icon: Home, end: true },
  { to: '/library', label: '词库', Icon: BookOpen, end: false },
  { to: '/records', label: '记录', Icon: ChartNoAxesColumnIncreasing, end: false },
  { to: '/settings', label: '设置', Icon: Settings, end: false },
] as const;

export function BottomNav() {
  return <nav className="bottom-nav" aria-label="主导航">{items.map(({ to, label, Icon, end }) => (
    <NavLink key={to} to={to} end={end} className={({ isActive }) => isActive ? 'bottom-nav__item is-active' : 'bottom-nav__item'}>
      {({ isActive }) => <><Icon size={21} strokeWidth={isActive ? 2.4 : 1.8} aria-hidden="true" /><span>{label}</span></>}
    </NavLink>
  ))}</nav>;
}
