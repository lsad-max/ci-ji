import { useState } from 'react';
import { DESTRUCTIVE_CONFIRMATION } from '../domain/constants';

export function ConfirmPhraseDialog({ title, description, onConfirm, onCancel }: { title: string; description: string; onConfirm: () => void | Promise<void>; onCancel: () => void }) {
  const [value,setValue]=useState(''); const [busy,setBusy]=useState(false);
  return <div className="dialog-backdrop" role="presentation"><section className="dialog" role="dialog" aria-modal="true" aria-labelledby="confirm-title"><h2 id="confirm-title">{title}</h2><p>{description}</p><label>请输入 <b>{DESTRUCTIVE_CONFIRMATION}</b><input autoFocus value={value} onChange={event=>setValue(event.target.value)}/></label><div className="dialog-actions"><button className="secondary-button" onClick={onCancel}>取消</button><button className="danger-button" disabled={value!==DESTRUCTIVE_CONFIRMATION||busy} onClick={async()=>{setBusy(true);try{await onConfirm();}finally{setBusy(false);}}}>确认</button></div></section></div>;
}
