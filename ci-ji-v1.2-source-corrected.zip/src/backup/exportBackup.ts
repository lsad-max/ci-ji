import type { IDBPDatabase } from 'idb';
import type { CiJiDb } from '../db/schema';
import { todayLocal } from '../domain/dates';
import type { CompleteBackupV2 } from './backupSchema';

export type BackupBlob = Blob & { fileName: string };

export async function readCompleteBackup(db: IDBPDatabase<CiJiDb>): Promise<CompleteBackupV2> {
  const [words, packs, studyStates, studyEvents, sessions, settings, imports, trash, reviews] = await Promise.all([
    db.getAll('words'), db.getAll('packs'), db.getAll('studyStates'), db.getAll('studyEvents'),
    db.getAll('sessions'), db.get('settings', 'singleton'), db.getAll('imports'), db.getAll('trash'),
    db.getAll('pronunciationReviews'),
  ]);
  if (!settings) throw new Error('设置数据缺失，无法生成完整备份');
  return {
    schemaVersion: 2,
    app: '词迹',
    exportedAt: new Date().toISOString(),
    localDate: todayLocal(),
    data: {
      words, packs, studyStates, studyEvents, sessions, settings, imports, trash,
      pronunciationReviews: reviews.filter((review) => review.origin === 'user'),
    },
  };
}

export async function exportCompleteBackup(db: IDBPDatabase<CiJiDb>): Promise<BackupBlob> {
  const backup = await readCompleteBackup(db);
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' }) as BackupBlob;
  blob.fileName = `词迹完整备份-${backup.localDate}.json`;
  return blob;
}
