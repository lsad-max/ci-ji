import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import type { LearningDirection, WordEntry } from '../domain/models';
import { SpeechButton } from '../speech/SpeechButton';

export function StudyCard({ word, direction, revealed, onReveal, showPhonetic }: { word: WordEntry; direction: LearningDirection; revealed: boolean; onReveal: () => void; showPhonetic: boolean }) {
  const [more, setMore] = useState(false);
  const hasMore = word.phrases.length + word.examples.length + word.confusables.length + word.supplementaryMeanings.length > 0;
  const frontMain = direction === 'en-zh' ? word.word : word.meanings.join('；');
  return <article className={`study-card ${revealed ? 'is-revealed' : ''}`}>
    <button className="study-card__reveal" aria-label="查看释义" onClick={onReveal} disabled={revealed}>
      <span className={direction === 'en-zh' ? 'study-card__word' : 'study-card__meaning-front'}>{frontMain}</span>
      {direction === 'en-zh' && showPhonetic ? <span className="study-card__phonetic">{word.phoneticUK ?? '暂无音标'}</span> : null}
      {!revealed ? <span className="study-card__hint">点击卡片查看{direction === 'en-zh' ? '释义' : '英文'}</span> : null}
    </button>
    <div className="study-card__speech"><SpeechButton word={word} showAttribution /></div>
    {revealed ? <div className="study-card__answer">
      {direction === 'en-zh' ? <><p className="study-card__pos">{word.partOfSpeech.join(' / ')}</p><p className="study-card__meaning">{word.meanings.join('；')}</p></> : <><p className="study-card__word study-card__word--answer">{word.word}</p>{showPhonetic ? <p className="study-card__phonetic">{word.phoneticUK ?? '暂无音标'}</p> : null}</>}
      {hasMore ? <button className="more-button" onClick={() => setMore((value) => !value)}>更多内容 {more ? <ChevronUp size={17}/> : <ChevronDown size={17}/>}</button> : null}
      {more ? <div className="study-card__more">
        {word.supplementaryMeanings.length ? <section><h3>补充释义</h3><p>{word.supplementaryMeanings.join('；')}</p></section> : null}
        {word.phrases.length ? <section><h3>常见搭配</h3>{word.phrases.map((item) => <p key={item.en}><b>{item.en}</b><br/>{item.zh}</p>)}</section> : null}
        {word.examples.length ? <section><h3>例句</h3>{word.examples.map((item) => <p key={item.en}><b>{item.en}</b><br/>{item.zh}</p>)}</section> : null}
        {word.confusables.length ? <section><h3>易混词</h3><p>{word.confusables.join(' / ')}</p></section> : null}
      </div> : null}
    </div> : null}
  </article>;
}
