import { useCallback, useEffect, useMemo, useState } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import { useRepositories } from '../db/RepositoriesContext';
import type { DailyPack, Rating, StudySession, StudyState, WordEntry } from '../domain/models';
import { todayLocal } from '../domain/dates';
import { useSettings } from '../settings/SettingsProvider';
import { createDailySession, createReviewSession, rateCurrentCard } from '../study/sessionEngine';
import { createStudyRepository } from '../study/studyRepository';

export type CardSessionStatus = 'loading' | 'empty' | 'active' | 'first-pass-complete' | 'fully-complete';

export function useCardSession() {
  const repositories = useRepositories();
  const { settings } = useSettings();
  const params = useParams();
  const location = useLocation();
  const [session, setSession] = useState<StudySession | null>(null);
  const [pack, setPack] = useState<DailyPack | null>(null);
  const [word, setWord] = useState<WordEntry | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showFirstPassSummary, setShowFirstPassSummary] = useState(false);
  const studyRepository = useMemo(() => createStudyRepository(repositories), [repositories]);

  const loadCurrentWord = useCallback(async (value: StudySession | null) => {
    const card = value?.queue[value.cursor];
    setWord(card ? await repositories.words.get(card.wordId) ?? null : null);
    setRevealed(false);
  }, [repositories]);

  const initialize = useCallback(async () => {
    setLoading(true);
    const mode = params.mode ?? (location.pathname.includes('/review') ? 'review' : 'today');
    let nextSession: StudySession | undefined;
    let selectedPack: DailyPack | null = null;
    if (mode === 'continue' && params.sessionId) {
      nextSession = await repositories.sessions.get(params.sessionId);
      selectedPack = nextSession?.packId ? await repositories.packs.get(nextSession.packId) ?? null : null;
    } else if (mode === 'review') {
      const id = `review:${todayLocal()}`;
      nextSession = await repositories.sessions.get(id);
      if (!nextSession) {
        const due = await repositories.studyStates.getDue(todayLocal());
        nextSession = createReviewSession(due, Math.random, settings.direction);
        nextSession.id = id;
        await repositories.sessions.put(nextSession);
      }
    } else {
      const packs = await repositories.packs.getAll();
      selectedPack = packs.find((item) => item.date === todayLocal()) ?? packs.sort((a,b) => b.date.localeCompare(a.date))[0] ?? null;
      if (selectedPack) {
        const id = `daily:${selectedPack.id}`;
        nextSession = await repositories.sessions.get(id);
        if (!nextSession) {
          nextSession = createDailySession(selectedPack, settings);
          await repositories.sessions.put(nextSession);
        }
      }
    }
    setPack(selectedPack);
    setSession(nextSession ?? null);
    setShowFirstPassSummary(Boolean(nextSession?.completedFirstPassAt && !nextSession.completedAt));
    await loadCurrentWord(nextSession ?? null);
    setLoading(false);
  }, [location.pathname, params.mode, params.sessionId, repositories, settings, loadCurrentWord]);

  useEffect(() => { void initialize(); }, [initialize]);

  const reveal = useCallback(() => setRevealed(true), []);
  const rate = useCallback(async (rating: Rating) => {
    if (!session || !word || !revealed) return;
    const previous = await repositories.studyStates.get(word.id);
    const mutation = rateCurrentCard(session, previous, rating, Math.random, { localDate: todayLocal(), studiedAt: new Date().toISOString() });
    await studyRepository.commitRating(mutation);
    const firstPassJustCompleted = !session.completedFirstPassAt && Boolean(mutation.session.completedFirstPassAt) && !mutation.session.completedAt;
    setSession(mutation.session);
    setShowFirstPassSummary(firstPassJustCompleted);
    await loadCurrentWord(mutation.session);
  }, [session, word, revealed, repositories, studyRepository, loadCurrentWord]);

  const undo = useCallback(async () => {
    if (!session?.undo) return;
    const rewound = await studyRepository.undoLast(session.id);
    setSession(rewound);
    setShowFirstPassSummary(false);
    await loadCurrentWord(rewound);
  }, [session, studyRepository, loadCurrentWord]);

  const resetSession = useCallback(async () => {
    if (!pack) return;
    const fresh = createDailySession(pack, settings);
    await repositories.sessions.put(fresh);
    setSession(fresh); setShowFirstPassSummary(false); await loadCurrentWord(fresh);
  }, [pack, settings, repositories, loadCurrentWord]);

  const restartViewKeepMastery = resetSession;
  const status: CardSessionStatus = loading ? 'loading' : !session || session.queue.length === 0 ? 'empty' : session.completedAt ? 'fully-complete' : showFirstPassSummary ? 'first-pass-complete' : 'active';
  const denominator = pack?.wordIds.length ?? (session?.kind === 'review' ? session.queue.length : 0);
  const numerator = session?.kind === 'daily' ? session.firstPassSeenWordIds.length : session?.cursor ?? 0;
  const currentCard = session?.queue[session.cursor] ?? null;

  return {
    status, session, pack, word, revealed, reveal, rate, undo, resetSession, restartViewKeepMastery,
    continueReinforcement: () => setShowFirstPassSummary(false), numerator, denominator, currentCard,
  };
}
