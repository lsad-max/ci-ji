import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, MoreHorizontal, RotateCcw } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useSettings } from '../settings/SettingsProvider';
import { useSpeech } from '../speech/useSpeech';
import type { Rating } from '../domain/models';
import { RatingBar } from './RatingBar';
import { StudyCard } from './StudyCard';
import { useCardSession } from './useCardSession';
import './card-study.css';

export function CardStudyPage() {
  const navigate = useNavigate();
  const { settings, patchSettings } = useSettings();
  const { speak } = useSpeech();
  const data = useCardSession();
  const [menu, setMenu] = useState(false);
  const start = useRef<{x:number;y:number}|null>(null);

  useEffect(() => {
    if (data.word && settings.autoSpeakCards && settings.speechUnlocked && data.status === 'active') void speak(data.word);
  }, [data.word?.id, settings.autoSpeakCards, settings.speechUnlocked]);
  const rate = (rating: Rating) => void data.rate(rating);
  const onPointerUp = (event: React.PointerEvent) => {
    if (!start.current || !data.revealed || !settings.gesturesEnabled) return;
    const dx = event.clientX - start.current.x; const dy = event.clientY - start.current.y; start.current = null;
    if (Math.abs(dx) < 72 && Math.abs(dy) < 72) return;
    if (Math.abs(dx) > Math.abs(dy)) rate(dx > 0 ? 'known' : 'unknown');
    else if (dy < 0) rate('fuzzy');
  };
  if (data.status === 'loading') return <div className="study-screen study-screen--center">正在准备词卡…</div>;
  if (data.status === 'empty') return <div className="study-screen study-screen--center"><h1>暂无可学习单词</h1><Link className="primary-button" to="/">返回首页</Link></div>;
  if (data.status === 'first-pass-complete') return <div className="study-screen study-screen--center completion-card"><span className="completion-mark">✓</span><h1>今日新词浏览完成</h1><p>共学习 {data.denominator} 词</p><div className="completion-counts"><span>认识 <b>{data.session?.ratingCounts.known}</b></span><span>模糊 <b>{data.session?.ratingCounts.fuzzy}</b></span><span>不认识 <b>{data.session?.ratingCounts.unknown}</b></span></div><button className="primary-button" onClick={data.continueReinforcement}>继续强化</button><Link className="secondary-button" to="/">返回首页</Link><Link className="text-button" to={`/immersive/${data.pack?.id ?? 'today'}`}>进入沉浸词表</Link></div>;
  if (data.status === 'fully-complete') return <div className="study-screen study-screen--center completion-card"><span className="completion-mark">✓</span><h1>本轮学习完成</h1><p>你的评价已保存，系统会按计划安排复习。</p><Link className="primary-button" to="/">返回首页</Link></div>;
  if (!data.word || !data.session || !data.currentCard) return null;
  return <div className="study-screen" onPointerDown={(e) => { start.current={x:e.clientX,y:e.clientY}; }} onPointerUp={onPointerUp}>
    <header className="study-header"><button aria-label="返回" onClick={() => navigate(-1)}><ArrowLeft/></button><div><b>{data.pack?.theme ?? '到期复习'}</b><span>{data.currentCard.phase === 'reinforcement' ? `强化 · ${data.word.word}` : `${data.numerator} / ${data.denominator}`}</span></div><button aria-label="学习菜单" onClick={() => setMenu(!menu)}><MoreHorizontal/></button></header>
    {menu ? <div className="study-menu"><button onClick={() => { setMenu(false); void data.resetSession(); }}><RotateCcw size={17}/>重新开始本次学习</button><button onClick={() => { setMenu(false); void data.restartViewKeepMastery(); }}>从头浏览但保留掌握记录</button></div> : null}
    <div className="study-stage"><StudyCard word={data.word} direction={data.session.direction} revealed={data.revealed} onReveal={data.reveal} showPhonetic={settings.showPhonetic} /></div>
    {settings.gesturesEnabled && !settings.gestureHintSeen ? <div className="gesture-hint">左滑不认识 · 上滑模糊 · 右滑认识 <button onClick={() => void patchSettings({ gestureHintSeen: true })}>知道了</button></div> : null}
    {data.revealed ? <RatingBar onRate={rate} /> : null}
    {data.session.undo ? <button className="undo-toast" onClick={() => void data.undo()}>已记录　撤销</button> : null}
  </div>;
}
