import type { Rating } from '../domain/models';

export function RatingBar({ onRate }: { onRate: (rating: Rating) => void }) {
  return <div className="rating-bar" aria-label="掌握程度">
    <button className="rating-button rating-button--unknown" onClick={() => onRate('unknown')}>不认识</button>
    <button className="rating-button rating-button--fuzzy" onClick={() => onRate('fuzzy')}>模糊</button>
    <button className="rating-button rating-button--known" onClick={() => onRate('known')}>认识</button>
  </div>;
}
