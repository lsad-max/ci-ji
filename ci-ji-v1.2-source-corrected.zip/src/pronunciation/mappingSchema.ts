import { z } from 'zod';

const missing = z.object({
  status: z.literal('missing'),
  accent: z.enum(['en-GB', 'en-US']),
}).strict();

const approved = z.object({
  status: z.literal('approved'),
  accent: z.enum(['en-GB', 'en-US']),
  audioUrl: z.string().url(),
  compatibleAudioUrl: z.string().url().nullable(),
  filePageUrl: z.string().url(),
  author: z.string().trim().min(1),
  licenseName: z.string().trim().min(1),
  licenseUrl: z.string().url().nullable(),
  sourceFileName: z.string().trim().min(1),
  durationSeconds: z.number().positive().max(12).nullable(),
}).strict();

const accentRecord = z.discriminatedUnion('status', [missing, approved]);
export const bundledMappingSchema = z.object({
  schemaVersion: z.literal(1),
  mappingVersion: z.number().int().positive(),
  generatedAt: z.string().datetime(),
  words: z.record(z.string().min(1), z.object({
    british: accentRecord,
    american: accentRecord,
  }).strict()),
}).strict();

export type BundledMapping = z.infer<typeof bundledMappingSchema>;
export type BundledAccentRecord = z.infer<typeof accentRecord>;
export const parseBundledMapping = (input: unknown): BundledMapping => bundledMappingSchema.parse(input);
