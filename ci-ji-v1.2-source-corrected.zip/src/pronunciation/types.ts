import type { Accent } from '../domain/models';

export type PronunciationAccent = Accent | 'unknown';
export type PronunciationStatus = 'unreviewed' | 'approved' | 'rejected' | 'missing';
export type PronunciationSourcePreference = 'wikimedia-first' | 'local-first' | 'system-only';
export type PronunciationOrigin = 'bundled' | 'user';

export interface PronunciationAttribution {
  author: string;
  licenseName: string;
  licenseUrl: string | null;
  filePageUrl: string;
  sourceFileName: string;
}

export interface ApprovedPronunciation extends PronunciationAttribution {
  accent: Accent;
  audioUrl: string;
  compatibleAudioUrl: string | null;
  durationSeconds: number | null;
  mappingVersion: number;
}

export interface PronunciationReviewRecord {
  id: string;
  wordId: string;
  normalizedKey: string;
  accent: Accent;
  status: PronunciationStatus;
  selected: ApprovedPronunciation | null;
  origin: PronunciationOrigin;
  reviewedAt: string | null;
  updatedAt: string;
}

export interface PronunciationCandidateRecord extends PronunciationAttribution {
  id: string;
  wordId: string;
  normalizedKey: string;
  accent: PronunciationAccent;
  audioUrl: string;
  compatibleAudioUrl: string | null;
  durationSeconds: number | null;
  source: 'wiktionary' | 'commons-search';
  rank: number;
  rejected: boolean;
  fetchedAt: string;
}

export const pronunciationReviewId = (wordId: string, accent: Accent) => `${wordId}:${accent}`;
