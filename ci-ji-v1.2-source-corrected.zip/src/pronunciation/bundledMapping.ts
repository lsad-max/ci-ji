import type { Accent } from '../domain/models';
import { parseBundledMapping, type BundledMapping } from './mappingSchema';

let pending: Promise<BundledMapping> | null = null;

export function loadBundledPronunciationMapping(fetcher: typeof fetch = fetch): Promise<BundledMapping> {
  pending ??= fetcher(`${import.meta.env.BASE_URL}data/wikimedia-pronunciations.json`)
    .then((response) => {
      if (!response.ok) throw new Error(`真人录音映射加载失败：${response.status}`);
      return response.json();
    })
    .then(parseBundledMapping)
    .catch((error) => {
      pending = null;
      throw error;
    });
  return pending;
}

export async function getBundledPronunciation(normalizedKey: string, accent: Accent) {
  const mapping = await loadBundledPronunciationMapping();
  return mapping.words[normalizedKey]?.[accent === 'en-GB' ? 'british' : 'american'] ?? null;
}

export function resetBundledMappingForTests() {
  pending = null;
}
