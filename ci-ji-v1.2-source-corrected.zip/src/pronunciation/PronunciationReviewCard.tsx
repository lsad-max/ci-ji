import { Volume2 } from 'lucide-react';
import type { PronunciationCandidateRecord } from './types';

export function PronunciationReviewCard({
  candidate,
  selected,
  onSelect,
  onPreview,
  onApprove,
  onReject,
}: {
  candidate: PronunciationCandidateRecord;
  selected: boolean;
  onSelect(): void;
  onPreview(): void;
  onApprove(): void;
  onReject(): void;
}) {
  const accentLabel = candidate.accent === 'en-GB'
    ? '英式'
    : candidate.accent === 'en-US'
      ? '美式'
      : '未标明';
  return <article className={`pronunciation-candidate ${selected ? 'is-selected' : ''}`}>
    <button type="button" className="pronunciation-candidate__main" onClick={onSelect} aria-pressed={selected}>
      <b>{accentLabel}</b>
      <span>{candidate.sourceFileName}</span>
      <small>{candidate.author} · {candidate.licenseName}</small>
    </button>
    <div className="pronunciation-candidate__actions">
      <button type="button" onClick={onPreview}><Volume2 size={16}/>试听</button>
      <button type="button" onClick={onApprove} disabled={candidate.accent === 'unknown'}>确认使用</button>
      <button type="button" onClick={onReject}>拒绝候选</button>
    </div>
  </article>;
}
