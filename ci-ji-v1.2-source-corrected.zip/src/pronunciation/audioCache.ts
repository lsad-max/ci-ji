import type { ApprovedPronunciation } from './types';

export const PRONUNCIATION_CACHE = 'ci-ji-wikimedia-audio-v1';
const DOWNLOAD_CONCURRENCY = 3;

export interface CachedPronunciation {
  objectUrl: string;
  bytes: number;
  cacheKey: string;
  revoke(): void;
}

export interface DownloadReport {
  success: number;
  failed: number;
  skipped: number;
  bytes: number;
}

export interface DownloadProgress extends DownloadReport {
  total: number;
  completed: number;
}

export interface DownloadOptions {
  onProgress?: (progress: DownloadProgress) => void;
}

export interface DownloadController {
  pause(): void;
  resume(): void;
  cancel(): void;
  result: Promise<DownloadReport>;
}

export interface PronunciationCacheStats {
  entries: number;
  bytes: number;
}

function playbackUrl(record: ApprovedPronunciation): string {
  return record.compatibleAudioUrl ?? record.audioUrl;
}

export function cacheRequest(record: ApprovedPronunciation): Request {
  const url = new URL(playbackUrl(record));
  url.searchParams.set('ci_ji_mapping', String(record.mappingVersion));
  return new Request(url.toString(), { method: 'GET', mode: 'cors' });
}

function createCached(response: Response, request: Request): Promise<CachedPronunciation> {
  return response.blob().then((blob) => {
    const objectUrl = URL.createObjectURL(blob);
    let revoked = false;
    return {
      objectUrl,
      bytes: blob.size,
      cacheKey: request.url,
      revoke() {
        if (revoked) return;
        revoked = true;
        URL.revokeObjectURL(objectUrl);
      },
    };
  });
}

export async function getCachedPronunciation(
  record: ApprovedPronunciation,
): Promise<CachedPronunciation | null> {
  if (!('caches' in globalThis)) return null;
  const cache = await caches.open(PRONUNCIATION_CACHE);
  const request = cacheRequest(record);
  const response = await cache.match(request);
  if (!response) return null;
  return createCached(response, request);
}

export async function cachePronunciation(
  record: ApprovedPronunciation,
  signal?: AbortSignal,
): Promise<CachedPronunciation> {
  if (!('caches' in globalThis)) throw new Error('当前浏览器不支持真人录音离线缓存');
  const response = await fetch(playbackUrl(record), {
    signal,
    mode: 'cors',
    credentials: 'omit',
  });
  if (!response.ok) throw new Error(`真人录音下载失败：${response.status}`);
  const contentType = response.headers.get('content-type') ?? '';
  const normalizedContentType = contentType.toLocaleLowerCase('en').split(';', 1)[0].trim();
  const isAudio = normalizedContentType.startsWith('audio/') || normalizedContentType === 'application/ogg';
  if (!isAudio) throw new Error('返回内容不是音频');
  const request = cacheRequest(record);
  const cache = await caches.open(PRONUNCIATION_CACHE);
  await cache.put(request, response.clone());
  return createCached(response, request);
}

export function downloadPronunciations(
  records: ApprovedPronunciation[],
  options: DownloadOptions = {},
): DownloadController {
  let paused = false;
  let cancelled = false;
  let nextIndex = 0;
  let resumeWaiters: (() => void)[] = [];
  const abortController = new AbortController();
  const report: DownloadReport = { success: 0, failed: 0, skipped: 0, bytes: 0 };

  const notify = () => options.onProgress?.({
    ...report,
    total: records.length,
    completed: report.success + report.failed + report.skipped,
  });

  const waitForResume = async () => {
    if (!paused || cancelled) return;
    await new Promise<void>((resolve) => resumeWaiters.push(resolve));
  };

  const worker = async () => {
    while (!cancelled) {
      await waitForResume();
      if (cancelled) return;
      const index = nextIndex;
      nextIndex += 1;
      if (index >= records.length) return;
      const record = records[index];
      try {
        const cached = await getCachedPronunciation(record);
        if (cached) {
          report.skipped += 1;
          report.bytes += cached.bytes;
          cached.revoke();
          notify();
          continue;
        }
        const saved = await cachePronunciation(record, abortController.signal);
        report.success += 1;
        report.bytes += saved.bytes;
        saved.revoke();
      } catch (error) {
        if (cancelled && error instanceof DOMException && error.name === 'AbortError') return;
        report.failed += 1;
      }
      notify();
    }
  };

  const result = Promise.all(
    Array.from({ length: Math.min(DOWNLOAD_CONCURRENCY, Math.max(records.length, 1)) }, () => worker()),
  ).then(() => ({ ...report }));

  return {
    pause() { paused = true; },
    resume() {
      if (!paused) return;
      paused = false;
      const waiters = resumeWaiters;
      resumeWaiters = [];
      waiters.forEach((resolve) => resolve());
    },
    cancel() {
      if (cancelled) return;
      cancelled = true;
      abortController.abort();
      const waiters = resumeWaiters;
      resumeWaiters = [];
      waiters.forEach((resolve) => resolve());
    },
    result,
  };
}

export async function getPronunciationCacheStats(): Promise<PronunciationCacheStats> {
  if (!('caches' in globalThis)) return { entries: 0, bytes: 0 };
  const cache = await caches.open(PRONUNCIATION_CACHE);
  const requests = await cache.keys();
  let bytes = 0;
  for (const request of requests) {
    const response = await cache.match(request);
    if (!response) continue;
    const length = Number(response.headers.get('content-length'));
    if (Number.isFinite(length) && length >= 0) bytes += length;
    else bytes += (await response.clone().arrayBuffer()).byteLength;
  }
  return { entries: requests.length, bytes };
}

export async function clearPronunciationCache(): Promise<void> {
  if (!('caches' in globalThis)) return;
  await caches.delete(PRONUNCIATION_CACHE);
}
