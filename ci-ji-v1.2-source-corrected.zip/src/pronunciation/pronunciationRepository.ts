import type { IDBPDatabase } from 'idb';
import type { CiJiDb } from '../db/schema';
import type { Accent, WordEntry } from '../domain/models';
import { loadBundledPronunciationMapping } from './bundledMapping';
import type { BundledMapping } from './mappingSchema';
import {
  pronunciationReviewId,
  type PronunciationCandidateRecord,
  type PronunciationReviewRecord,
} from './types';

const ACCENTS: Accent[] = ['en-GB', 'en-US'];

function bundledSlot(mapping: BundledMapping | null, normalizedKey: string, accent: Accent) {
  const entry = mapping?.words[normalizedKey];
  if (!entry) return null;
  return accent === 'en-GB' ? entry.british : entry.american;
}

export function createUnreviewedRecord(
  wordId: string,
  normalizedKey: string,
  accent: Accent,
  now = new Date().toISOString(),
): PronunciationReviewRecord {
  return {
    id: pronunciationReviewId(wordId, accent),
    wordId,
    normalizedKey,
    accent,
    status: 'unreviewed',
    selected: null,
    origin: 'user',
    reviewedAt: null,
    updatedAt: now,
  };
}

export async function ensureReviewSlotsForWords(
  db: IDBPDatabase<CiJiDb>,
  words: WordEntry[],
  suppliedMapping?: BundledMapping,
): Promise<PronunciationReviewRecord[]> {
  const mapping = suppliedMapping ?? await loadBundledPronunciationMapping().catch(() => null);
  const created: PronunciationReviewRecord[] = [];
  const tx = db.transaction('pronunciationReviews', 'readwrite');
  for (const word of words) {
    for (const accent of ACCENTS) {
      const id = pronunciationReviewId(word.id, accent);
      const existing = await tx.store.get(id);
      if (existing) continue;
      if (bundledSlot(mapping, word.normalizedKey, accent)?.status === 'approved') continue;
      const record = createUnreviewedRecord(word.id, word.normalizedKey, accent);
      await tx.store.put(record);
      created.push(record);
    }
  }
  await tx.done;
  return created;
}

export async function approveCandidate(
  db: IDBPDatabase<CiJiDb>,
  candidate: PronunciationCandidateRecord,
): Promise<PronunciationReviewRecord> {
  if (candidate.accent === 'unknown') throw new Error('地区未标明的录音不能直接确认');
  const now = new Date().toISOString();
  const record: PronunciationReviewRecord = {
    id: pronunciationReviewId(candidate.wordId, candidate.accent),
    wordId: candidate.wordId,
    normalizedKey: candidate.normalizedKey,
    accent: candidate.accent,
    status: 'approved',
    selected: {
      accent: candidate.accent,
      audioUrl: candidate.audioUrl,
      compatibleAudioUrl: candidate.compatibleAudioUrl,
      filePageUrl: candidate.filePageUrl,
      author: candidate.author,
      licenseName: candidate.licenseName,
      licenseUrl: candidate.licenseUrl,
      sourceFileName: candidate.sourceFileName,
      durationSeconds: candidate.durationSeconds,
      mappingVersion: 1,
    },
    origin: 'user',
    reviewedAt: now,
    updatedAt: now,
  };
  await db.put('pronunciationReviews', record);
  return record;
}

export async function rejectCandidate(
  db: IDBPDatabase<CiJiDb>,
  candidateId: string,
): Promise<PronunciationCandidateRecord> {
  const candidate = await db.get('pronunciationCandidates', candidateId);
  if (!candidate) throw new Error('未找到候选录音');
  const rejected = { ...candidate, rejected: true };
  await db.put('pronunciationCandidates', rejected);
  return rejected;
}

export async function markAccentMissing(
  db: IDBPDatabase<CiJiDb>,
  wordId: string,
  normalizedKey: string,
  accent: Accent,
): Promise<PronunciationReviewRecord> {
  const now = new Date().toISOString();
  const record: PronunciationReviewRecord = {
    id: pronunciationReviewId(wordId, accent),
    wordId,
    normalizedKey,
    accent,
    status: 'missing',
    selected: null,
    origin: 'user',
    reviewedAt: now,
    updatedAt: now,
  };
  await db.put('pronunciationReviews', record);
  return record;
}

export interface PendingPronunciationWord {
  wordId: string;
  normalizedKey: string;
  british: PronunciationReviewRecord | null;
  american: PronunciationReviewRecord | null;
}

export async function listPendingWords(db: IDBPDatabase<CiJiDb>): Promise<PendingPronunciationWord[]> {
  const reviews = await db.getAllFromIndex('pronunciationReviews', 'by-status', 'unreviewed');
  const grouped = new Map<string, PendingPronunciationWord>();
  for (const review of reviews) {
    const current = grouped.get(review.wordId) ?? {
      wordId: review.wordId,
      normalizedKey: review.normalizedKey,
      british: null,
      american: null,
    };
    if (review.accent === 'en-GB') current.british = review;
    else current.american = review;
    grouped.set(review.wordId, current);
  }
  return [...grouped.values()].sort((a, b) => a.normalizedKey.localeCompare(b.normalizedKey, 'en'));
}

export async function migrateReviewNormalizedKey(
  db: IDBPDatabase<CiJiDb>,
  wordId: string,
  normalizedKey: string,
): Promise<void> {
  const reviews = await db.getAllFromIndex('pronunciationReviews', 'by-word', wordId);
  if (!reviews.length) return;
  const tx = db.transaction('pronunciationReviews', 'readwrite');
  const now = new Date().toISOString();
  for (const review of reviews) await tx.store.put({ ...review, normalizedKey, updatedAt: now });
  await tx.done;
}
