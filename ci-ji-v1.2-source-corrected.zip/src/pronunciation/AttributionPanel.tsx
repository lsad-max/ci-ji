import { useState, type MouseEvent } from 'react';
import type { ApprovedPronunciation } from './types';
import './pronunciation.css';

export function AttributionPanel({
  recording,
  cached,
  compact = false,
}: {
  recording: ApprovedPronunciation;
  cached: boolean;
  compact?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const toggle = (event: MouseEvent<HTMLButtonElement>) => {
    event.stopPropagation();
    setOpen((value) => !value);
  };
  return <div className={`pronunciation-attribution ${compact ? 'is-compact' : ''}`} onClick={(event) => event.stopPropagation()}>
    <button type="button" className="pronunciation-attribution__toggle" onClick={toggle} aria-expanded={open}>
      真人发音 · Wikimedia
    </button>
    {open ? <div className="pronunciation-attribution__details">
      <p><b>作者：</b>{recording.author}</p>
      <p><b>口音：</b>{recording.accent === 'en-GB' ? '英式' : '美式'}</p>
      <p><b>许可证：</b>{recording.licenseUrl
        ? <a href={recording.licenseUrl} target="_blank" rel="noreferrer">{recording.licenseName}</a>
        : recording.licenseName}</p>
      <p><b>缓存：</b>{cached ? '已缓存' : '在线'}</p>
      <a href={recording.filePageUrl} target="_blank" rel="noreferrer">查看 Wikimedia 文件页</a>
    </div> : null}
  </div>;
}
