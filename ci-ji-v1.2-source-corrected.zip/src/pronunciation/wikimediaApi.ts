import type { Accent } from '../domain/models';
import { normalizeWordKey } from '../domain/normalize';
import type { PronunciationAccent, PronunciationCandidateRecord } from './types';

const WIKTIONARY_API = 'https://en.wiktionary.org/w/api.php';
const COMMONS_API = 'https://commons.wikimedia.org/w/api.php';
const REQUEST_TIMEOUT_MS = 8_000;
const CACHE_TTL_MS = 15 * 60 * 1_000;
const AUDIO_EXTENSION = /\.(?:ogg|oga|opus|wav|mp3|webm|flac)$/i;

interface MediaWikiImage {
  title?: string;
}

interface MediaWikiMetadataValue {
  value?: string;
}

interface MediaWikiImageInfo {
  url?: string;
  descriptionurl?: string;
  mime?: string;
  mediatype?: string;
  duration?: number | string;
  extmetadata?: Record<string, MediaWikiMetadataValue | undefined>;
}

interface MediaWikiPage {
  title?: string;
  images?: MediaWikiImage[];
  imageinfo?: MediaWikiImageInfo[];
}

interface MediaWikiResponse {
  query?: { pages?: MediaWikiPage[] };
}

interface CachedCandidates {
  expiresAt: number;
  value: PronunciationCandidateRecord[];
}

const successfulCache = new Map<string, CachedCandidates>();

function apiUrl(base: string, params: Record<string, string>): string {
  const url = new URL(base);
  url.search = new URLSearchParams({
    action: 'query',
    format: 'json',
    formatversion: '2',
    origin: '*',
    ...params,
  }).toString();
  return url.toString();
}

async function fetchJson(url: string, externalSignal?: AbortSignal): Promise<MediaWikiResponse> {
  const controller = new AbortController();
  const abortFromExternal = () => controller.abort(externalSignal?.reason);
  if (externalSignal?.aborted) abortFromExternal();
  else externalSignal?.addEventListener('abort', abortFromExternal, { once: true });
  const timer = globalThis.setTimeout(() => controller.abort(new DOMException('请求超时', 'TimeoutError')), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    });
    if (!response.ok) throw new Error(`Wikimedia 请求失败：${response.status}`);
    return await response.json() as MediaWikiResponse;
  } finally {
    globalThis.clearTimeout(timer);
    externalSignal?.removeEventListener('abort', abortFromExternal);
  }
}

export function stripMetadataHtml(value: string): string {
  if (!value) return '';
  return value
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function metadataValue(info: MediaWikiImageInfo, key: string): string {
  return stripMetadataHtml(info.extmetadata?.[key]?.value ?? '');
}

function detectAccent(title: string, info: MediaWikiImageInfo): PronunciationAccent {
  const text = [
    title,
    metadataValue(info, 'Categories'),
    metadataValue(info, 'Language'),
  ].join(' ').toLocaleLowerCase('en');
  const british = ['en-uk', 'en-gb', 'british', 'uk english', 'united kingdom'];
  const american = ['en-us', 'american', 'us english', 'united states'];
  const hasBritish = british.some((token) => text.includes(token));
  const hasAmerican = american.some((token) => text.includes(token));
  if (hasBritish && !hasAmerican) return 'en-GB';
  if (hasAmerican && !hasBritish) return 'en-US';
  return 'unknown';
}

function fileStem(title: string): string {
  return title
    .replace(/^File:/i, '')
    .replace(/\.[^.]+$/, '')
    .replace(/[_-]+/g, ' ')
    .replace(/\b(?:en|uk|gb|us|british|american|english|pronunciation|audio|voice)\b/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLocaleLowerCase('en');
}

function comparable(value: string): string {
  return normalizeWordKey(value).replace(/[^a-z0-9']/g, '');
}

function exactFileStemMatch(candidate: PronunciationCandidateRecord): boolean {
  return comparable(fileStem(candidate.sourceFileName ?? '')) === comparable(candidate.normalizedKey ?? '');
}

function candidateScore(candidate: PronunciationCandidateRecord, requestedAccent: Accent): number {
  let score = 0;
  score += candidate.source === 'wiktionary' ? 1000 : 0;
  score += exactFileStemMatch(candidate) ? 500 : 0;
  score += candidate.accent === requestedAccent ? 300 : 0;
  score += candidate.accent === 'unknown' ? 50 : 0;
  const complete = Boolean(candidate.author && candidate.licenseName && candidate.filePageUrl);
  score += complete ? 100 : -1000;
  const durationInRange = candidate.durationSeconds !== null
    && candidate.durationSeconds >= 0.2
    && candidate.durationSeconds <= 12;
  score += durationInRange ? 50 : 0;
  return score;
}

export function rankCandidates(
  candidates: PronunciationCandidateRecord[],
  requestedAccent: Accent,
): PronunciationCandidateRecord[] {
  return candidates
    .filter((candidate) => candidate.accent === requestedAccent || candidate.accent === 'unknown')
    .map((candidate, index) => ({ candidate, index, score: candidateScore(candidate, requestedAccent) }))
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .map(({ candidate }, index) => ({ ...candidate, rank: index + 1 }));
}


export function selectReviewCandidates(
  candidates: PronunciationCandidateRecord[],
  maxPerAccent = 5,
): PronunciationCandidateRecord[] {
  const visible = candidates.filter((candidate) => !candidate.rejected);
  const explicit = (accent: Accent) => rankCandidates(visible, accent)
    .filter((candidate) => candidate.accent === accent)
    .slice(0, maxPerAccent)
    .map((candidate, index) => ({ ...candidate, rank: index + 1 }));
  const unknown = rankCandidates(visible, 'en-GB')
    .filter((candidate) => candidate.accent === 'unknown')
    .slice(0, maxPerAccent)
    .map((candidate, index) => ({ ...candidate, rank: index + 1 }));
  return [...explicit('en-GB'), ...explicit('en-US'), ...unknown];
}

function parseCandidate(
  page: MediaWikiPage,
  normalizedKey: string,
  source: PronunciationCandidateRecord['source'],
): PronunciationCandidateRecord | null {
  const title = page.title?.trim() ?? '';
  const info = page.imageinfo?.[0];
  if (!title || !info) return null;
  const mime = info.mime?.toLocaleLowerCase('en') ?? '';
  const isAudio = info.mediatype === 'AUDIO' || mime.startsWith('audio/');
  if (!isAudio) return null;
  if (!info.url?.startsWith('https://')) return null;
  const durationRaw = info.duration;
  const parsedDuration = durationRaw === undefined ? null : Number(durationRaw);
  const durationSeconds = parsedDuration !== null && Number.isFinite(parsedDuration) ? parsedDuration : null;
  if (durationSeconds !== null && (durationSeconds < 0.2 || durationSeconds > 12)) return null;
  const author = metadataValue(info, 'Artist');
  const licenseName = metadataValue(info, 'LicenseShortName') || metadataValue(info, 'UsageTerms');
  const licenseUrlRaw = metadataValue(info, 'LicenseUrl');
  const licenseUrl = licenseUrlRaw.startsWith('https://') ? licenseUrlRaw : null;
  const filePageUrl = info.descriptionurl?.startsWith('https://')
    ? info.descriptionurl
    : `https://commons.wikimedia.org/wiki/${title.replace(/ /g, '_')}`;
  if (!author || !licenseName || !filePageUrl.startsWith('https://')) return null;
  const accent = detectAccent(title, info);
  return {
    id: `${normalizedKey}:${accent}:${title}`,
    wordId: normalizedKey,
    normalizedKey,
    accent,
    audioUrl: info.url,
    compatibleAudioUrl: null,
    filePageUrl,
    sourceFileName: title.replace(/^File:/i, ''),
    author,
    licenseName,
    licenseUrl,
    durationSeconds,
    source,
    rank: 0,
    rejected: false,
    fetchedAt: new Date().toISOString(),
  };
}

async function fetchWiktionaryTitles(normalizedWord: string, signal?: AbortSignal): Promise<string[]> {
  const response = await fetchJson(apiUrl(WIKTIONARY_API, {
    prop: 'images',
    titles: normalizedWord,
    imlimit: 'max',
  }), signal);
  return (response.query?.pages ?? [])
    .flatMap((page) => page.images ?? [])
    .map((image) => image.title ?? '')
    .filter((title) => title.startsWith('File:') && AUDIO_EXTENSION.test(title));
}

async function fetchCommonsDetails(titles: string[], signal?: AbortSignal): Promise<MediaWikiPage[]> {
  if (!titles.length) return [];
  const response = await fetchJson(apiUrl(COMMONS_API, {
    titles: titles.join('|'),
    prop: 'imageinfo',
    iiprop: 'url|mime|mediatype|extmetadata',
    iiextmetadatalanguage: 'en',
    iiextmetadatafilter: 'Artist|LicenseShortName|LicenseUrl|UsageTerms|AttributionRequired|Categories|Language',
  }), signal);
  return response.query?.pages ?? [];
}

async function fetchCommonsSearch(normalizedWord: string, signal?: AbortSignal): Promise<MediaWikiPage[]> {
  const response = await fetchJson(apiUrl(COMMONS_API, {
    generator: 'search',
    gsrsearch: `${normalizedWord} pronunciation`,
    gsrnamespace: '6',
    gsrlimit: '20',
    prop: 'imageinfo',
    iiprop: 'url|mime|mediatype|extmetadata',
    iiextmetadatalanguage: 'en',
    iiextmetadatafilter: 'Artist|LicenseShortName|LicenseUrl|UsageTerms|AttributionRequired|Categories|Language',
  }), signal);
  return response.query?.pages ?? [];
}

export async function searchWikimediaCandidates(
  word: string,
  signal?: AbortSignal,
): Promise<PronunciationCandidateRecord[]> {
  const normalizedWord = normalizeWordKey(word);
  if (!normalizedWord) return [];
  const cached = successfulCache.get(normalizedWord);
  if (cached && cached.expiresAt > Date.now()) return cached.value.map((item) => ({ ...item }));

  const wiktionaryTitles = await fetchWiktionaryTitles(normalizedWord, signal);
  const [linkedPages, searchPages] = await Promise.all([
    fetchCommonsDetails(wiktionaryTitles, signal),
    fetchCommonsSearch(normalizedWord, signal),
  ]);
  const byTitle = new Map<string, PronunciationCandidateRecord>();
  for (const page of linkedPages) {
    const candidate = parseCandidate(page, normalizedWord, 'wiktionary');
    if (candidate) byTitle.set(candidate.sourceFileName.toLocaleLowerCase('en'), candidate);
  }
  for (const page of searchPages) {
    const candidate = parseCandidate(page, normalizedWord, 'commons-search');
    if (candidate && !byTitle.has(candidate.sourceFileName.toLocaleLowerCase('en'))) {
      byTitle.set(candidate.sourceFileName.toLocaleLowerCase('en'), candidate);
    }
  }
  const candidates = [...byTitle.values()];
  successfulCache.set(normalizedWord, {
    expiresAt: Date.now() + CACHE_TTL_MS,
    value: candidates.map((item) => ({ ...item })),
  });
  return candidates;
}

export function clearWikimediaCandidateCacheForTests() {
  successfulCache.clear();
}
