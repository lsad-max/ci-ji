import type { Accent } from '../domain/models';
import {
  cancelSpeech,
  playLocalAudio,
  playSystemSpeech,
  type LowLevelPlaybackResult,
  type SpeechFailureReason,
  type SpeechRate,
} from '../speech/speechService';
import {
  cachePronunciation,
  getCachedPronunciation,
  type CachedPronunciation,
} from './audioCache';
import type { ApprovedPronunciation } from './types';
import type { PronunciationPlan, PronunciationPlanStep } from './pronunciationResolver';

export type { PronunciationPlan, PronunciationPlanStep } from './pronunciationResolver';

export type PronunciationPlaybackSource =
  | 'wikimedia-cache'
  | 'wikimedia-online'
  | 'local-audio'
  | 'system';

export type PronunciationPlaybackResult =
  | {
      ok: true;
      source: PronunciationPlaybackSource;
      accent: Accent;
      voiceName?: string;
      attribution: ApprovedPronunciation | null;
    }
  | { ok: false; reason: SpeechFailureReason };

export interface PlaybackOptions {
  rate: SpeechRate;
  cacheAfterPlayback: boolean;
  userInitiated?: boolean;
}

export interface PlaybackDependencies {
  getCached(recording: ApprovedPronunciation): Promise<CachedPronunciation | null>;
  playRemote(recording: ApprovedPronunciation, rate: SpeechRate, signal: AbortSignal): Promise<LowLevelPlaybackResult>;
  playLocal(url: string, rate: SpeechRate, signal: AbortSignal): Promise<LowLevelPlaybackResult>;
  playSystem(
    word: string,
    accent: Accent,
    rate: SpeechRate,
    signal: AbortSignal,
  ): Promise<LowLevelPlaybackResult & { voiceName?: string }>;
  cacheRemote(recording: ApprovedPronunciation, signal?: AbortSignal): Promise<unknown>;
}

const defaultDependencies: PlaybackDependencies = {
  getCached: getCachedPronunciation,
  playRemote: (recording, rate, signal) => playLocalAudio(
    recording.compatibleAudioUrl ?? recording.audioUrl,
    rate,
    signal,
  ),
  playLocal: playLocalAudio,
  playSystem: playSystemSpeech,
  cacheRemote: async (recording, signal) => {
    const cached = await cachePronunciation(recording, signal);
    cached.revoke();
  },
};

let activeController: AbortController | null = null;

export function cancelPronunciation(): void {
  activeController?.abort();
  activeController = null;
  cancelSpeech();
}

function stepSignal(parent: AbortSignal) {
  const controller = new AbortController();
  const abort = () => controller.abort();
  parent.addEventListener('abort', abort, { once: true });
  return {
    controller,
    cleanup: () => parent.removeEventListener('abort', abort),
  };
}

async function withTimeout(
  operation: (signal: AbortSignal) => Promise<LowLevelPlaybackResult & { voiceName?: string }>,
  timeoutMs: number,
  parent: AbortSignal,
): Promise<LowLevelPlaybackResult & { voiceName?: string }> {
  if (parent.aborted) return { ok: false, reason: 'cancelled' };
  const { controller, cleanup } = stepSignal(parent);
  let timer = 0;
  try {
    return await Promise.race([
      operation(controller.signal),
      new Promise<LowLevelPlaybackResult>((resolve) => {
        timer = window.setTimeout(() => {
          controller.abort();
          resolve({ ok: false, reason: parent.aborted ? 'cancelled' : 'playback-failed' });
        }, timeoutMs);
      }),
    ]);
  } finally {
    window.clearTimeout(timer);
    cleanup();
  }
}

async function playStep(
  plan: PronunciationPlan,
  step: PronunciationPlanStep,
  options: PlaybackOptions,
  dependencies: PlaybackDependencies,
  signal: AbortSignal,
): Promise<LowLevelPlaybackResult & { voiceName?: string }> {
  if (step.kind === 'wikimedia-cache') {
    return withTimeout(async (stepSignalValue) => {
      const cached = await dependencies.getCached(step.recording);
      if (!cached) return { ok: false, reason: 'playback-failed' };
      if (stepSignalValue.aborted) {
        cached.revoke();
        return { ok: false, reason: 'cancelled' };
      }
      try {
        return await dependencies.playLocal(cached.objectUrl, options.rate, stepSignalValue);
      } finally {
        cached.revoke();
      }
    }, step.timeoutMs, signal);
  }
  if (step.kind === 'wikimedia-online') {
    return withTimeout(
      (stepSignalValue) => dependencies.playRemote(step.recording, options.rate, stepSignalValue),
      step.timeoutMs,
      signal,
    );
  }
  if (step.kind === 'local-audio') {
    return withTimeout(
      (stepSignalValue) => dependencies.playLocal(step.url, options.rate, stepSignalValue),
      step.timeoutMs,
      signal,
    );
  }
  return withTimeout(
    (stepSignalValue) => dependencies.playSystem(plan.word, step.accent, options.rate, stepSignalValue),
    step.timeoutMs,
    signal,
  );
}

export async function playPronunciation(
  plan: PronunciationPlan,
  options: PlaybackOptions,
  dependencies: PlaybackDependencies = defaultDependencies,
): Promise<PronunciationPlaybackResult> {
  cancelPronunciation();
  const controller = new AbortController();
  activeController = controller;

  try {
    for (const step of plan.steps) {
      if (controller.signal.aborted) return { ok: false, reason: 'cancelled' };
      const result = await playStep(plan, step, options, dependencies, controller.signal);
      if (result.ok) {
        if (step.kind === 'wikimedia-online' && options.cacheAfterPlayback) {
          void dependencies.cacheRemote(step.recording).catch(() => undefined);
        }
        return {
          ok: true,
          source: step.kind,
          accent: plan.accent,
          ...(result.voiceName ? { voiceName: result.voiceName } : {}),
          attribution: step.kind.startsWith('wikimedia') ? plan.attribution : null,
        };
      }
      if (result.reason === 'cancelled') return result;
      if (result.reason === 'autoplay-blocked' && options.userInitiated === false) return result;
    }
    return { ok: false, reason: controller.signal.aborted ? 'cancelled' : 'unsupported' };
  } finally {
    if (activeController === controller) activeController = null;
  }
}
