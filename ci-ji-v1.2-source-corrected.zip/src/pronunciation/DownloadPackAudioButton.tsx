import { useRef, useState } from 'react';
import type { DailyPack, WordEntry } from '../domain/models';
import { useRepositories } from '../db/RepositoriesContext';
import { useSettings } from '../settings/SettingsProvider';
import { getBundledPronunciation } from './bundledMapping';
import { resolvePronunciationPlan, type PronunciationDataSource } from './pronunciationResolver';
import { downloadPronunciations, type DownloadController, type DownloadProgress, type DownloadReport } from './audioCache';
import type { ApprovedPronunciation } from './types';
import './pronunciation.css';

export function DownloadPackAudioButton({ pack, words }: { pack: DailyPack; words: WordEntry[] }) {
  const repos = useRepositories();
  const { settings } = useSettings();
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<'current' | 'both'>('current');
  const [records, setRecords] = useState<ApprovedPronunciation[]>([]);
  const [missing, setMissing] = useState(0);
  const [progress, setProgress] = useState<DownloadProgress | null>(null);
  const [report, setReport] = useState<DownloadReport | null>(null);
  const [paused, setPaused] = useState(false);
  const controller = useRef<DownloadController | null>(null);

  const prepare = async (selectedMode: 'current' | 'both' = mode) => {
    const source: PronunciationDataSource = {
      getUserReview: (wordId, accent) => repos.pronunciationReviews.get(wordId, accent),
      getBundled: (key, accent) => getBundledPronunciation(key, accent).catch(() => null),
    };
    const accents = selectedMode === 'both' ? (['en-GB', 'en-US'] as const) : [settings.accent];
    const approved: ApprovedPronunciation[] = [];
    let absent = 0;
    for (const word of words.filter((word) => pack.wordIds.includes(word.id))) {
      for (const accent of accents) {
        const plan = await resolvePronunciationPlan(word, accent, { ...settings, pronunciationSource: 'wikimedia-first' }, source);
        if (plan.attribution) approved.push(plan.attribution);
        else absent += 1;
      }
    }
    const unique = [...new Map(approved.map((record) => [`${record.accent}:${record.audioUrl}`, record])).values()];
    setRecords(unique);
    setMissing(absent);
    setReport(null);
    setProgress(null);
    setOpen(true);
  };

  const start = () => {
    const next = downloadPronunciations(records, { onProgress: setProgress });
    controller.current = next;
    setPaused(false);
    void next.result.then(setReport);
  };

  return <div className="pack-audio-download">
    <button type="button" className="secondary-button" onClick={() => void prepare()}>下载今日真人发音</button>
    {open ? <section className="pack-audio-download__panel">
      <label>下载口音<select value={mode} onChange={(event) => { const selected = event.target.value as 'current' | 'both'; setMode(selected); void prepare(selected); }}>
        <option value="current">当前口音</option><option value="both">双口音</option>
      </select></label>
      <p>可下载真人录音：{records.length}条</p>
      <p>缺少真人录音：{missing}条</p>
      <p>预计空间：下载后统计</p>
      {!progress && !report ? <button type="button" onClick={start} disabled={!records.length}>开始下载</button> : null}
      {progress && !report ? <>
        <p>已完成 {progress.completed} / {progress.total}</p>
        <button type="button" onClick={() => { if (paused) controller.current?.resume(); else controller.current?.pause(); setPaused(!paused); }}>{paused ? '继续' : '暂停'}</button>
        <button type="button" onClick={() => controller.current?.cancel()}>取消</button>
      </> : null}
      {report ? <p>成功 {report.success} · 已有 {report.skipped} · 失败 {report.failed}</p> : null}
      <button type="button" onClick={() => setOpen(false)}>关闭</button>
    </section> : null}
  </div>;
}
