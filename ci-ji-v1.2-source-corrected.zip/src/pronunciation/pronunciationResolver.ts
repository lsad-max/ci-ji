import type { Accent, AppSettings, WordEntry } from '../domain/models';
import type { BundledAccentRecord } from './mappingSchema';
import type { ApprovedPronunciation, PronunciationReviewRecord } from './types';

export type PronunciationPlanStep =
  | { kind: 'wikimedia-cache'; recording: ApprovedPronunciation; timeoutMs: 1000 }
  | { kind: 'wikimedia-online'; recording: ApprovedPronunciation; timeoutMs: 6000 }
  | { kind: 'local-audio'; url: string; accent: Accent; timeoutMs: 4000 }
  | { kind: 'system'; accent: Accent; timeoutMs: 3000 };

export interface PronunciationPlan {
  word: string;
  accent: Accent;
  steps: PronunciationPlanStep[];
  attribution: ApprovedPronunciation | null;
}

export interface PronunciationDataSource {
  getUserReview(wordId: string, accent: Accent): Promise<PronunciationReviewRecord | undefined>;
  getBundled(normalizedKey: string, accent: Accent): Promise<BundledAccentRecord | null>;
}

function bundledApproved(record: BundledAccentRecord | null, accent: Accent): ApprovedPronunciation | null {
  if (!record || record.status !== 'approved' || record.accent !== accent) return null;
  return {
    accent,
    audioUrl: record.audioUrl,
    compatibleAudioUrl: record.compatibleAudioUrl,
    filePageUrl: record.filePageUrl,
    author: record.author,
    licenseName: record.licenseName,
    licenseUrl: record.licenseUrl,
    sourceFileName: record.sourceFileName,
    durationSeconds: record.durationSeconds,
    mappingVersion: (record as BundledAccentRecord & { mappingVersion?: number }).mappingVersion ?? 1,
  };
}

async function resolveApproved(
  word: WordEntry,
  accent: Accent,
  source: PronunciationDataSource,
): Promise<ApprovedPronunciation | null> {
  const user = await source.getUserReview(word.id, accent);
  if (user?.status === 'approved' && user.selected?.accent === accent) return user.selected;
  if (user?.status === 'missing' || user?.status === 'rejected') return null;
  return bundledApproved(await source.getBundled(word.normalizedKey, accent), accent);
}

function wikimediaSteps(recording: ApprovedPronunciation | null): PronunciationPlanStep[] {
  if (!recording) return [];
  return [
    { kind: 'wikimedia-cache', recording, timeoutMs: 1000 },
    { kind: 'wikimedia-online', recording, timeoutMs: 6000 },
  ];
}

export async function resolvePronunciationPlan(
  word: WordEntry,
  accent: Accent,
  settings: AppSettings,
  source: PronunciationDataSource,
): Promise<PronunciationPlan> {
  const approved = settings.pronunciationSource === 'system-only'
    ? null
    : await resolveApproved(word, accent, source);
  const localUrl = accent === 'en-GB' ? word.audioUK : word.audioUS;
  const localStep: PronunciationPlanStep[] = localUrl
    ? [{ kind: 'local-audio', url: localUrl, accent, timeoutMs: 4000 }]
    : [];
  const systemStep: PronunciationPlanStep = { kind: 'system', accent, timeoutMs: 3000 };
  const humanSteps = wikimediaSteps(approved);

  const steps = settings.pronunciationSource === 'system-only'
    ? [systemStep]
    : settings.pronunciationSource === 'local-first'
      ? [...localStep, ...humanSteps, systemStep]
      : [...humanSteps, ...localStep, systemStep];

  return {
    word: word.word,
    accent,
    steps,
    attribution: approved,
  };
}
