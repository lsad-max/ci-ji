import { useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowLeft, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useRepositories } from '../db/RepositoriesContext';
import type { Accent, WordEntry } from '../domain/models';
import { todayLocal } from '../domain/dates';
import { cancelSpeech, playLocalAudio } from '../speech/speechService';
import {
  approveCandidate,
  markAccentMissing,
  rejectCandidate,
} from './pronunciationRepository';
import { searchWikimediaCandidates, selectReviewCandidates } from './wikimediaApi';
import type { PronunciationCandidateRecord, PronunciationReviewRecord } from './types';
import { PronunciationReviewCard } from './PronunciationReviewCard';
import './pronunciation.css';

export type PronunciationReviewFilter = 'today' | 'all' | 'missing-british' | 'missing-american' | 'marked-missing';
const STALE_MS = 15 * 60 * 1000;

function reviewFor(reviews: PronunciationReviewRecord[], wordId: string, accent: Accent) {
  return reviews.find((review) => review.wordId === wordId && review.accent === accent);
}

function filterWords(words: WordEntry[], reviews: PronunciationReviewRecord[], filter: PronunciationReviewFilter) {
  const today = todayLocal();
  return words.filter((word) => {
    const british = reviewFor(reviews, word.id, 'en-GB');
    const american = reviewFor(reviews, word.id, 'en-US');
    if (filter === 'today') return word.appearedDates.includes(today)
      && [british, american].some((review) => review?.status === 'unreviewed');
    if (filter === 'missing-british') return !british || british.status === 'unreviewed' || british.status === 'missing';
    if (filter === 'missing-american') return !american || american.status === 'unreviewed' || american.status === 'missing';
    if (filter === 'marked-missing') return british?.status === 'missing' || american?.status === 'missing';
    return [british, american].some((review) => review?.status === 'unreviewed');
  }).sort((a, b) => a.word.localeCompare(b.word, 'en'));
}

function remapCandidates(word: WordEntry, candidates: PronunciationCandidateRecord[]) {
  return candidates.map((candidate) => ({
    ...candidate,
    id: `${word.id}:${candidate.accent}:${candidate.sourceFileName}`,
    wordId: word.id,
    normalizedKey: word.normalizedKey,
  }));
}

export function PronunciationReviewPage() {
  const repos = useRepositories();
  const navigate = useNavigate();
  const [words, setWords] = useState<WordEntry[]>([]);
  const [reviews, setReviews] = useState<PronunciationReviewRecord[]>([]);
  const [filter, setFilter] = useState<PronunciationReviewFilter>('all');
  const [index, setIndex] = useState(0);
  const [selectedWordId, setSelectedWordId] = useState<string | null>(null);
  const [candidates, setCandidates] = useState<PronunciationCandidateRecord[]>([]);
  const [selected, setSelected] = useState<Partial<Record<Accent, string>>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const reload = useCallback(async () => {
    const [nextWords, nextReviews] = await Promise.all([
      repos.words.getAll(),
      repos.pronunciationReviews.getAll(),
    ]);
    setWords(nextWords);
    setReviews(nextReviews);
  }, [repos]);

  useEffect(() => { void reload(); }, [reload]);
  const pendingWords = useMemo(() => filterWords(words, reviews, filter), [words, reviews, filter]);
  const fallbackIndex = Math.min(index, Math.max(pendingWords.length - 1, 0));
  const current = pendingWords.find((word) => word.id === selectedWordId) ?? pendingWords[fallbackIndex] ?? null;

  const loadCandidates = useCallback(async (word: WordEntry, force = false) => {
    setLoading(true);
    setError('');
    try {
      const stored = await repos.pronunciationCandidates.getByWord(word.id);
      const prepare = (items: PronunciationCandidateRecord[]) => selectReviewCandidates(remapCandidates(word, items));
      const fresh = stored.length > 0 && stored.some((candidate) => Date.now() - Date.parse(candidate.fetchedAt) < STALE_MS);
      if (fresh && !force) {
        setCandidates(prepare(stored));
        return;
      }
      const rejectedFiles = new Set(stored
        .filter((candidate) => candidate.rejected)
        .map((candidate) => candidate.sourceFileName.toLocaleLowerCase('en')));
      const discovered = remapCandidates(word, await searchWikimediaCandidates(word.word))
        .map((candidate) => ({
          ...candidate,
          rejected: rejectedFiles.has(candidate.sourceFileName.toLocaleLowerCase('en')),
        }));
      const visible = selectReviewCandidates(discovered);
      const rejected = discovered.filter((candidate) => candidate.rejected);
      await repos.pronunciationCandidates.clearForWord(word.id);
      await repos.pronunciationCandidates.putMany([...rejected, ...visible]);
      setCandidates(visible);
    } catch {
      const stored = await repos.pronunciationCandidates.getByWord(word.id).catch(() => []);
      setCandidates(selectReviewCandidates(remapCandidates(word, stored)));
      setError('查询失败，稍后重试');
    } finally {
      setLoading(false);
    }
  }, [repos]);

  useEffect(() => {
    setSelected({});
    if (current) void loadCandidates(current);
    else setCandidates([]);
    return () => cancelSpeech();
  }, [current?.id, loadCandidates]);

  useEffect(() => {
    if (index >= pendingWords.length && pendingWords.length > 0) setIndex(pendingWords.length - 1);
  }, [index, pendingWords.length]);

  const currentByAccent = (accent: Accent) => {
    const exact = candidates.filter((candidate) => candidate.accent === accent);
    const selectedId = selected[accent];
    return exact.find((candidate) => candidate.id === selectedId) ?? exact[0] ?? null;
  };

  const preview = async (candidate: PronunciationCandidateRecord) => {
    cancelSpeech();
    await playLocalAudio(candidate.compatibleAudioUrl ?? candidate.audioUrl, 1);
  };

  const getNextWord = () => {
    if (!current) return null;
    const currentPosition = pendingWords.findIndex((word) => word.id === current.id);
    return currentPosition >= 0 ? pendingWords[currentPosition + 1] ?? null : null;
  };

  const selectNextWord = (nextWord: WordEntry | null) => {
    cancelSpeech();
    setSelectedWordId(nextWord?.id ?? null);
    if (nextWord) {
      const nextPosition = pendingWords.findIndex((word) => word.id === nextWord.id);
      if (nextPosition >= 0) setIndex(nextPosition);
    } else {
      setIndex((value) => Math.min(value + 1, pendingWords.length));
    }
  };

  const advance = () => selectNextWord(getNextWord());

  const approve = async (candidate: PronunciationCandidateRecord, shouldAdvance = false) => {
    if (candidate.accent === 'unknown') return;
    const nextWord = shouldAdvance ? getNextWord() : null;
    if (shouldAdvance) selectNextWord(nextWord);
    try {
      await approveCandidate(repos.db, candidate);
      await reload();
    } catch {
      if (shouldAdvance) {
        setSelectedWordId(candidate.wordId);
        const previousPosition = pendingWords.findIndex((word) => word.id === candidate.wordId);
        if (previousPosition >= 0) setIndex(previousPosition);
      }
      setError('保存审核结果失败，请重试');
    }
  };

  const approveBoth = async () => {
    if (!current || !british || !american) return;
    const previousWord = current;
    const nextWord = getNextWord();
    selectNextWord(nextWord);
    try {
      await Promise.all([
        approveCandidate(repos.db, british),
        approveCandidate(repos.db, american),
      ]);
      await reload();
    } catch {
      setSelectedWordId(previousWord.id);
      const previousPosition = pendingWords.findIndex((word) => word.id === previousWord.id);
      if (previousPosition >= 0) setIndex(previousPosition);
      setError('保存审核结果失败，请重试');
    }
  };

  const reject = async (candidate: PronunciationCandidateRecord) => {
    await rejectCandidate(repos.db, candidate.id);
    const remaining = candidates.filter((item) => item.id !== candidate.id);
    setCandidates(remaining);
    if (candidate.accent !== 'unknown' && selected[candidate.accent] === candidate.id) {
      setSelected((value) => ({ ...value, [candidate.accent]: remaining.find((item) => item.accent === candidate.accent)?.id }));
    }
  };

  const markMissing = async (accent: Accent) => {
    if (!current) return;
    await markAccentMissing(repos.db, current.id, current.normalizedKey, accent);
    await reload();
  };

  const british = currentByAccent('en-GB');
  const american = currentByAccent('en-US');
  const unknown = candidates.filter((candidate) => candidate.accent === 'unknown');

  return <div className="page pronunciation-review-page">
    <header className="subpage-header">
      <button className="icon-button" onClick={() => navigate(-1)} aria-label="返回"><ArrowLeft/></button>
      <div><h1>待审核发音</h1><p>试听并确认英式、美式真人录音</p></div>
    </header>
    <div className="pronunciation-review-filters">
      <select aria-label="审核筛选" value={filter} onChange={(event) => { setFilter(event.target.value as PronunciationReviewFilter); setIndex(0); setSelectedWordId(null); }}>
        <option value="today">今日词包</option>
        <option value="all">全部待审核</option>
        <option value="missing-british">仅缺英式</option>
        <option value="missing-american">仅缺美式</option>
        <option value="marked-missing">已标记缺失</option>
      </select>
      <span>{pendingWords.length ? `${Math.min(index + 1, pendingWords.length)} / ${pendingWords.length}` : '0 / 0'}</span>
    </div>
    {!current ? <div className="library-empty">当前没有待审核发音</div> : <>
      <section className="pronunciation-review-word">
        <h2>{current.word}</h2>
        <p>{current.meanings.join('；')}</p>
        <button type="button" className="secondary-button" onClick={() => void loadCandidates(current, true)} disabled={loading}><RefreshCw size={16}/>重新查询</button>
      </section>
      {loading ? <p>正在查询 Wikimedia 候选录音…</p> : null}
      {error ? <p className="form-error" role="alert">{error}</p> : null}
      <section className="pronunciation-review-accent"><h3>英式候选</h3>
        {candidates.filter((candidate) => candidate.accent === 'en-GB').map((candidate) => <PronunciationReviewCard
          key={candidate.id} candidate={candidate} selected={(selected['en-GB'] ?? british?.id) === candidate.id}
          onSelect={() => setSelected((value) => ({ ...value, 'en-GB': candidate.id }))}
          onPreview={() => void preview(candidate)} onApprove={() => void approve(candidate)} onReject={() => void reject(candidate)}
        />)}
        {!british ? <p className="muted">暂无英式候选</p> : null}
        <div className="pronunciation-review-actions">
          <button type="button" onClick={() => british && void approve(british, true)} disabled={!british || loading}>确认英式并进入下一词</button>
          <button type="button" onClick={() => void markMissing('en-GB')}>标记缺失</button>
        </div>
      </section>
      <section className="pronunciation-review-accent"><h3>美式候选</h3>
        {candidates.filter((candidate) => candidate.accent === 'en-US').map((candidate) => <PronunciationReviewCard
          key={candidate.id} candidate={candidate} selected={(selected['en-US'] ?? american?.id) === candidate.id}
          onSelect={() => setSelected((value) => ({ ...value, 'en-US': candidate.id }))}
          onPreview={() => void preview(candidate)} onApprove={() => void approve(candidate)} onReject={() => void reject(candidate)}
        />)}
        {!american ? <p className="muted">暂无美式候选</p> : null}
        <div className="pronunciation-review-actions">
          <button type="button" onClick={() => american && void approve(american, true)} disabled={!american || loading}>确认美式并进入下一词</button>
          <button type="button" onClick={() => void markMissing('en-US')}>标记缺失</button>
        </div>
      </section>
      {unknown.length ? <section className="pronunciation-review-accent"><h3>地区未标明</h3>{unknown.map((candidate) => <PronunciationReviewCard
        key={candidate.id} candidate={candidate} selected={false} onSelect={() => undefined}
        onPreview={() => void preview(candidate)} onApprove={() => undefined} onReject={() => void reject(candidate)}
      />)}</section> : null}
      <div className="pronunciation-review-footer">
        <button type="button" onClick={() => void approveBoth()} disabled={!british || !american || loading}>两个口音均确认</button>
        <button type="button" onClick={advance} disabled={loading}>跳过</button>
      </div>
    </>}
  </div>;
}
