import type { IDBPDatabase, StoreNames } from 'idb';
import type { CiJiDb } from './schema';

export async function runReadWriteTransaction<T>(
  db: IDBPDatabase<CiJiDb>,
  storeNames: StoreNames<CiJiDb>[],
  work: (tx: ReturnType<IDBPDatabase<CiJiDb>['transaction']>) => Promise<T>,
): Promise<T> {
  const tx = db.transaction(storeNames, 'readwrite');
  try {
    const result = await work(tx as ReturnType<IDBPDatabase<CiJiDb>['transaction']>);
    await tx.done;
    return result;
  } catch (error) {
    tx.abort();
    throw error;
  }
}
