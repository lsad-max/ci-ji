import { createContext, useContext, type ReactNode } from 'react';
import type { Repositories } from './repositories';

const RepositoriesContext = createContext<Repositories | null>(null);

export function RepositoriesProvider({ repositories, children }: { repositories: Repositories; children: ReactNode }) {
  return <RepositoriesContext.Provider value={repositories}>{children}</RepositoriesContext.Provider>;
}

export function useRepositories(): Repositories {
  const value = useContext(RepositoriesContext);
  if (!value) throw new Error('useRepositories must be used within RepositoriesProvider');
  return value;
}
