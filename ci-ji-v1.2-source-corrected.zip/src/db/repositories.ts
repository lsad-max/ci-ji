import type { IDBPDatabase } from 'idb';
import { DEFAULT_SETTINGS } from '../domain/constants';
import type {
  Accent, AppSettings, DailyPack, ImportRecord, LocalDate, StudyEvent, StudySession,
  StudyState, TrashRecord, WordEntry,
} from '../domain/models';
import { openCiJiDb } from './openDb';
import { pronunciationReviewId, type PronunciationCandidateRecord, type PronunciationReviewRecord, type PronunciationStatus } from '../pronunciation/types';
import type { CiJiDb } from './schema';

export interface Repositories {
  db: IDBPDatabase<CiJiDb>;
  close(): void;
  words: {
    get(id: string): Promise<WordEntry | undefined>;
    getMany(ids: string[]): Promise<WordEntry[]>;
    getAll(): Promise<WordEntry[]>;
    getByNormalizedKey(key: string): Promise<WordEntry | undefined>;
    put(word: WordEntry): Promise<void>;
    delete(id: string): Promise<void>;
  };
  packs: {
    get(id: string): Promise<DailyPack | undefined>;
    getByDate(date: LocalDate): Promise<DailyPack[]>;
    getAll(): Promise<DailyPack[]>;
    put(pack: DailyPack): Promise<void>;
    delete(id: string): Promise<void>;
  };
  studyStates: {
    get(wordId: string): Promise<StudyState | undefined>;
    put(state: StudyState): Promise<void>;
    getAll(): Promise<StudyState[]>;
    getDue(onOrBefore: LocalDate): Promise<StudyState[]>;
    delete(wordId: string): Promise<void>;
  };
  studyEvents: {
    add(event: StudyEvent): Promise<void>;
    delete(id: string): Promise<void>;
    getByWord(wordId: string): Promise<StudyEvent[]>;
    getAll(): Promise<StudyEvent[]>;
  };
  sessions: {
    get(id: string): Promise<StudySession | undefined>;
    getAll(): Promise<StudySession[]>;
    put(session: StudySession): Promise<void>;
    delete(id: string): Promise<void>;
  };
  settings: {
    get(): Promise<AppSettings>;
    patch(patch: Partial<Omit<AppSettings, 'id'>>): Promise<AppSettings>;
  };
  pronunciationReviews: {
    get(wordId: string, accent: Accent): Promise<PronunciationReviewRecord | undefined>;
    getByWord(wordId: string): Promise<PronunciationReviewRecord[]>;
    getByStatus(status: PronunciationStatus): Promise<PronunciationReviewRecord[]>;
    getAll(): Promise<PronunciationReviewRecord[]>;
    put(record: PronunciationReviewRecord): Promise<void>;
    deleteByWord(wordId: string): Promise<void>;
  };
  pronunciationCandidates: {
    getByWord(wordId: string): Promise<PronunciationCandidateRecord[]>;
    putMany(records: PronunciationCandidateRecord[]): Promise<void>;
    clearForWord(wordId: string): Promise<void>;
    deleteOlderThan(iso: string): Promise<number>;
  };
  imports: { add(record: ImportRecord): Promise<void>; getAll(): Promise<ImportRecord[]> };
  trash: {
    put(record: TrashRecord): Promise<void>;
    getAll(): Promise<TrashRecord[]>;
    restore(id: string): Promise<WordEntry>;
    purgeExpired(nowIso: string): Promise<number>;
    delete(id: string): Promise<void>;
  };
}

export async function createRepositories(dbName?: string): Promise<Repositories> {
  const db = await openCiJiDb(dbName);
  return {
    db,
    close: () => db.close(),
    words: {
      get: (id) => db.get('words', id),
      getMany: async (ids) => {
        const tx = db.transaction('words', 'readonly');
        const values = await Promise.all(ids.map((id) => tx.store.get(id)));
        await tx.done;
        return values.filter((value): value is WordEntry => Boolean(value));
      },
      getAll: () => db.getAll('words'),
      getByNormalizedKey: (key) => db.getFromIndex('words', 'by-normalized', key),
      put: async (word) => { await db.put('words', word); },
      delete: async (id) => { await db.delete('words', id); },
    },
    packs: {
      get: (id) => db.get('packs', id),
      getByDate: (date) => db.getAllFromIndex('packs', 'by-date', date),
      getAll: () => db.getAll('packs'),
      put: async (pack) => { await db.put('packs', pack); },
      delete: async (id) => { await db.delete('packs', id); },
    },
    studyStates: {
      get: (wordId) => db.get('studyStates', wordId),
      put: async (state) => { await db.put('studyStates', state); },
      getAll: () => db.getAll('studyStates'),
      getDue: async (onOrBefore) => {
        const all = await db.getAll('studyStates');
        return all
          .filter((state) => state.nextReviewDate !== null && state.nextReviewDate <= onOrBefore)
          .sort((a, b) => (a.nextReviewDate ?? '').localeCompare(b.nextReviewDate ?? ''));
      },
      delete: async (wordId) => { await db.delete('studyStates', wordId); },
    },
    studyEvents: {
      add: async (event) => { await db.put('studyEvents', event); },
      delete: async (id) => { await db.delete('studyEvents', id); },
      getByWord: (wordId) => db.getAllFromIndex('studyEvents', 'by-word', wordId),
      getAll: () => db.getAll('studyEvents'),
    },
    sessions: {
      get: (id) => db.get('sessions', id),
      getAll: () => db.getAll('sessions'),
      put: async (session) => { await db.put('sessions', session); },
      delete: async (id) => { await db.delete('sessions', id); },
    },
    settings: {
      get: async () => {
        const value = await db.get('settings', 'singleton');
        if (value) {
          const merged: AppSettings = { ...structuredClone(DEFAULT_SETTINGS), ...value, id: 'singleton' };
          if (JSON.stringify(merged) !== JSON.stringify(value)) await db.put('settings', merged);
          return merged;
        }
        await db.put('settings', DEFAULT_SETTINGS);
        return structuredClone(DEFAULT_SETTINGS);
      },
      patch: async (patch) => {
        const stored = await db.get('settings', 'singleton');
        const current: AppSettings = { ...structuredClone(DEFAULT_SETTINGS), ...(stored ?? {}), id: 'singleton' };
        const next: AppSettings = { ...current, ...patch, id: 'singleton' };
        await db.put('settings', next);
        return next;
      },
    },
    pronunciationReviews: {
      get: (wordId, accent) => db.get('pronunciationReviews', pronunciationReviewId(wordId, accent)),
      getByWord: (wordId) => db.getAllFromIndex('pronunciationReviews', 'by-word', wordId),
      getByStatus: (status) => db.getAllFromIndex('pronunciationReviews', 'by-status', status),
      getAll: () => db.getAll('pronunciationReviews'),
      put: async (record) => { await db.put('pronunciationReviews', record); },
      deleteByWord: async (wordId) => {
        const tx = db.transaction('pronunciationReviews', 'readwrite');
        const records = await tx.store.index('by-word').getAll(wordId);
        await Promise.all(records.map((record) => tx.store.delete(record.id)));
        await tx.done;
      },
    },
    pronunciationCandidates: {
      getByWord: (wordId) => db.getAllFromIndex('pronunciationCandidates', 'by-word', wordId),
      putMany: async (records) => {
        const tx = db.transaction('pronunciationCandidates', 'readwrite');
        await Promise.all(records.map((record) => tx.store.put(record)));
        await tx.done;
      },
      clearForWord: async (wordId) => {
        const tx = db.transaction('pronunciationCandidates', 'readwrite');
        const records = await tx.store.index('by-word').getAll(wordId);
        await Promise.all(records.map((record) => tx.store.delete(record.id)));
        await tx.done;
      },
      deleteOlderThan: async (iso) => {
        const tx = db.transaction('pronunciationCandidates', 'readwrite');
        const records = await tx.store.getAll();
        const stale = records.filter((record) => record.fetchedAt < iso);
        await Promise.all(stale.map((record) => tx.store.delete(record.id)));
        await tx.done;
        return stale.length;
      },
    },
    imports: {
      add: async (record) => { await db.put('imports', record); },
      getAll: () => db.getAll('imports'),
    },
    trash: {
      put: async (record) => { await db.put('trash', record); },
      getAll: () => db.getAll('trash'),
      restore: async (id) => {
        const tx = db.transaction(['trash', 'words'], 'readwrite');
        const record = await tx.objectStore('trash').get(id);
        if (!record) { tx.abort(); throw new Error('回收站中未找到该单词'); }
        await tx.objectStore('words').put(record.word);
        await tx.objectStore('trash').delete(id);
        await tx.done;
        return record.word;
      },
      purgeExpired: async (nowIso) => {
        const tx = db.transaction(['trash', 'pronunciationReviews', 'pronunciationCandidates'], 'readwrite');
        const all = await tx.objectStore('trash').getAll();
        const expired = all.filter((record) => record.expiresAt <= nowIso);
        for (const record of expired) {
          await tx.objectStore('trash').delete(record.id);
          const reviews = await tx.objectStore('pronunciationReviews').index('by-word').getAll(record.word.id);
          for (const review of reviews) await tx.objectStore('pronunciationReviews').delete(review.id);
          const candidates = await tx.objectStore('pronunciationCandidates').index('by-word').getAll(record.word.id);
          for (const candidate of candidates) await tx.objectStore('pronunciationCandidates').delete(candidate.id);
        }
        await tx.done;
        return expired.length;
      },
      delete: async (id) => {
        const record = await db.get('trash', id);
        if (!record) return;
        const tx = db.transaction(['trash', 'pronunciationReviews', 'pronunciationCandidates'], 'readwrite');
        await tx.objectStore('trash').delete(id);
        const reviews = await tx.objectStore('pronunciationReviews').index('by-word').getAll(record.word.id);
        for (const review of reviews) await tx.objectStore('pronunciationReviews').delete(review.id);
        const candidates = await tx.objectStore('pronunciationCandidates').index('by-word').getAll(record.word.id);
        for (const candidate of candidates) await tx.objectStore('pronunciationCandidates').delete(candidate.id);
        await tx.done;
      },
    },
  };
}
