import { openDB, type IDBPDatabase } from 'idb';
import type { CiJiDb } from './schema';

export const DB_VERSION = 2;
export const DEFAULT_DB_NAME = 'ci-ji';

export function openCiJiDb(name = DEFAULT_DB_NAME): Promise<IDBPDatabase<CiJiDb>> {
  return openDB<CiJiDb>(name, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('words')) {
        const store = db.createObjectStore('words', { keyPath: 'id' });
        store.createIndex('by-normalized', 'normalizedKey', { unique: true });
        store.createIndex('by-updated', 'updatedAt');
      }
      if (!db.objectStoreNames.contains('packs')) {
        const store = db.createObjectStore('packs', { keyPath: 'id' });
        store.createIndex('by-date', 'date');
      }
      if (!db.objectStoreNames.contains('studyStates')) {
        const store = db.createObjectStore('studyStates', { keyPath: 'wordId' });
        store.createIndex('by-status', 'status');
        store.createIndex('by-next-review', 'nextReviewDate');
      }
      if (!db.objectStoreNames.contains('studyEvents')) {
        const store = db.createObjectStore('studyEvents', { keyPath: 'id' });
        store.createIndex('by-word', 'wordId');
        store.createIndex('by-local-date', 'localDate');
      }
      if (!db.objectStoreNames.contains('sessions')) {
        const store = db.createObjectStore('sessions', { keyPath: 'id' });
        store.createIndex('by-updated', 'updatedAt');
      }
      if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('imports')) {
        const store = db.createObjectStore('imports', { keyPath: 'id' });
        store.createIndex('by-imported', 'importedAt');
      }
      if (!db.objectStoreNames.contains('trash')) {
        const store = db.createObjectStore('trash', { keyPath: 'id' });
        store.createIndex('by-expires', 'expiresAt');
      }
      if (!db.objectStoreNames.contains('pronunciationReviews')) {
        const store = db.createObjectStore('pronunciationReviews', { keyPath: 'id' });
        store.createIndex('by-word', 'wordId');
        store.createIndex('by-status', 'status');
        store.createIndex('by-normalized', 'normalizedKey');
      }
      if (!db.objectStoreNames.contains('pronunciationCandidates')) {
        const store = db.createObjectStore('pronunciationCandidates', { keyPath: 'id' });
        store.createIndex('by-word', 'wordId');
        store.createIndex('by-accent', 'accent');
        store.createIndex('by-fetched', 'fetchedAt');
      }
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' });
    },
  });
}
