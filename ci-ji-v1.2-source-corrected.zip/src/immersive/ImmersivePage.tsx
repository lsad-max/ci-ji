import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, ChevronDown, ChevronRight, Search } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { useRepositories } from '../db/RepositoriesContext';
import type { DailyPack, StudyState, WordEntry } from '../domain/models';
import { todayLocal } from '../domain/dates';
import { useSettings } from '../settings/SettingsProvider';
import { useSpeech } from '../speech/useSpeech';
import { buildImmersiveRows, type ImmersiveFilter } from './immersiveQueries';
import { ImmersiveRow } from './ImmersiveRow';
import './immersive.css';

export function ImmersivePage(){
  const {packId}=useParams();const navigate=useNavigate();const repositories=useRepositories();const {settings}=useSettings();const {speak}=useSpeech();
  const [pack,setPack]=useState<DailyPack|null>(null);const [words,setWords]=useState<WordEntry[]>([]);const [states,setStates]=useState<StudyState[]>([]);const [openWordId,setOpenWordId]=useState<string|null>(null);
  const [order,setOrder]=useState<'source'|'category'>('source');const [filter,setFilter]=useState<ImmersiveFilter>('all');const [search,setSearch]=useState('');const [expanded,setExpanded]=useState<Set<string>>(new Set());const listRef=useRef<HTMLDivElement>(null);
  useEffect(()=>{void(async()=>{const packs=await repositories.packs.getAll();const selected=packId==='today'?packs.find(p=>p.date===todayLocal())??packs.sort((a,b)=>b.date.localeCompare(a.date))[0]:packs.find(p=>p.id===packId);if(!selected)return;setPack(selected);setWords(await repositories.words.getMany(selected.wordIds));setStates(await repositories.studyStates.getAll());setExpanded(new Set(selected.categories));queueMicrotask(()=>{const saved=Number(sessionStorage.getItem(`immersive-scroll:${selected.id}`)??0);const element=listRef.current;if(!element)return;if(typeof element.scrollTo==='function')element.scrollTo({top:saved});else element.scrollTop=saved;});})();},[packId,repositories]);
  useEffect(()=>setOpenWordId(null),[order,filter,search,packId]);
  useEffect(()=>()=>{if(pack&&listRef.current)sessionStorage.setItem(`immersive-scroll:${pack.id}`,String(listRef.current.scrollTop));},[pack]);
  const projection=useMemo(()=>pack?buildImmersiveRows(pack,words,states,{order,filter,search}):{rows:[],groups:[]},[pack,words,states,order,filter,search]);
  const toggle=(row:typeof projection.rows[number])=>{const opening=openWordId!==row.word.id;setOpenWordId(opening?row.word.id:null);if(opening&&settings.autoSpeakImmersive)void speak(row.word);};
  return <div className="immersive-screen"><header className="immersive-header"><button aria-label="返回" onClick={()=>navigate(-1)}><ArrowLeft/></button><div><b>{pack?.theme??'沉浸词表'}</b><span>{projection.rows.length}词</span></div></header>
    <div className="immersive-tools"><label className="immersive-search"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="搜索英文或中文"/></label><div className="segmented"><button className={order==='source'?'is-active':''} onClick={()=>setOrder('source')}>原顺序</button><button className={order==='category'?'is-active':''} onClick={()=>setOrder('category')}>按分类</button></div><div className="filter-row">{(['all','unseen','fuzzy','unknown'] as const).map(value=><button key={value} className={filter===value?'is-active':''} onClick={()=>setFilter(value)}>{({all:'全部',unseen:'未学习',fuzzy:'模糊',unknown:'不认识'} as const)[value]}</button>)}</div></div>
    <div className="immersive-list" ref={listRef} onClick={event=>{if(event.target===event.currentTarget)setOpenWordId(null);}}>
      {order==='source'?projection.rows.map(row=><ImmersiveRow key={row.word.id} row={row} open={openWordId===row.word.id} onToggle={()=>toggle(row)}/>):projection.groups.map(group=><section className="immersive-group" key={group.category}><button className="group-header" onClick={()=>setExpanded(prev=>{const next=new Set(prev);next.has(group.category)?next.delete(group.category):next.add(group.category);return next;})}>{expanded.has(group.category)?<ChevronDown size={19}/>:<ChevronRight size={19}/>}<span>{group.category}</span><small>{group.rows.length}词</small></button>{expanded.has(group.category)?group.rows.map(row=><ImmersiveRow key={`${group.category}-${row.word.id}`} row={row} open={openWordId===row.word.id} onToggle={()=>toggle(row)}/>):null}</section>)}
      {!projection.rows.length?<div className="immersive-empty">没有符合条件的单词</div>:null}
    </div>
  </div>;
}
