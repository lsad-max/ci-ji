import type { DailyPack, MasteryStatus, StudyState, WordEntry } from '../domain/models';
import { normalizeWordKey } from '../domain/normalize';

export type ImmersiveFilter = 'all' | 'unseen' | 'fuzzy' | 'unknown';
export interface ImmersiveRowData { number:number; word:WordEntry; status:MasteryStatus }
export interface ImmersiveGroup { category:string; rows:ImmersiveRowData[] }
export interface ImmersiveProjection { rows:ImmersiveRowData[]; groups:ImmersiveGroup[] }

export function buildImmersiveRows(
  pack: DailyPack,
  words: WordEntry[],
  states: StudyState[],
  options: { order:'source'|'category'; filter:ImmersiveFilter; search:string },
): ImmersiveProjection {
  const byId=new Map(words.map(word=>[word.id,word]));
  const stateById=new Map(states.map(state=>[state.wordId,state]));
  const query=normalizeWordKey(options.search);
  const rows=pack.wordIds.flatMap((id,index)=>{
    const word=byId.get(id);if(!word)return [];
    const status=stateById.get(id)?.status??'unseen';
    if(options.filter!=='all'&&status!==options.filter)return [];
    if(query&&!normalizeWordKey(`${word.word} ${word.meanings.join(' ')}`).includes(query))return [];
    return [{number:index+1,word,status}];
  });
  const groupsMap=new Map<string,ImmersiveRowData[]>();
  for(const row of rows){for(const category of row.word.categories.length?row.word.categories:['未分类']){const list=groupsMap.get(category)??[];list.push(row);groupsMap.set(category,list);}}
  const groups=[...groupsMap.entries()].map(([category,groupRows])=>({category,rows:groupRows}));
  return {rows,groups};
}
