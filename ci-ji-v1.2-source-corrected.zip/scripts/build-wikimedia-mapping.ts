import { readFile, writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { normalizeWordKey } from '../src/domain/normalize';
import { parseBundledMapping, type BundledAccentRecord, type BundledMapping } from '../src/pronunciation/mappingSchema';

export interface ReviewRow {
  word: string;
  normalizedKey: string;
  accent: 'en-GB' | 'en-US';
  status: 'approved' | 'missing';
  audioUrl: string;
  compatibleAudioUrl: string;
  filePageUrl: string;
  author: string;
  licenseName: string;
  licenseUrl: string;
  sourceFileName: string;
  durationSeconds: string;
  reviewedBy: string;
  reviewedAt: string;
  notes: string;
}

const REQUIRED_HEADER = [
  'word','normalizedKey','accent','status','audioUrl','compatibleAudioUrl','filePageUrl','author',
  'licenseName','licenseUrl','sourceFileName','durationSeconds','reviewedBy','reviewedAt','notes',
] as const;

function parseCsvRows(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') { field += '"'; index += 1; }
      else if (char === '"') quoted = false;
      else field += char;
      continue;
    }
    if (char === '"') quoted = true;
    else if (char === ',') { row.push(field); field = ''; }
    else if (char === '\n') { row.push(field.replace(/\r$/, '')); rows.push(row); row = []; field = ''; }
    else field += char;
  }
  if (field || row.length) { row.push(field.replace(/\r$/, '')); rows.push(row); }
  if (quoted) throw new Error('审核 CSV 引号未闭合');
  return rows.filter((item) => item.some((value) => value.trim() !== ''));
}

export function parseReviewCsv(text: string): ReviewRow[] {
  const [header, ...rows] = parseCsvRows(text);
  if (!header || header.join(',') !== REQUIRED_HEADER.join(',')) {
    throw new Error(`审核 CSV 表头必须为：${REQUIRED_HEADER.join(',')}`);
  }
  return rows.map((values, rowIndex) => {
    if (values.length !== REQUIRED_HEADER.length) throw new Error(`审核 CSV 第 ${rowIndex + 2} 行列数错误`);
    return Object.fromEntries(REQUIRED_HEADER.map((key, index) => [key, values[index] ?? ''])) as unknown as ReviewRow;
  });
}

function approvedRecord(row: ReviewRow): BundledAccentRecord {
  const required = [row.audioUrl, row.filePageUrl, row.author, row.licenseName, row.sourceFileName, row.reviewedBy, row.reviewedAt];
  if (required.some((value) => !value.trim())) throw new Error(`${row.normalizedKey} ${row.accent} 授权字段不完整`);
  if (!row.audioUrl.startsWith('https://') || !row.filePageUrl.startsWith('https://commons.wikimedia.org/wiki/File:')) {
    throw new Error(`${row.normalizedKey} ${row.accent} URL 不符合要求`);
  }
  const duration = row.durationSeconds.trim() ? Number(row.durationSeconds) : null;
  if (duration !== null && (!Number.isFinite(duration) || duration <= 0 || duration > 12)) {
    throw new Error(`${row.normalizedKey} ${row.accent} 时长无效`);
  }
  return {
    status: 'approved',
    accent: row.accent,
    audioUrl: row.audioUrl,
    compatibleAudioUrl: row.compatibleAudioUrl || null,
    filePageUrl: row.filePageUrl,
    author: row.author,
    licenseName: row.licenseName,
    licenseUrl: row.licenseUrl || null,
    sourceFileName: row.sourceFileName,
    durationSeconds: duration,
  };
}

export function buildMapping(
  pack: { words: { word: string }[] },
  rows: ReviewRow[],
  currentMappingVersion = 0,
  generatedAt = new Date().toISOString(),
): BundledMapping {
  const packWords = [...new Map(pack.words.map((item) => [normalizeWordKey(item.word), item.word])).entries()]
    .sort(([a], [b]) => a.localeCompare(b, 'en'));
  const packKeys = new Set(packWords.map(([key]) => key));
  const byKey = new Map<string, Map<'en-GB' | 'en-US', ReviewRow>>();

  for (const row of rows) {
    const key = normalizeWordKey(row.normalizedKey || row.word);
    if (!packKeys.has(key)) throw new Error(`审核 CSV 包含词包外词条：${key}`);
    if (row.accent !== 'en-GB' && row.accent !== 'en-US') throw new Error(`${key} 口音无效`);
    if (row.status !== 'approved' && row.status !== 'missing') throw new Error(`${key} ${row.accent} 状态无效`);
    const accentRows = byKey.get(key) ?? new Map();
    if (accentRows.has(row.accent)) throw new Error(`${key} ${row.accent} 存在重复审核结果`);
    accentRows.set(row.accent, { ...row, normalizedKey: key });
    byKey.set(key, accentRows);
  }

  const words: BundledMapping['words'] = {};
  for (const [key] of packWords) {
    const accentRows = byKey.get(key);
    const british = accentRows?.get('en-GB');
    const american = accentRows?.get('en-US');
    if (!british) throw new Error(`${key} 缺少 en-GB 审核结果`);
    if (!american) throw new Error(`${key} 缺少 en-US 审核结果`);
    words[key] = {
      british: british.status === 'approved' ? approvedRecord(british) : { status: 'missing', accent: 'en-GB' },
      american: american.status === 'approved' ? approvedRecord(american) : { status: 'missing', accent: 'en-US' },
    };
  }

  return parseBundledMapping({
    schemaVersion: 1,
    mappingVersion: currentMappingVersion + 1,
    generatedAt,
    words,
  });
}

async function main() {
  const packPath = resolve('public/packs/2026-07-11-自然地理与环境-131词.json');
  const reviewPath = resolve('docs/pronunciation/wikimedia-review.csv');
  const mappingPath = resolve('public/data/wikimedia-pronunciations.json');
  const pack = JSON.parse(await readFile(packPath, 'utf8')) as { words: { word: string }[] };
  const rows = parseReviewCsv(await readFile(reviewPath, 'utf8'));
  let currentVersion = 0;
  try {
    currentVersion = parseBundledMapping(JSON.parse(await readFile(mappingPath, 'utf8'))).mappingVersion;
  } catch { /* first build */ }
  const mapping = buildMapping(pack, rows, currentVersion);
  await writeFile(mappingPath, `${JSON.stringify(mapping, null, 2)}\n`, 'utf8');
  const records = Object.values(mapping.words).flatMap((entry) => [entry.british, entry.american]);
  const approved = records.filter((record) => record.status === 'approved').length;
  console.log(`${Object.keys(mapping.words).length} words / ${records.length} accent slots reviewed`);
  console.log(`approved: ${approved}`);
  console.log(`missing: ${records.length - approved}`);
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  main().catch((error) => { console.error(error instanceof Error ? error.message : error); process.exitCode = 1; });
}
