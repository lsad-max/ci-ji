import { execFileSync } from 'node:child_process';
import { mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
const root=resolve(import.meta.dirname,'..');const source=resolve(root,'public/icons/icon.svg');mkdirSync(dirname(source),{recursive:true});
const convert=process.env.IMAGEMAGICK_CONVERT||'/opt/imagemagick/bin/convert';
const render=(size,name,sourcePath=source)=>execFileSync(convert,['-background','none',sourcePath,'-resize',`${size}x${size}`,resolve(root,`public/icons/${name}`)],{stdio:'inherit'});
render(192,'icon-192.png');render(512,'icon-512.png');render(180,'apple-touch-icon.png');
const maskable=resolve(root,'public/icons/.maskable.svg');writeFileSync(maskable,`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" fill="#0f766e"/><image href="icon.svg" x="56" y="56" width="400" height="400"/></svg>`);render(512,'maskable-512.png',maskable);rmSync(maskable);
console.log('Generated PWA icons.');
