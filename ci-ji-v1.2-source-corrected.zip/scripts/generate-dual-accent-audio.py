#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / 'public' / 'packs' / '2026-07-11-自然地理与环境-131词.json'
AUDIO_ROOT = ROOT / 'public' / 'audio'

VOICE_BY_ACCENT = {
    'en-GB': 'en-uk-rp',
    'en-US': 'en-us',
}


def slugify(value: str) -> str:
    value = value.strip().lower().replace('ñ', 'n')
    value = re.sub(r'[^a-z0-9]+', '-', value)
    return value.strip('-') or 'word'


def run(command: list[str]) -> None:
    subprocess.run(command, check=True)


def generate(word: str, voice: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        wav = Path(tmp) / 'word.wav'
        run(['espeak', '-v', voice, '-s', '145', '-w', str(wav), word])
        run([
            'ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
            '-i', str(wav),
            '-af', (
                'silenceremove=start_periods=1:start_silence=0.02:start_threshold=-50dB:'
                'stop_periods=-1:stop_silence=0.12:stop_threshold=-50dB,'
                'loudnorm=I=-18:TP=-3:LRA=7,apad=pad_dur=0.12'
            ),
            '-ar', '22050', '-ac', '1', '-b:a', '48k', str(destination),
        ])


def main() -> None:
    if shutil.which('espeak') is None or shutil.which('ffmpeg') is None:
        raise SystemExit('espeak and ffmpeg are required')

    pack = json.loads(PACK.read_text(encoding='utf-8'))
    for index, item in enumerate(pack['words'], start=1):
        filename = f'{index:03d}-{slugify(item["word"])}.mp3'
        for accent, voice in VOICE_BY_ACCENT.items():
            relative = Path('audio') / accent / filename
            destination = ROOT / 'public' / relative
            if not destination.exists():
                generate(item['word'], voice, destination)
            key = 'audioUK' if accent == 'en-GB' else 'audioUS'
            item[key] = relative.as_posix()

    pack['notes'] = (
        '根据用户提供的四张词表图片校对整理；以识词为目标。'
        '已附带英式与美式双口音独立音频，系统语音作为备用。'
    )
    PACK.write_text(json.dumps(pack, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
