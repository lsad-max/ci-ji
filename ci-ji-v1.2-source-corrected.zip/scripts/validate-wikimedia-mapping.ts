import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { normalizeWordKey } from '../src/domain/normalize';
import { parseBundledMapping } from '../src/pronunciation/mappingSchema';

async function main() {
  const packPath = resolve('public/packs/2026-07-11-自然地理与环境-131词.json');
  const mappingPath = resolve('public/data/wikimedia-pronunciations.json');
  const pack = JSON.parse(await readFile(packPath, 'utf8')) as { words: { word: string }[] };
  const mapping = parseBundledMapping(JSON.parse(await readFile(mappingPath, 'utf8')));
  const packKeys = pack.words.map((word) => normalizeWordKey(word.word));
  const missingWords = packKeys.filter((key) => !mapping.words[key]);
  if (missingWords.length) throw new Error(`映射缺少词条：${missingWords.join(', ')}`);
  const extraWords = Object.keys(mapping.words).filter((key) => !packKeys.includes(key));
  if (extraWords.length) throw new Error(`映射包含词包外词条：${extraWords.join(', ')}`);
  for (const [key, entry] of Object.entries(mapping.words)) {
    for (const record of [entry.british, entry.american]) {
      if (record.status === 'approved' && !record.filePageUrl.includes('commons.wikimedia.org/wiki/File:')) {
        throw new Error(`${key} 的来源页不是 Commons File 页面`);
      }
    }
  }
  console.log(`${packKeys.length} words / ${packKeys.length * 2} accent slots validated`);
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
});
