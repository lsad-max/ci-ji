import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { normalizeWordKey } from '../src/domain/normalize';
import { rankCandidates, searchWikimediaCandidates } from '../src/pronunciation/wikimediaApi';

const USER_AGENT = 'CiJiPronunciationAudit/1.2 (https://github.com/lsad-max/ci-ji)';
const WAIT_MS = 250;
const outputPath = resolve('docs/pronunciation/wikimedia-candidates.json');

const nativeFetch = globalThis.fetch;
globalThis.fetch = (input, init = {}) => nativeFetch(input, {
  ...init,
  headers: { ...Object.fromEntries(new Headers(init.headers).entries()), 'User-Agent': USER_AGENT },
});

async function main() {
  const pack = JSON.parse(await readFile(resolve('public/packs/2026-07-11-自然地理与环境-131词.json'), 'utf8')) as { words: { word: string }[] };
  const results: unknown[] = [];
  let failures = 0;
  for (const [index, item] of pack.words.entries()) {
    const normalizedKey = normalizeWordKey(item.word);
    try {
      const candidates = await searchWikimediaCandidates(item.word);
      results.push({
        word: item.word,
        normalizedKey,
        british: rankCandidates(candidates, 'en-GB').slice(0, 5),
        american: rankCandidates(candidates, 'en-US').slice(0, 5),
      });
      console.log(`[${index + 1}/${pack.words.length}] ${item.word}: ${candidates.length} candidates`);
    } catch (error) {
      failures += 1;
      results.push({ word: item.word, normalizedKey, error: error instanceof Error ? error.message : String(error) });
      console.error(`[${index + 1}/${pack.words.length}] ${item.word}: failed`);
    }
    await new Promise((resolveWait) => setTimeout(resolveWait, WAIT_MS));
  }
  await mkdir(resolve('docs/pronunciation'), { recursive: true });
  await writeFile(outputPath, `${JSON.stringify({ generatedAt: new Date().toISOString(), userAgent: USER_AGENT, results }, null, 2)}\n`, 'utf8');
  console.log(`candidate discovery complete: ${pack.words.length - failures} succeeded, ${failures} failed`);
  if (failures) process.exitCode = 1;
}

main().catch((error) => { console.error(error instanceof Error ? error.message : error); process.exitCode = 1; });
