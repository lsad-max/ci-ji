import { readFile } from 'node:fs/promises';
import { parsePackJson } from '../src/packs/parsePack';

const file = process.argv[2];
if (!file) throw new Error('Usage: npm run validate:pack -- <path>');
const result = parsePackJson(await readFile(file, 'utf8'));
if (!result.ok) {
  console.error(JSON.stringify(result.issues, null, 2));
  process.exitCode = 1;
} else {
  console.log(`VALID ${result.pack.date} ${result.pack.theme} ${result.pack.wordCount}`);
}
